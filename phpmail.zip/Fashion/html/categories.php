<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab ::Contact us</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="megamenu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="megamenu/css/webslidemenu.css" />
<script type="text/javascript" src="megamenu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="megamenu/font-awesome/css/font-awesome.min.css" />



</head>

<body>
<? include"header.php"?>
<div class="inner-banner ib-s">
<div><a href="index.php">Home</a> &raquo; About us</div>
</div

<div class="container">
<div class="content">
<h1><span>Product Categories</span></h1> 
      
      
     <ul class="list1">
<? //$SQL = "select * from categories where pid = 0  order by cname  ";
	$RES = mysql_query("select * from categories where pid = 0  order by cname") or die(mysql_error());
	while($ARR = mysql_fetch_array($RES)){
	?>    
<li><a href="detail-catid-<? echo $ARR[cid]; ?>-cname-<?=stripslashes($ARR[cname])?>.html"><? echo stripslashes($ARR[cname]); ?></a>


  <?
	//$SUBCATSQL = "select * from categories where pid = '$ARR[cid]' order by cname";
	$SUBCATres = mysql_query("select * from categories where pid = '$ARR[cid]' order by cname") or die(mysql_error());
	while($SUBCATARR = mysql_fetch_array($SUBCATres)){ 
	//$SUBCATSQLS = "select * from categories where pid = '$SUBCATARR[cid]' order by cname";  ?>
    
<?php
$cntSql1 = mysql_query("select master_categories_id from products where master_categories_id = '$SUBCATARR[cid]' and products_status  = 1");
$numsubmenu1 = mysql_num_rows($cntSql1);
if($numsubmenu1>0) {
?>    
    
	
<?php 
$cntSql1 = mysql_query("select master_categories_id from products where master_categories_id = '$SUBCATARR[cid]' and products_status  = 1");
$numsubmenu1 = mysql_num_rows($cntSql1);
if($numsubmenu1>0) { ?><ul>
<?php
$SUBCATres = mysql_query("select * from categories where pid = '$ARR[cid]' order by cname") or die(mysql_error());
	while($SUBCATARR = mysql_fetch_array($SUBCATres)){
?>

<?php
$cntSql = mysql_query("select master_categories_id from products where master_categories_id = '$SUBCATARR[cid]' and products_status  = 1");
$numsubmenu = mysql_num_rows($cntSql);
if($numsubmenu>0) {
?>    
    <li><a href="detail-catid-<? echo $SUBCATARR[cid]; ?>-cname-<?=stripslashes($SUBCATARR[cname])?>.html"  ><? echo stripslashes($SUBCATARR[cname]); ?></a></li> 
<? } ?>	

    
 <? } ?>	   
    
    
   </ul>
   <? } ?>
   
  <? } ?>  
   
   
   
  
   
<? }?> 


  
   
   
   
   
   
</li>
  <? }?>

   
   
   
   
   
   
   
   
</li>

</ul>

<div class="clear"></div>
</div>
</div>
<? include"footer.php"?>
</body>
</html>