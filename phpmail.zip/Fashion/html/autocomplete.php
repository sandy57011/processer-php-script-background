<? include("include/connect.php");?>
<? include("include/function.php");?>
<? //include("includeshoping/functions.php");
$q = strtolower($_GET["q"]);
if (!$q) return;
$sqlSearch = "select cid,cname from categories where cname LIKE '%$q%' ";
$res = mysql_query($sqlSearch);
$cntName = mysql_num_rows($res);
if($cntName>0) {
while($rs = mysql_fetch_array($res))
 {
$cname = $rs['cname'];
echo "$cname\n";
}
}
$sqlSearch = "select * from products where product_title LIKE '%$q%' ";
$res = mysql_query($sqlSearch);
$cntName = mysql_num_rows($res);
if($cntName>0) {
while($rs = mysql_fetch_array($res))
 {
$product_title = $rs['product_title'];
echo "$product_title\n";
}
}
$sqlSearch = "select * from products where product_title1 LIKE '%$q%' ";
$res = mysql_query($sqlSearch);
$cntName = mysql_num_rows($res);
if($cntName>0) {
while($rs = mysql_fetch_array($res))
 {
$product_title1 = $rs['product_title1'];
echo "$product_title1\n";
}
}
?>