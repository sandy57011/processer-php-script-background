<?
 if($_REQUEST[btnSubmit]){
 $other="";
   for($n=0;$n<count($_REQUEST[other]);$n++)
  {
    if($n>0)
   $other.=", ".$_REQUEST[other][$n];
   else
   $other.=$_REQUEST[other][$n];
   }
  	 $intFile=mt_rand();
if($_FILES[ProductFile][name]!="")
	{ 
		$filename = "product_file/".$intFile.$_FILES[ProductFile][name];
 		move_uploaded_file($_FILES[ProductFile][tmp_name],"../".$filename);
	}
else{	$filename="";	}
if($_FILES[articleFile2][name]!="")
	{ $filename1 = "product_file/".$intFile.$_FILES[articleFile2][name];
 		move_uploaded_file($_FILES[articleFile2][tmp_name],"../".$filename1);
	}
else{	$filename1="";	}
if($_FILES[articleFile3][name]!="")
	{ 
	$filename2 = "product_file/".$intFile.$_FILES[articleFile3][name];
 		move_uploaded_file($_FILES[articleFile3][tmp_name],"../".$filename2);
	}
else{	$filename2="";	}  
 /**icon image code**/
 $intFile=mt_rand();
	 if($_FILES["icon1"]["name"]!=""){
 	$icon1 = "icon1/".$intFile.$_FILES[icon1][name];					
move_uploaded_file($_FILES[icon1][tmp_name],"../".$icon1);
  				}else{
				$icon1='';
				}
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon2"]["name"]!=""){
 	$icon2 = "icon2/".$intFile.$_FILES[icon2][name];					
move_uploaded_file($_FILES[icon2][tmp_name],"../".$icon2);
  				}else{
				$icon2='';
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon3"]["name"]!=""){
 	$icon3 = "icon3/".$intFile.$_FILES[icon3][name];					
move_uploaded_file($_FILES[icon3][tmp_name],"../".$icon3);
  				}else{
				$icon3='';
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon4"]["name"]!=""){
 	$icon4 = "icon4/".$intFile.$_FILES[icon4][name];					
move_uploaded_file($_FILES[icon4][tmp_name],"../".$icon4);
  				}else{
				$icon4='';
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon5"]["name"]!=""){
 	 	$icon5 = "icon5/".$intFile.$_FILES[icon5][name];					
move_uploaded_file($_FILES[icon5][tmp_name],"../".$icon5);
  				}else{
				$icon5='';
				}																
				
 /*****/ 

		$sql = "INSERT INTO products set products_model = '".$_REQUEST[products_model]."',product_make = '".$_REQUEST[	product_make]."',product_title = '".$_REQUEST[ProductTitle]."',products_price = '".$_REQUEST[productprice]."',  products_date_added = '".time()."', Description= '".$_REQUEST[productSummary]."',  products_quantity_order_min = '".$_REQUEST[minorder]."', master_categories_id = '".$_REQUEST[productCat]."', products_status = '".$_REQUEST[productStatus]."', products_isFeatured = '".$_REQUEST[productFeatured]."',authorsummary = '".$_REQUEST[authorsummary]."',author = '".$_REQUEST[author]."',sibn = '".$_REQUEST[sibn]."',npage = '".$_REQUEST[npage]."',cover = '".$_REQUEST[cover]."',rarebooks = '".$_REQUEST[rarebooks]."',products_image ='".$filename."',products_image2 ='".$filename1."',products_image3 ='".$filename2."',dltime = '".$_REQUEST[dltime]."',stock = '".$_REQUEST[stock]."',brand = '".$_REQUEST[brand]."',mrpprice = '".$_REQUEST[mrpprice]."',shortdesc = '".$_REQUEST[shortdesc]."',specification = '".$_REQUEST[specification]."',icon1 ='".$icon1."',icon2 ='".$icon2."',icon3 ='".$icon3."',icon4 ='".$icon4."',icon5 ='".$icon5."',emdvedio='".$_REQUEST[emdvedio]."' "; 
		mysql_query($sql) or die(mysql_error());
 
 	 	 
 		//$Msg="<li>Article Successfully Addes";	
		  header("Location:home.php?PageURL=AddProduct&cid=$_REQUEST[productCat]&cname=$_REQUEST[cname]&intMSG=<li>Product Successfully Added");
	
}
 
?>
<link href="images/class.css" rel="stylesheet" type="text/css">
      <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script> 

<style type="text/css">
<!--
.style3 {color: #FF0000; font-weight: bold; }
-->
</style>
<br>
<table width="95%" border="0" cellpadding="3" cellspacing="0"  >
  <tr  > 
    <td bgcolor="#CCCCCC" class="headR" ><strong>Add Product </strong></td>
  </tr>
  <tr > 
    <form action="" method="post" enctype="multipart/form-data" name="frmArticle" id="frmArticle" onSubmit="javascript:return check()">
      <td class="tableBorderDarkGrey"> <table width="100%"  border="0" cellpadding="3" cellspacing="1"  class="text" >
          <?
	 if($Msg!="" or $_REQUEST[intMSG]!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" class="errortext"> 
              <?=$Msg?><?=$_REQUEST[intMSG]?>            </td>
          </tr>
          <? }?>
          <tr> 
            <td width="50%" align="center" ><table width="100%"  border="0" cellpadding="3" cellspacing="4" class="text">
              <tr>
                <td width="35%"><span class="style3">*</span><strong>Category Name :</strong></td>
                <td width="65%" align="left" valign="top"> <? 
 				if($_REQUEST[cid]==""){?>
                  <select name="productCat" id="select2" class="textbox">
                    <option value="" selected>Select</option>
                    <?
							$sql3="select * from categories where pid=0";
							$rs3=mysql_query($sql3);
							//cid, cname, pid, Childs, LevelFromRoot
							while ($row3 = mysql_fetch_array($rs3))
							{
							$AccumulatedNodes= array();
							$NodeLevel= array();
							$NodesToTraverse= array();
							$NodesExpire= array();
							
								
 								array_unshift($AccumulatedNodes, $row3[cid]);
								array_unshift($NodesToTraverse, $row3[cid]);
   								while(count($NodesToTraverse)>0)
								{
									$OpenNodeId=array_shift($NodesToTraverse);
									array_push($NodesExpire, $OpenNodeId);
									$query4="select * from categories where cid=$OpenNodeId";
									$res4=mysql_query($query4);
									$row4 = mysql_fetch_array($res4);
									if($row4[Childs]!="")
									{
										$Childs= array();
										$Childs=explode(',', $row4[Childs]);
										$NumChilds=count($Childs)-1;
										for($i=$NumChilds-1;$i>=0;$i--)
										{
 											array_unshift($AccumulatedNodes, $Childs[$i]);
											array_unshift($NodesToTraverse, $Childs[$i]);
										}
										unset($Childs);
									}
  								}
								$AccumulatedNodes = array_reverse($AccumulatedNodes, false);
								reset($NodesExpire);
								for($i=0;$i<count($NodesExpire);$i++)
								{
									$query5="select * from categories where cid=$NodesExpire[$i]";
									$res5=mysql_query($query5);
									$row5 = mysql_fetch_array($res5);
 									?>
                    <option value="<?=$row5[cid]?>" <? if($row5[cid]==$_REQUEST[productCat]){?>selected <? }?> >
                    <? for($j=0;$j<$row5[LevelFromRoot];$j++){ echo ">"; } ?>
                    <?=$row5[cname]?>
                    </option>
                    <?
								}
 							unset($AccumulatedNodes, $NodeLevel, $NodesToTraverse, $NodesExpire);
							}																									
							?>
                  </select>
				  <? }else{
				 $sql3="select * from categories where cid='".$_REQUEST[cid]."'";
				 $rs3=mysql_query($sql3) or die(mysql_error());
				$Ar3 = mysql_fetch_array($rs3);
				  	echo $Ar3[cname];
				  ?>
				  	<input name="productCat" type="hidden" value="<?=$_REQUEST[cid]?>">
				  <? }?>                 </td>
              </tr>
              
              
            </table>              </td>
            <td align="left"><table width="100%" border="0" cellpadding="3" cellspacing="4" class="text">
              <tr>
                <td align="left" valign="top"><span class="style3">* </span><strong> <span class="style3"> </span><strong>  Name</strong> :</strong></td>
                <td align="left" valign="top"><input name="ProductTitle" type="text"    class="textbox" id="ProductTitle" value="<?=$_REQUEST[ProductTitle]?>" size="30" maxlength="255" /></td>
              </tr>
            </table></td>
          </tr>
		    
		    <tr align="center"  >
            <td colspan="2"> <table width="100%" border="0" cellspacing="3" cellpadding="2">
              <tr>
                <th scope="row"><table width="100%" border="0" cellpadding="3" cellspacing="4" class="text">
                  <tr>
                    <td align="left" valign="top"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Make </strong> :</strong></td>
                    <td align="left" valign="top"><input name="product_make" type="text"    class="textbox" id="product_make" value="<?=$_REQUEST[product_make]?>" size="30" maxlength="255" /></td>
                  </tr>
                </table></th>
                <td><table width="100%" border="0" cellpadding="3" cellspacing="4" class="text">
                  <tr>
                    <td align="left" valign="top"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Model Name</strong> :</strong></td>
                    <td align="left" valign="top"><input name="products_model" type="text"    class="textbox" id="products_model" value="<?=$_REQUEST[products_model]?>" size="30" maxlength="255" /></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="center"  >
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr align="center"  >
            <td colspan="2"><span class="style3">* </span><strong>Product Detail </strong></td>
          </tr>          <tr align="center" >
            <td colspan="2">&nbsp; </td>
            </tr>          
          
           <tr  >
            <td align="right"><strong>Product toys Image 1 : </strong></td>
            <td><input name="ProductFile" type="file"   id="ProductFile"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Product toys Image 2 : </strong></td>
            <td><input name="articleFile2" type="file" id="articleFile2" /></td>
          </tr>
          <tr  >
            <td align="right"><strong>Product toys Image 3 : </strong></td>
            <td><input name="articleFile3" type="file" id="articleFile3" /></td>
          </tr>
   
          <tr  >
            <td align="right"><strong>icon1</strong></td>
            <td><input name="icon1" type="file" id="icon1" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
      
          <tr  >
            <td align="right"><strong>icon2</strong></td>
            <td><input name="icon2" type="file" id="icon2" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
	 
          <tr  >
            <td align="right"><strong>icon3</strong></td>
            <td><input name="icon3" type="file" id="icon3" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
	 
          <tr  >
            <td align="right"><strong>icon4</strong></td>
            <td><input name="icon4" type="file" id="icon4" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
		 
          <tr  >
            <td align="right"><strong>icon5</strong></td>
            <td><input name="icon5" type="file" id="icon5" />
              image size (width:45,/\Height:45px;) </td>
          </tr>

          <tr  >
            <td align="right"><strong>SKU</strong></td>
            <td><input name="sibn" type="text" id="sibn" /></td>
          </tr>
          
          <tr  >
            <td align="right"><strong>MRP Price</strong> </td>
            <td><input name="productprice" type="text" id="productprice" size="10" value="<?=$_REQUEST[productprice]?>"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Brand Name</strong></td>
            <td><select name="brand" size="1" class="textfield3" id="brand">
              <!-- ************************ Start  Code for select category ***************-->
              <option  value="">Select Brand</option>
              <? $Sql= "select * from brand ";
 			$Result = mysql_query($Sql) or die(mysql_error());
		while($ArrayC = mysql_fetch_array($Result)){
	  ?>
              <option value="<?=$ArrayC[cid]?>"  style="font-size:12px;" <? if($ArrayC[cid]==$_REQUEST[brand]){ echo "selected"; }else{?> <? } ?>>
              <?=$ArrayC[name]?>
              </option>
              <? }?>
            </select></td>
          </tr>
          <tr  >
            <td align="right"><strong>Stock</strong></td>
            <td><input name="stock" type="radio" value="1" <? if ($_REQUEST[stock]=="1") {?> checked="checked" <? } ?> />
              <strong> In Stock</strong>
              <input name="stock" type="radio" value="0" <? if ($_REQUEST[stock]=="0") {?> checked="checked" <? } ?> />
              <strong>Out of Stock </strong></td>
          </tr>
          <tr  >
            <td align="right"><strong>Delivery Time</strong></td>
            <td><input name="dltime" type="text" id="dltime" value="<?=$_REQUEST[dltime]?>" style="width:400px;" /></td>
          </tr>
      
          
   <tr align="center"  >
		      <td colspan="2" align="left"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><strong>Prodyduct Short Detail </strong></td>
              </tr>
              <tr>
                <td colspan="2" align="center"> <textarea id="shortdesc" name="shortdesc" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[shortdesc]?></textarea></td>
              </tr>
			  <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'shortdesc',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
              <tr>
                <td colspan="2" align="center"><span class="style3"> </span> 
                   <span class="style3">* </span><strong> About Product : </strong> </td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                <textarea id="productSummary" name="productSummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[productSummary]?></textarea></td>
                </tr> <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'productSummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
	      </tr>
		  <tr align="center"  >
		      <td colspan="2" align="left"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><span class="style3">* </span><strong> Product feature  : </strong></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                <textarea id="authorsummary" name="authorsummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[authorsummary]?></textarea></td>
                </tr> <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'authorsummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
	      </tr>
		  <tr align="center"  >
		      <td colspan="2" align="left"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><span class="style3">* </span><strong> Product specification  : </strong></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                <textarea id="specification" name="specification" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[specification]?></textarea></td>
                </tr><?php /*?> <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'specification',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script><?php */?>
            </table></td>
	      </tr>
          <tr  >
            <td align="right"><strong>Embed Code</strong></td>
            <td><textarea name="emdvedio" id="emdvedio"></textarea></td>
          </tr>
          <tr  >
            <td align="right"><strong> View Product  : </strong></td>
            <td><input name="productStatus" type="checkbox" class="textbox" id="productStatus" value="1" <? if($_REQUEST[productStatus]==1){?>checked <? }?>></td>
          </tr>
                    
          <?php /*?><tr  >
            <td align="right"><strong>Combos Mantra  Product :</strong></td>
            <td><input name="productFeatured" type="checkbox" class="textbox" id="productFeatured" value="1" <? if($_REQUEST[productFeatured]==1){?>checked <? }?>></td>
          </tr><?php */?>
          <tr align="center"> 
            <td colspan="2">
			
			<input name="btnBack2" type="button" id="btnBack3" value="   &lt;&lt; Back   "  class="button1" onClick="javascript:location.href='home.php?PageURL=ManageCategory&catid=<?=$_REQUEST[cid]?>&cname=<?=$Ar3[cname]?>'">
			      <input name="btnSubmit" type="submit" id="btnSubmit" value="Add Product Now" class="button1"></td>
          </tr>
        </table></td>
    </form>
  </tr>
</table>
 	<script language="javascript">
	function check()
	{
		if(document.frmArticle.productCat.value=="")	
			{
				alert("Please Select Product Category");
				document.frmArticle.productCat.focus();
				return false;
			}
  		if(document.frmArticle.ProductTitle.value=="")	
			{
				alert("Please Enter Product Name");
				document.frmArticle.ProductTitle.focus();
				return false;
			}		
 		
	}
	</script>