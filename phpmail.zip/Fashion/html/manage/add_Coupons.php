<?



if($_REQUEST[ndn]==1)



{



	$products=$_REQUEST[productsSelectedValues]; 



		$Query = "insert into discount_coupons_to_customers  set cuname = '".$_REQUEST[newstitle]."',cp_id = '".$_REQUEST[cp_id]."',



		stdate = '".$_REQUEST['MyDate']."',enddate = '".$_REQUEST['checkout_date']."',



		product = '".$products."',dis_cou = '".$_REQUEST[dis_cou]."'";



 $Result = mysql_query($Query) or die(mysql_error());



 



	 		 header("Location:home.php?PageURL=managecoupan");



		 }



		  



 



?>



 <script language="Javascript">



function productsAdd(){



	for(i=0;i<document.form1.products.length;i++){



	if(document.form1.products.options[i].selected){



		val=document.form1.products.options[i].value;



		name=document.form1.products.options[i].text;







		count=document.form1.productsSelected.length



		for(j=0;j<document.form1.productsSelected.length;j++){



			text=document.form1.productsSelected.options[j].text;







			//if(text>name){



			//count=j;



			//break;



			//}



		}



		len=document.form1.productsSelected.length



		curname="- "



		curval="0"



		document.form1.productsSelected.options[len] = new Option(curname,curval);







		for (j=len;j>count;j--){



			curval=document.form1.productsSelected.options[j-1].value;



			curname=document.form1.productsSelected.options[j-1].text;







		 	document.form1.productsSelected.options[j].text=curname



			document.form1.productsSelected.options[j].value=curval



			}



		document.form1.productsSelected.options[count].text = name



		document.form1.productsSelected.options[count].value=val



		document.form1.products.options[i]=null;



		i--;







	}



	}







}



function productsReturn(){



	for(i=0;i<document.form1.productsSelected.length;i++){



	//alert(form1.city.length);



	if(document.form1.productsSelected.options[i].selected){



		val=document.form1.productsSelected.options[i].value;



		name=document.form1.productsSelected.options[i].text;



		//alert(name);







		count=document.form1.products.length



		//alert(count);



		for(j=0;j<document.form1.products.length;j++){



			text=document.form1.products.options[j].text







			if(text>name){



			count=j;



			break;



			}



		}



		len=document.form1.products.length



		//alert(len);



		curname="- "



		curval="0"



		document.form1.products.options[len] = new Option(curname,curval);







		for (j=len;j>count;j--){



			curval=document.form1.products.options[j-1].value;



			curname=document.form1.products.options[j-1].text;







		 	document.form1.products.options[j].text=curname



			document.form1.products.options[j].value=curval



			//alert("sdfsdfsdfsdf"+curval);



			}



		document.form1.products.options[count].text = name



		document.form1.products.options[count].value=val



		document.form1.productsSelected.options[i]=null;



		i--;



	}



	}







}



function productsCheck(){



 	for(i=0;i<document.form1.productsSelected.length;i++){



	document.form1.productsSelected.options[i].selected=true;



    document.form1.productsSelected.options[i].value;



    }







   var txtSelectedValuesObj = document.getElementById('productsSelectedValues');



   var selectedArray = new Array();



   var selObj = document.getElementById('productsSelected');



   var i;



   var count = 0;



   for (i=0; i<selObj.options.length; i++) {



    if (selObj.options[i].selected) {



      selectedArray[count] = selObj.options[i].value;



      count++;



    }



   }



   txtSelectedValuesObj.value = selectedArray;



  }



</script>



<script src="calender/js/jscal2.js"></script>



    <script src="calender/js/lang/en.js"></script>



    <link rel="stylesheet" type="text/css" href="calender/css/jscal2.css" />



    <link rel="stylesheet" type="text/css" href="calender/css/border-radius.css" />



    <link rel="stylesheet" type="text/css" href="calender/css/steel/steel.css" />



<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">







<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1" onSubmit="return validate()">



  <tr height="26" class="headM txtcol">



    <td width="78%" align="center"  >Add  </td>



    <td width="22%"> <a href="home.php?PageURL=managecoupan" class="link-top">Back</a> </td>



  </tr>



  <tr>



       <td colspan="2"><table width="100%"  border="0" cellspacing="2" cellpadding="0" >



           <tr>



             <td width="46%" height="30"  align="right">  Title </td>



             <td width="1%" align="center">:</td>



            <td width="53%"> <input name="newstitle" type="text" id="newstitle" value="">            </td>

         </tr>



           <tr>



             <td height="30"  align="right">Promo Code:</td>



             <td align="center">&nbsp;</td>



             <td><input type="text" name="cp_id" id="cp_id" /></td>

           </tr>



           <tr>



             <td height="30"  align="right">Discount On Product</td>



             <td align="center">:</td>



             <td><input type="text" name="dis_cou" id="dis_cou" />

             %</td>

           </tr>







          

          <tr>



             <td colspan="3" align="center">&nbsp; </td>

          </tr>



          <tr>



            <td align="right">&nbsp;</td>



            <td colspan="2">



              <input name="btnchange" type="submit" id="btnchange" value="Add" class="btnstyle">



            <input name="ndn" type="hidden" id="ndn" value="1">            </td>

          </tr>



      </table></td>



  </tr>



  </form>



</table>



   <script type="text/javascript">//<![CDATA[



      Calendar.setup({



        inputField : "MyDate",



        trigger    : "f_btn1",



        onSelect   : function() { this.hide() },



        showTime   : 24,



        dateFormat : "%Y-%m-%d"



      });



	  



	  Calendar.setup({



        inputField : "checkout_date",



        trigger    : "f_btn2",



        onSelect   : function() { this.hide() },



        showTime   : 24,



        dateFormat : "%Y-%m-%d"



      });



    //]]></script>



    