<?
$BannerSql = "select * from ad_banner where adid=".$_REQUEST[adid]."";
$BannerRes = mysql_query($BannerSql) or die("error:".mysql_error());
$BannerRow = mysql_fetch_array($BannerRes);
?>
<style type="text/css">
<!--
.style11 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
 <table width="99%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#3399CC" celspacing="1">
  <tr> 
    <td bordercolor="#FFFFFF"><table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
        <tr bgcolor="#666666" > 
          <td colspan="2"  ><span class="style11">Banner 
            Details for  
            </span></td>
        </tr>
        
        <tr align="center" bordercolor="#D8D8D8" bgcolor="#F5F5F5"> 
          <td colspan="2"> 
           
            <img  src="../ad_pic/<?=$BannerRow[adfilevalue]?>"  border=0>                    </td>
        </tr>
        
        <?php /*?><tr bordercolor="#D8D8D8" bgcolor="#F5F5F5">
          <td align="right">URL://</td>
          <td align="left"><?=$BannerRow[bannerurl]?></td>
        </tr><?php */?>
        <tr bordercolor="#D8D8D8" bgcolor="#F5F5F5"> 
          <td width="50%" align="right">Ad Status :</td>
          <td width="406" align="left"> 
            <?=$BannerRow[adstatus]?>          </td>
        </tr>
        
        <tr align="center" bordercolor="#D8D8D8" bgcolor="#F5F5F5"> 
          <td colspan="2"><input name="Submit2" type="button" class="btnstyle" value="  &lt;&lt; BACK    " onClick="location.href='home.php?PageURL=banner_show'"></td>
        </tr>
    </table> </td>
  </tr>
 
</table>
