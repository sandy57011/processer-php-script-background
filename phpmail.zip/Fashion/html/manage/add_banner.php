<script language="javascript">
function open1(a)
	{	
		adtype=a.value;
		if(adtype=="jscript")
			{
			file="home.php?PageURL=add_banner_jscript&adtype="+adtype;
			window.location.href=file;
			}
		else
			{
			file="home.php?PageURL=add_banner_pic&adtype="+adtype;
			window.location.href=file;	
			}
	}		
</script>
 
 <table width="99%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#3399CC" celspacing="1">
 <form name="add_banner" action="" method="post">
  <tr> 
    <td bordercolor="#FFFFFF"><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
          <tr bgcolor="#666666"> 
            <td colspan="2" ><span class="style7"><strong><font color="#FFFFFF">Select 
              Ad Type</font></strong></span></td>
          </tr>
          <tr> 
            <td width="51%" height="50" align="right" bgcolor="#F5F5F5"> Ad Type: 
            </td>
            <td width="49%" bgcolor="#F5F5F5"> <select name="ad_type" id="ad_type" onChange="javascript:open1(this)">
                <option value = "0" selected>---Select One---</option>
                <option value = "flash">Flash</option>
                <option value="image">Image</option>
                <option value="jscript">Java Script</option>
              </select> </td>
          </tr>
          <tr align="center"> 
            <td height="50" colspan="2" bgcolor="#F5F5F5"><input name="Submit2" type="button" class="btnstyle" value="  &lt;&lt; BACK    " onClick="location.href='home.php?PageURL=banner_show'"></td>
          </tr>
        </table> </td>
  </tr>
</form>
</table>
