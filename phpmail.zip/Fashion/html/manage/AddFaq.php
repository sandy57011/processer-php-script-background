<?
if($_REQUEST[btnSubmit])
	{
	$SelQuery = "select * from faq where faq_question	 = '$_REQUEST[txtQuestion]'";
	$SelResult=mysql_query($SelQuery) or die(mysql_error());
	if(mysql_num_rows($SelResult)>0)
		{
		$ERR=1;
		}else{
		///////////////////////////////////////////////////////////////////////////////
		if($_FILES[faqimages][name])
		{
		$intFlag=0;
		$ext=array("exe", "sh", "pl", "php", "cgi", "asp", "aspx");
		$articleFile=$_FILES[faqimages][name];
  		$path_parts = pathinfo($articleFile);
				if(in_array($path_parts["extension"], $ext))
				{
					$intFlag=1;
					$errFile.=$articleFile.", <br>";
				}else{
				$addFile="Faq_file/".mt_rand(1,10000)."_".$articleFile;
						copy($HTTP_POST_FILES['faqimages']['tmp_name'],$addFile);	
				}
		}
		/////////////////////////////////////////////////////////////////////////////////
		$Query = "INSERT INTO `faq` (`faq_id`, `faq_question`, `faq_ans`, faq_image) VALUES ('', '$_REQUEST[txtQuestion]', '$_REQUEST[txtAns]', '$addFile')";
		$Result=mysql_query($Query) or die(mysql_error());
		$Msg=1;
		}
	}
?>

<table width="70%"  border="1" align="center" cellpadding="3" cellspacing="0" bordercolor="#B4BCC7">
  <tr>
    <td bgcolor="#CCCCCC" class="headR"> <strong>Add FAQ</strong>  </td>
  </tr>
  <tr>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return validate(this)">
      <td><table width="100%"  border="0" cellspacing="0" cellpadding="3">
          <?
	  if($Msg!="" or $ERR!="")
	  	{
	  ?>
          <tr align="center">
            <td colspan="2">
              <?
		  if($Msg==1){	
		  ?>
              <font color="#006633"> FAQ added successfully.</font>
              <? }elseif($ERR==1){?>
              <font color="#FF0000"> Question already exists.</font>
              <? }?>
            </td>
          </tr>
          <tr>
            <? }?>
            <td width="50%" align="right"><font class="bodybold1"><strong>Question:</strong></font></td>
            <td><textarea name="txtQuestion" cols="50" rows="5" id="txtQuestion"></textarea></td>
          </tr>
          <tr>
            <td width="50%" align="right"><font class="bodybold1"><strong>Answer:</strong></font></td>
            <td><textarea name="txtAns" cols="60" rows="7" id="txtAns"></textarea></td>
          </tr>
          <tr align="center">
            <td align="right" nowrap><strong>Faq Image:</strong></td>
            <td align="left"><input name="faqimages" type="file" id="faqimages"></td>
          </tr>
          <tr align="center">
            <td colspan="2"><input name="btnBack" type="button" id="btnBack" value="Back"  class="button1" onClick="javascript:location.href='home.php?PageURL=managefaq'">&nbsp;<input name="btnSubmit" class="button1" type="submit" id="btnSubmit" value="   ADD   "  ></td>
          </tr>
      </table></td>
    </form>
  </tr>
</table>
<script language="JavaScript" type="text/JavaScript">
function validate(id)
	{
	if(id.txtQuestion.value=="")
		{
		alert("Please enter the question.");
		id.txtQuestion.focus();
		return false;
		}
	if(id.txtAns.value=="")	
		{
		alert("Please enter the answer.");
		id.txtAns.focus();
		return false;
		}
	return true;	
	}

</script>
