<?
 if($_REQUEST[btnSubmit]){
//.exe, .sh, .pl, .php, .cgi, .asp, .aspx
$other="";
   for($n=0;$n<count($_REQUEST[other]);$n++)
  {
    if($n>0)
   $other.=", ".$_REQUEST[other][$n];
   else
   $other.=$_REQUEST[other][$n];
   }
$intFile=mt_rand();
if($_FILES["articleFile"]["name"]!=""){
if($_REQUEST[ExistImage]!=""){
@unlink($_REQUEST[ExistImage]);
}
$filename1 = "product_file/".$intFile.$_FILES[articleFile][name];					
move_uploaded_file($_FILES[articleFile][tmp_name],"../".$filename1);
}
else
{
$filename1=$_REQUEST[ExistImage];
}
if($_FILES["articleFile2"]["name"]!="")
{
 	
	if($_REQUEST[ExistImage2]!=""){
 							@unlink($_REQUEST[ExistImage2]);
  						}
	$filename2 = "product_file/".$intFile.$_FILES[articleFile2][name];					
move_uploaded_file($_FILES[articleFile2][tmp_name],"../".$filename2);
  				}else{
				$filename2=$_REQUEST[ExistImage2];
				}
	if($_FILES["articleFile3"]["name"]!=""){
 						if($_REQUEST[ExistImage3]!=""){
 							@unlink($_REQUEST[ExistImage3]);
  						}
	$filename3 = "product_file/".$intFile.$_FILES[articleFile3][name];					
move_uploaded_file($_FILES[articleFile3][tmp_name],"../".$filename3);
  				}else{
				$filename3=$_REQUEST[ExistImage3];
				}
	if($_FILES["articleFile4"]["name"]!=""){
 						if($_REQUEST[ExistImage4]!=""){
 							@unlink($_REQUEST[ExistImage4]);
  						}
	$filename4 = "product_file/".$intFile.$_FILES[articleFile4][name];					
move_uploaded_file($_FILES[articleFile4][tmp_name],"../".$filename4);
  				}else{
				$filename4=$_REQUEST[ExistImage4];
				}
 if($_FILES["articleFile5"]["name"]!=""){
 						if($_REQUEST[ExistImage5]!=""){
 							@unlink($_REQUEST[ExistImage5]);
  						}
	$filename5 = "product_file/".$intFile.$_FILES[articleFile5][name];					
move_uploaded_file($_FILES[articleFile5][tmp_name],"../".$filename5);
  				}else{
				$filename5=$_REQUEST[ExistImage5];
				}
 
 
 /**icon image code**/
 $intFile=mt_rand();
	 if($_FILES["icon1"]["name"]!=""){
 						if($_REQUEST[Existicon1]!=""){
 							@unlink($_REQUEST[Existicon1]);
  						}
	$icon1 = "icon1/".$intFile.$_FILES[icon1][name];					
move_uploaded_file($_FILES[icon1][tmp_name],"../".$icon1);
  				}else{
				$icon1=$_REQUEST[Existicon1];
				}
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon2"]["name"]!=""){
 						if($_REQUEST[Existicon2]!=""){
 							@unlink($_REQUEST[Existicon2]);
  						}
	$icon2 = "icon2/".$intFile.$_FILES[icon2][name];					
move_uploaded_file($_FILES[icon2][tmp_name],"../".$icon2);
  				}else{
				$icon2=$_REQUEST[Existicon2];
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon3"]["name"]!=""){
 						if($_REQUEST[Existicon3]!=""){
 							@unlink($_REQUEST[Existicon3]);
  						}
	$icon3 = "icon3/".$intFile.$_FILES[icon3][name];					
move_uploaded_file($_FILES[icon3][tmp_name],"../".$icon3);
  				}else{
				$icon3=$_REQUEST[Existicon3];
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon4"]["name"]!=""){
 						if($_REQUEST[Existicon4]!=""){
 							@unlink($_REQUEST[Existicon4]);
  						}
	$icon4 = "icon4/".$intFile.$_FILES[icon4][name];					
move_uploaded_file($_FILES[icon4][tmp_name],"../".$icon4);
  				}else{
				$icon4=$_REQUEST[Existicon4];
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon5"]["name"]!=""){
 						if($_REQUEST[Existicon5]!=""){
 							@unlink($_REQUEST[Existicon5]);
  						}
	$icon5 = "icon5/".$intFile.$_FILES[icon5][name];					
move_uploaded_file($_FILES[icon5][tmp_name],"../".$icon5);
  				}else{
				$icon5=$_REQUEST[Existicon5];
				}																
				
 /*****/
 $product_make = $_POST[product_make];
 foreach($product_make as $tt){
 if($tt!="") { 
 	$product_makefav .=",".$tt;
	}
 }
$product_makefav = substr($product_makefav,1);


$input_url = $_REQUEST[input_url];
if($input_url=="") {
$input_url = "detail-itid-".$_REQUEST[ProductID]."-catid-".ucwords($_REQUEST[productCat]);
}
//exit();
if($_REQUEST[weightUnit]=="") {
$weightUnitins = $_REQUEST[customweightUnit];
} else {
$weightUnitins = $_REQUEST[weightUnit];
}

/******************   Product Option Array Value Start    *****************/
$productoptionid = $_POST['productoptionid'];
$optionIdArray = "";
$product_option_field_array = "";
for($i=0;$i<sizeof($productoptionid);$i++) {
 
$posttext = "optionarr".$productoptionid[$i];

$posttextnn = $_POST[$posttext];

if($posttextnn!="") {
$optionIdArray .=",".$productoptionid[$i];
$product_option_field_array .=",".$posttextnn;
}
}
$optionIdArray = substr($optionIdArray,1); 

$gotidarray = explode(",",$optionIdArray);
sort($gotidarray);
foreach($gotidarray as $key => $value) {
		$optionvalueidtt11id = $value;
		if($optionvalueidtt11id!="") {
		$searchoptionid11id .=",".$optionvalueidtt11id;		
		}
	}
$searchoptionidsubstr11id = substr($searchoptionid11id,1);	
$optionIdArraynew = $searchoptionidsubstr11id;



$product_option_field_array = substr($product_option_field_array,1);

$gotarray = explode(",",$product_option_field_array);
sort($gotarray);
foreach($gotarray as $key => $value) {
		$optionvalueidtt11 = $value;
		if($optionvalueidtt11!="") {
		$searchoptionid11 .=",".$optionvalueidtt11;		
		}
	}
$searchoptionidsubstr11 = substr($searchoptionid11,1);	
$product_option_field_arraynew = $searchoptionidsubstr11;

/******************   Product Option Array Value End    ******************/
				//products_isFeatured = '".$_REQUEST[productFeatured]."',
if($_REQUEST['multioption']!='1') {				
	    $sql = "update products set input_url = '".$_REQUEST[input_url]."', Seo_Project_Title = '".$_REQUEST[Seo_Project_Title]."', Seo_Project_Description = '".$_REQUEST[Seo_Project_Description]."',  Seo_Project_Keyword = '".$_REQUEST[Seo_Project_Keyword]."', products_model = '".$_REQUEST[products_model]."',product_make = '".$product_makefav."',product_title = '".addslashes($_REQUEST[ProductTitle])."',product_title1 = '".addslashes($_REQUEST[ProductTitle1])."', icon1 ='".$icon1."',icon2 ='".$icon2."',icon3 ='".$icon3."',icon4 ='".$icon4."',icon5 ='".$icon5."',
	  products_image ='".$filename1."',products_image2='".$filename2."',products_image3='".$filename3."',products_image4='".$filename4."',products_image5='".$filename5."',products_price = '".$_REQUEST[productprice]."',products_oldprice = '".$_REQUEST[productOldPrice]."', Description = '".$_REQUEST[productSummary]."', products_date_added = '".time()."', products_quantity_order_min = '".$_REQUEST[minorder]."', customerdiscount = '".$_REQUEST[customerdiscount]."',discountpercentage = '".$_REQUEST[discount]."', master_categories_id = '".$_REQUEST[productCat]."', products_status = '".$_REQUEST[productStatus]."', products_offer = '".$_REQUEST[productOffer]."',authorsummary = '".$_REQUEST[authorsummary]."',author = '".$_REQUEST[author]."',sibn = '".$_REQUEST[sibn]."',npage = '".$_REQUEST[npage]."',cover = '".$_REQUEST[cover]."',rarebooks = '".$_REQUEST[rarebooks]."',dltime = '".$_REQUEST[dltime]."',stock = '".$_REQUEST[stock]."',brand = '".$_REQUEST[brand]."',mrpprice = '".$_REQUEST[mrpprice]."',shortdesc = '".$_REQUEST[shortdesc]."',specification = '".$_REQUEST[specification]."',emdvedio='".$_REQUEST[emdvedio]."', weight_qty='".$_REQUEST[productWeight]."', weight_unit='".$weightUnitins."', product_option_field_array = '".$product_option_field_arraynew."', product_option_ids = '".$optionIdArraynew."', freeproduct = '".addslashes($_REQUEST['freeproduct'])."' where products_id = '".$_REQUEST[ProductID]."'"; 
		mysql_query($sql) or die(mysql_error());
}
		
if($_REQUEST['multioption']=='1') {
$sql = "insert into products set input_url = '".$_REQUEST[input_url]."', Seo_Project_Title = '".$_REQUEST[Seo_Project_Title]."', Seo_Project_Description = '".$_REQUEST[Seo_Project_Description]."',  Seo_Project_Keyword = '".$_REQUEST[Seo_Project_Keyword]."', products_model = '".$_REQUEST[products_model]."',product_make = '".$product_makefav."',product_title = '".addslashes($_REQUEST[ProductTitle])."',product_title1 = '".addslashes($_REQUEST[ProductTitle1])."', icon1 ='".$icon1."',icon2 ='".$icon2."',icon3 ='".$icon3."',icon4 ='".$icon4."',icon5 ='".$icon5."',
	  products_image ='".$filename1."',products_image2='".$filename2."',products_image3='".$filename3."',products_image4='".$filename4."',products_image5='".$filename5."',products_price = '".$_REQUEST[productprice]."',products_oldprice = '".$_REQUEST[productOldPrice]."', Description = '".$_REQUEST[productSummary]."', products_date_added = '".time()."', products_quantity_order_min = '".$_REQUEST[minorder]."', customerdiscount = '".$_REQUEST[customerdiscount]."',discountpercentage = '".$_REQUEST[discount]."', master_categories_id = '".$_REQUEST[productCat1]."', products_status = '".$_REQUEST[productStatus]."', products_offer = '".$_REQUEST[productOffer]."',authorsummary = '".$_REQUEST[authorsummary]."',author = '".$_REQUEST[author]."',sibn = '".$_REQUEST[sibn]."',npage = '".$_REQUEST[npage]."',cover = '".$_REQUEST[cover]."',rarebooks = '".$_REQUEST[rarebooks]."',dltime = '".$_REQUEST[dltime]."',stock = '".$_REQUEST[stock]."',brand = '".$_REQUEST[brand1]."',mrpprice = '".$_REQUEST[mrpprice]."',shortdesc = '".$_REQUEST[shortdesc]."',specification = '".$_REQUEST[specification]."',emdvedio='".$_REQUEST[emdvedio]."', weight_qty='".$_REQUEST[productWeight]."', weight_unit='".$weightUnitins."', product_option_field_array = '".$product_option_field_arraynew."', product_option_ids = '".$optionIdArraynew."', p_id = '".$_REQUEST[ProductID]."', freeproduct = '".addslashes($_REQUEST['freeproduct'])."'"; 
		mysql_query($sql) or die(mysql_error());
}		
		$articleID=$_REQUEST[ProductID];
 	 		 
		  header("Location:home.php?PageURL=EditProduct&ProductID=$_REQUEST[ProductID]&catid=$_REQUEST[productCat]&cname=$_REQUEST[cname]&intMSG=<li>Product Successfully Updated&articleID=".$_REQUEST[articleID]);
	
	 
}
  $SQL=mysql_query("select * from products where products_id='".$_REQUEST[ProductID]."'") or die(mysql_error());
 $myRows=mysql_fetch_array($SQL);
 

?>
<link href="images/class.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
.style3 {color: #FF0000; font-weight: bold; }
-->
</style>
<br>
     <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script> 
<script language="javascript" type="text/javascript">
function validate()
    { 
		//alert();
        doc =document.frmArticle;
		var productCat = doc.productCat.value;
		var ProductTitle = doc.ProductTitle.value;
		var brand = doc.brand.value;
		var shortdesc = doc.shortdesc.value;
		var authorsummary = doc.authorsummary.value;
		var specification = doc.specification.value;
        if(productCat=="")
        {
        alert('Please Select Category');
        doc.productCat.focus();
        return false;
        }
		if(ProductTitle=="")
        {
        alert('Please Enter Product Name');
        doc.ProductTitle.focus();
        return false;
        }
		if(brand=="")
        {
        alert('Please Select Brand');
        doc.brand.focus();
        return false;
        } 
		if(shortdesc=="")
        {
        alert('Please Enter Product Short Desc');
        doc.shortdesc.focus();
        return false;
        }
		if(authorsummary=="")
        {
        alert('Please Enter Product feature');
        doc.authorsummary.focus();
        return false;
        } 
		if(specification=="")
        {
        alert('Please Enter Product specification');
        doc.specification.focus();
        return false;
        }   
    }
</script>
<table width="100%" border="0" cellpadding="0" cellspacing="0"  >
  
  <tr > 
    <form action="" method="post" enctype="multipart/form-data" name="frmArticle" id="frmArticle" onSubmit="return validate()">
      <td class="tableBorderDarkGrey"> <h1>Add Similar Product</h1>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0"  class="text" >
          <?
	 if($Msg!="" or $_REQUEST[intMSG]!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" class="errortext"> 
              <?=$Msg?><?=$_REQUEST[intMSG]?>            </td>
          </tr>
          <? }?>
          
          <tr>
            <td colspan="2">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tbl1">
  <tr>
    <th width="21%" align="right"><span class="style3">*</span><strong>Category Name :</strong></th>
            <th width="79%" align="left"><select name="productCat" id="select2" class="selbox" disabled>
                    <option value="" selected>Select</option>
                    <?
							$sql3="select * from categories where pid=0";
							$rs3=mysql_query($sql3);
							//cid, cname, pid, Childs, LevelFromRoot
							while ($row3 = mysql_fetch_array($rs3))
							{
							$AccumulatedNodes= array();
							$NodeLevel= array();
							$NodesToTraverse= array();
							$NodesExpire= array();
							
								
 								array_unshift($AccumulatedNodes, $row3[cid]);
								array_unshift($NodesToTraverse, $row3[cid]);
   								while(count($NodesToTraverse)>0)
								{
									$OpenNodeId=array_shift($NodesToTraverse);
									array_push($NodesExpire, $OpenNodeId);
									$query4="select * from categories where cid=$OpenNodeId";
									$res4=mysql_query($query4);
									$row4 = mysql_fetch_array($res4);
									if($row4[Childs]!="")
									{
										$Childs= array();
										$Childs=explode(',', $row4[Childs]);
										$NumChilds=count($Childs)-1;
										for($i=$NumChilds-1;$i>=0;$i--)
										{
 											array_unshift($AccumulatedNodes, $Childs[$i]);
											array_unshift($NodesToTraverse, $Childs[$i]);
										}
										unset($Childs);
									}
  								}
								$AccumulatedNodes = array_reverse($AccumulatedNodes, false);
								reset($NodesExpire);
								for($i=0;$i<count($NodesExpire);$i++)
								{
									$query5="select * from categories where cid=$NodesExpire[$i]";
									$res5=mysql_query($query5);
									$row5 = mysql_fetch_array($res5);
 									?>
                    <option value="<?=$row5[cid]?>" <? if($row5[cid]==$myRows[master_categories_id]){?>selected <? }?> >
                    <? for($j=0;$j<$row5[LevelFromRoot];$j++){ echo ">"; } ?>
                    <?=stripslashes($row5[cname])?>
                    </option>
                    
                    <?
								}
 							unset($AccumulatedNodes, $NodeLevel, $NodesToTraverse, $NodesExpire);
							}																									
							?>
            </select></th>
            <input type="hidden" name="productCat1" id="productCat1" value="<?php echo $myRows[master_categories_id]; ?>">
          </tr>
          <tr>
            <td align="right"><span class="style3">* </span><strong> Name :</strong></td>
            <td><input name="ProductTitle" type="text" class="txtbox1" id="ProductTitle" value="<?=stripslashes($myRows[product_title])?>" size="30" maxlength="255" readonly="readonly"/></td>
          </tr>
          <tr>
            <td align="right"><span class="style3">* </span><strong> Title :</strong></td>
            <td><input name="ProductTitle1" type="text" class="txtbox1" id="ProductTitle1" value="<?=stripslashes($myRows[product_title1])?>" size="30" maxlength="255" /></td>
          </tr>
          <?php /*?><tr>
            <td align="right"><strong> <span class="style3"> </span>Flavour:</strong></td>
            <td><select name="product_make[]" size="10" class="selbox" id="product_make" multiple="multiple" style="height:60px;">
              <!-- ************************ Start  Code for select category ***************-->
              <option  value="">Select flavour</option>
              <? $makeSql= "select * from flavour ORDER BY name";
 			$makeResult = mysql_query($makeSql) or die(mysql_error());
		while($makeArrayC = mysql_fetch_array($makeResult)){
	  ?>
              <option value="<?=$makeArrayC[cid]?>"  style="font-size:12px;" <? if($makeArrayC[cid]==$myRows[product_make]){ echo "selected"; }else{?> <? } ?>>
              <?=$makeArrayC[name]?>
              </option>
              <? }?>
            </select></td>
          </tr><?php */?>
          <?php /*?><tr>
            <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Model Name</strong> :</strong></td>
            <td><select name="products_model" size="1" class="textfield3" id="products_model">
              <!-- ************************ Start  Code for select category ***************-->
              <option  value="">Select model</option>
              <? $modelSql= "select * from model  ";
 			$modelResult = mysql_query($modelSql) or die(mysql_error());
		while($modelArrayC = mysql_fetch_array($modelResult)){
	  ?>
              <option value="<?=$modelArrayC[cid]?>"  style="font-size:12px;" <? if($modelArrayC[cid]==$myRows[products_model]){ echo "selected"; }else{?> <? } ?>>
              <?=$modelArrayC[name]?>
              </option>
              <? }?>
            </select></td>
          </tr><?php */?>
          <tr>
            <td align="right"><span class="style3">* </span><strong>Brand Name : </strong></td>
            <td><select name="brand" size="1" class="selbox" id="brand" disabled>
                    <!-- ************************ Start  Code for select category ***************-->
                    <option  value="">Select Brand</option>
 		   
                      <? $Sql= "select * from brand ";
 			$Result = mysql_query($Sql) or die(mysql_error());
		while($ArrayC = mysql_fetch_array($Result)){
	  ?>
                    <option value="<?=$ArrayC[cid]?>"  style="font-size:12px;" <? if($ArrayC[cid]==$myRows[brand]){ echo "selected"; }else{?> <? } ?>>
                    <?=stripslashes($ArrayC[name])?>
                    </option>
                    <? }?>
                    
                     
                  </select></td>
                  <input type="hidden" name="brand1" id="brand1" value="<?php echo $myRows[brand]; ?>">
  </tr>
</table>            </td>
          </tr>
          
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
         
          <tr align="center">
            <td colspan="2">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tbl1">
  <tr>
    <th colspan="2" align="left"><span class="style3">* </span><strong>Add Url & Meta Tags </strong></th>
          </tr>          
			 <!--<tr  >
            <td width="21%" align="right"><strong>Input Url : </strong></td>
            <td width="79%"><input name="input_url" type="text" class="txtbox1" value="<?=$myRows[input_url]?>" /></td>
          </tr>-->  
		   <tr>
            <td align="right"><strong>Seo Project Title : </strong></td>
            <td><textarea name="Seo_Project_Title" class="txtarea1" ><?=$myRows[Seo_Project_Title]?></textarea></td>
          </tr>  
		   <tr>
            <td align="right"><strong>Seo Project Description : </strong></td>
            <td><textarea name="Seo_Project_Description" class="txtarea1"><?=$myRows[Seo_Project_Description]?></textarea></td>
          </tr>   
		  <tr>
            <td align="right"><strong>Seo Project Keyword: </strong></td>
            <td><textarea name="Seo_Project_Keyword" class="txtarea1"><?=$myRows[Seo_Project_Keyword]?></textarea></td>
  </tr>
</table>

            </td>
          </tr>
          <tr align="center">
            <td colspan="2" align="left">&nbsp;</td>
          </tr>
          <tr align="center">
            <td colspan="2">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tbl1">
  <tr>
    <th colspan="2" align="left"><span class="style3">* </span><strong>Product Detail </strong></th>
  </tr>            
			        
			<?
			if($myRows[products_image]!=""){
			?>
          <tr  >
            <td width="21%" align="right"><strong>Existing Product Related File 1 : </strong></td>
            <td width="79%"><img src="../<?=$myRows[products_image]?>" width="100" height="100">
			<input type="hidden" name="ExistImage" value="<?=$myRows[products_image]?>" />			</td>
          </tr>
		  <? } ?>
          <tr  >
            <td align="right"><strong>Product Related File 1 : </strong></td>
            <td><a href="deletepic.php?img=1&amp;id=<?php echo $myRows[products_id]; ?>"><img src="images/del.gif" alt="Delete Image" width="12" height="12" border="0" align="absmiddle"><span class="leftlinks">[Remove]</span></a><input name="articleFile" type="file" id="articleFile"></td>
          </tr>
		  <?
			if($myRows[products_image2]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product Related File 2 :</strong></td>
		     <td><img src="../<?=$myRows[products_image2]?>" width="100" height="100">
			 <input type="hidden" name="ExistImage2" value="<?=$myRows[products_image2]?>" /></td>
	      </tr>
		    <? } ?>
		   <tr  >
		     <td align="right"><strong>Product Related File 2 :</strong></td>
		     <td><a href="deletepic.php?img=2&amp;id=<?php echo $myRows[products_id]; ?>"><img src="images/del.gif" alt="Delete Image" width="12" height="12" border="0" align="absmiddle"><span class="leftlinks">[Remove]</span></a><input name="articleFile2" type="file" id="articleFile2" /></td>
	      </tr>
		   <?
			if($myRows[products_image3]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product Related File 3 :</strong></td>
		     <td><img src="../<?=$myRows[products_image3]?>" width="100" height="100">
			 <input type="hidden" name="ExistImage3" value="<?=$myRows[products_image3]?>" /></td>
	      </tr>
		   <? } ?>
		   <tr  >
		     <td align="right"><strong>Product Related File 3 :</strong></td>
		     <td><a href="deletepic.php?img=3&amp;id=<?php echo $myRows[products_id]; ?>"><img src="images/del.gif" alt="Delete Image" width="12" height="12" border="0" align="absmiddle"><span class="leftlinks">[Remove]</span></a><input name="articleFile3" type="file" id="articleFile3" /></td>
	      </tr>
		  <?
			if($myRows[products_image4]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product Related File 4 :</strong></td>
		     <td><img src="../<?=$myRows[products_image4]?>" width="100" height="100">
			 <input type="hidden" name="ExistImage3" value="<?=$myRows[products_image4]?>" /></td>
	      </tr>
		   <? } ?>
		   <tr  >
		     <td align="right"><strong>Product Related File 4 :</strong></td>
		     <td> <a href="deletepic.php?img=4&amp;id=<?php echo $myRows[products_id]; ?>"><img src="images/del.gif" alt="Delete Image" width="12" height="12" border="0" align="absmiddle"><span class="leftlinks">[Remove]</span></a><input name="articleFile4" type="file" id="articleFile4" /></td>
	      </tr>
		  <?
			if($myRows[products_image5]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product Related File 5 :</strong></td>
		     <td><img src="../<?=$myRows[products_image5]?>" width="100" height="100" />
	         <input type="hidden" name="ExistImage5" value="<?=$myRows[products_image5]?>" /></td>
	      </tr>
		   <? } ?>
		   <tr  >
		     <td align="right"><strong>Product Related File 5 :</strong></td>
		     <td> <a href="deletepic.php?img=5&amp;id=<?php echo $myRows[products_id]; ?>"><img src="images/del.gif" alt="Delete Image" width="12" height="12" border="0" align="absmiddle"><span class="leftlinks">[Remove]</span></a><input name="articleFile5" type="file" id="articleFile5" /></td>
	      </tr>
		 <?
			if($myRows[icon1]!=""){
			?> 
		   
		   <? } ?>
          
           <?
			if($myRows[icon2]!=""){
			?> 
		   
		   <? } ?>
          
		   <?
			if($myRows[icon3]!=""){
			?> 
		   
		   <? } ?>
          
		  		   <?
			if($myRows[icon4]!=""){
			?> 
		   
		   <? } ?>
          
		  		  		   <?
			if($myRows[icon5]!=""){
			?> 
		   
		   <? } ?>
          
          <!--<tr  >
            <td align="right"><strong>SKU : </strong></td>
            <td><input name="sibn" type="text" class="txtbox1" id="sibn" value="<?=$myRows[sibn]?>" /></td>
          </tr>-->

          <tr  >
            <td align="right"><strong>MRP </strong><strong>Price : </strong> </td>
            <td><input name="productprice" type="text" class="txtbox1" id="productprice"  value="<?=$myRows[products_price]?>"></td>
          </tr>
          <tr  >
            <td align="right"><strong>OLD </strong><strong>Price : </strong> </td>
            <td><input name="productOldPrice" type="text" class="txtbox1" id="productprice"  value="<?=$myRows[products_oldprice]?>"></td>
          </tr>
          <tr>
            <td align="right"><strong> Offer Product  : </strong></td>
            <td><input name="productOffer" type="checkbox" class="textbox" id="articleStatus" value="1" <? if($myRows[products_offer]==1){?>checked <? }?>></td>
          </tr>
          <tr  >
            <td align="right"><strong>Stock : </strong></td>
            <td><input name="stock" type="radio" value="1" <? if ($myRows[stock]=="1") {?> checked="checked" <? } ?> />
              <strong>              In Stock</strong> 
              <input name="stock" type="radio" value="0" <? if ($myRows[stock]=="0") {?> checked="checked" <? } ?> />
              <strong>Out of Stock </strong></td>
          </tr>
          <tr  >
            <td align="right"><strong>Delivery Time : </strong></td>
            <td><input name="dltime" type="text" class="txtbox1" id="dltime" value="<?=$myRows[dltime]?>" /></td>
          </tr>
          <tr>
            <td align="right" valign="top"><strong>Embed Code : </strong></td>
            <td><textarea name="emdvedio" class="txtarea1" id="emdvedio" style="height:60px; width:300px;"><?=$myRows[emdvedio]?></textarea></td>
          </tr>
          <tr>
            <td align="right"><strong> Offer Free Product  : </strong></td>
            <td><input name="freeproduct" type="text" class="txtbox1" id="freeproduct" value="" /></td>
          </tr>
          <tr>
            <td align="right"><strong> View Product  : </strong></td>
            <td><input name="productStatus" type="checkbox" class="textbox" id="articleStatus" value="1" <? if($myRows[products_status]==1){?>checked <? }?>></td>
          </tr>
          
          <!--<tr>
            <td align="right"><strong> Product Weight : </strong></td>
            <td><input name="productWeight" type="text" class="txtbox1" id="productWeight" value="<?=$myRows[weight_qty]?>"> &nbsp;&nbsp;
            <select name="weightUnit" class="selbox" id="weightUnit" style="width:80px">
            <option value="" selected="selected">-- Select --</option>
            	<option value="gm" <? if($myRows[weight_unit]=='gm'){?> selected="selected" <? }?>>gm</option>
                <option value="kg" <? if($myRows[weight_unit]=='kg'){?> selected="selected" <? }?>>kg</option>
                <option value="lb" <? if($myRows[weight_unit]=='lb'){?> selected="selected" <? }?>>lb</option>
                <option value="tablets" <? if($myRows[weight_unit]=='tablets'){?> selected="selected" <? }?>>tablets</option>
                <option value="capsules" <? if($myRows[weight_unit]=='capsules'){?> selected="selected" <? }?>>capsules</option>
            </select> 
            &nbsp;&nbsp;<input type="text" name="customweightUnit" id="customweightUnit" <?php if(($myRows[weight_unit]!='gm') &&  ($myRows[weight_unit]!='kg') && ($myRows[weight_unit]!='lb') && ($myRows[weight_unit]!='tablets') && ($myRows[weight_unit]!='capsules')) { ?> value="<?php echo $myRows[weight_unit]; ?>" <?php } ?>/>
            
                       </td>
  </tr>-->
</table>

            </td>
          </tr>
          
          
          <tr>
            <td colspan="2"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td colspan="2" align="center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2" align="left"><h2><span class="style3">* </span><strong>About Product</strong></h2></td>
              </tr>
              <tr>
                <td colspan="2" align="center"><textarea id="shortdesc" name="shortdesc" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[shortdesc]?></textarea>&nbsp;</td>
              </tr>
			  	<script type="text/javascript">		
		var editor = CKEDITOR.replace( 'shortdesc',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
              <?php /*?><tr>
                <td colspan="2" align="center"><span class="style3"> </span> 
                   <span class="style3">* </span><strong> About Product : </strong> </td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
				<textarea id="productSummary" name="productSummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[Description]?></textarea>                 </td>
                </tr>
				
		<?php */?>
		<script type="text/javascript">		
		var editor = CKEDITOR.replace( 'productSummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
          </tr>
		    <tr>
            <td colspan="2"><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="text">
              <tr>
                <td colspan="2" align="center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2" align="left"><h2><span class="style3">* </span><strong> Product Feature  : </strong></h2></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
				<textarea id="authorsummary" name="authorsummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[authorsummary]?></textarea>                 </td>
                </tr>
            </table></td>
          </tr>
      
          <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'authorsummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
 <tr>
            <td colspan="2"><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="text">
              <tr>
                <td colspan="2" align="center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2" align="left"><h2><span class="style3">* </span><strong> Product Specification  : </strong></h2></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
				<textarea id="specification" name="specification" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[specification]?></textarea>                 </td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
   <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" class="tbl1">
     <tr>
       <th>&nbsp;</th>
       <th>&nbsp;</th>
     </tr>
      <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'specification',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
 <!--------------   Option Array Listing Start  --------------------->
 
 <!--<tr>
            <td align="right"><strong> Multi Option  : </strong></td>
            <td><input name="multioption" type="checkbox" class="textbox" id="multioption" value="1" <? if($myRows[multioption]==1){?>checked <? }?>>&nbsp;&nbsp;</td>
          </tr>-->
          <input type="hidden" name="multioption" id="multioption" value="1">
<?php
$allProductOption = getAllProductOption();
if(count(allProductOption)>0) {
foreach($allProductOption as $allProductOptionData) {
?>                
                  <tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> <?php echo $allProductOptionData['name']; ?></strong> :</strong></td>
                    <td align="left">
<!--------------   Option Field Array Listing Start  --------------------->
<?php
$allProductOptionField = getAllProductOptionField($allProductOptionData['op_id']);
if(count(allProductOptionField)>0) { ?>
<input type="hidden" name="productoptionid[]" id="productoptionid" value="<?php echo $allProductOptionData['op_id']; ?>">

<select name="optionarr<?php echo $allProductOptionData['op_id']; ?>">
<option value="">-- Select --</option>
<?php 
foreach($allProductOptionField as $allProductOptionFieldData) {
?>

<?php /*?><input type="checkbox" name=[<?php echo $allProductOptionData['op_id'] ?>][] id="" value="<?php echo $allProductOptionFieldData['id']; ?>">&nbsp;<?php */?>

<?php /*?><input type="radio" name="optionarr<?php echo $allProductOptionData['op_id']; ?>" value="<?php echo $allProductOptionFieldData['id']; ?>">&nbsp;<?php */?>
<!--<select name="optionarr<?php echo $allProductOptionData['op_id']; ?>">
	<option value="">-- Select --</option>
	<option value="<?php echo $allProductOptionFieldData['id']; ?>"></option>
</select>-->
<option value="<?php echo $allProductOptionFieldData['id']; ?>"><?php echo $allProductOptionFieldData['product_option_name']; ?></option>

<?php echo $allProductOptionFieldData['product_option_name']; ?>&nbsp;&nbsp;&nbsp;

<?php } ?>
</select>
<?php } ?>
	

<!--------------   Option Field Array Listing End  --------------------->               
                  
                    </td>
                  </tr>
<?php } } ?>
<!--------------   Option Array Listing End  --------------------->    
   </table></td>
   </tr>
      
                

          <tr align="center"> 
            <td colspan="2" align="left">              <input name="btnSubmit" type="submit" id="btnSubmit" value="Add Similar Product" class="btn1">
           <input name="ProductID" type="hidden" id="ProductID" value="<?=$_REQUEST[ProductID]?>">           </tr>
      </table></td>
    </form>
  </tr>
</table>
<script language="javascript">
function RBtnReset() {
//alert();
//document.getElementsById(allradiobtn).checked = false;
document.getElementById(allradiobtn).checked = false;
}
</script>
 
