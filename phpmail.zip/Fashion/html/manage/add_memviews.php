 <?
if(isset($_REQUEST["hdn"])){
	if($_REQUEST["hdn"]==1){
		$startdate=mktime($_REQUEST[SHOUR],$_REQUEST[SSECOND],0, $_REQUEST[SMONTH], $_REQUEST[SDATE], $_REQUEST[SYEAR]);
		$filename = $_FILES[browse][name];
		$randno = mt_rand(1,1000);
		$filename = "$randno$filename";
		copy($_FILES[browse][tmp_name],"../member/".$filename);
	 	$query="insert into member_vew set mem_name='".$_REQUEST[c_name]."',mem_view ='".$_REQUEST[l_dsc]."',member ='".$filename."'";
			$result=mysql_query($query) or die(mysql_error());
			 header("Location:home.php?PageURL=add_memviews&MSG=Successfully Added.");
 
	}
}

?>
<link href="images/class.css" rel="stylesheet" type="text/css">
  
 
<link href="styles.css" rel="stylesheet" type="text/css">
 
<form name=frmAdd method=post ENCTYPE="multipart/form-data">
    <input type="hidden" name="hdn" value="1">
<table width="95%" border="0" align="center" cellpadding="3" cellspacing="1">
  <tr> 
    <td height="10" colspan=2 ></td>
  </tr>
 
    <?
	if($MSG) { ?>
    <TR align="center"> 
      <TD colspan=2> <?echo "<font color='#FF3366'>".$MSG."</font>"; ?> </TD>
    </TR>
    <? } ?>
    <TR> 
      <TD height="27" colspan="2" valign="top" class="headM txtcol"><strong>Add Message Box &nbsp;:</strong></TD>
    </TR>
    <TR>
      <TD width="50%" align=right valign="middle" class="text">Name &nbsp;<strong>:</strong></TD>
      <TD width="50%"><input name="c_name" type="text" class="TextBox" id="c_name" value="<?=$_REQUEST[c_name]?>" size="50" /></TD>
    </TR>
    <TR>
      <TD align=right valign="middle" class="text">Description<strong> :</strong></TD>
      <TD><textarea name="l_dsc" class="TextBox" id="l_dsc" style="height:200px; width:400px;"></textarea></TD>
    </TR>
    <TR>
      <TD align=right valign="middle" class="text">Image</TD>
      <TD><input type="file" name="browse" />
      width=&quot;67&quot; height=&quot;70&quot;</TD>
    </TR>
    
    
    <TR> 
      <TD height=0 colspan="2" align=center valign="top" class="text">&nbsp; </TD>
    </TR>
    
    	
   
    <TR align="center"> 
      <TD height=50 colspan="2"> <input type=submit class=button1 name=Add value="Add " onClick="return validate();">
	  
	  &nbsp;&nbsp;&nbsp;&nbsp;<input id="btnBack2" class="button1" type="button" value=" Back " onClick="javascript:history.back(-1)" name="Back"/>      </TD>
    </TR>
</TABLE>
</form>
<script language="JavaScript" type="text/javascript">

function validate()
{
	
if(document.frmAdd.c_name.value=="")
{
	alert("Name field can't be blank");
	document.frmAdd.c_name.focus();
	return false;
}
  
}
</script>
