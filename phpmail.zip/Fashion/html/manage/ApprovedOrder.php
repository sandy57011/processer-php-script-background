<style type="text/css">
<!--
.style3 {color: #000000; font-weight: bold; }
-->
</style><br>
<?
	$query="select * from order_mem";
	$result=mysql_query($query) or die(mysql_error());
	$Pending = 0;
	$Processing = 0;
	$shipped = 0;
	$Approved = 0;
	while($array = mysql_fetch_array($result)){
	if($array[status]==0 and $array[shipped]==0 and $array[intPaid]==0){
	$Pending +=1;
	}
	if($array[intPaid]==1 and $array[shipped]==0 and $array[status]==0){
	$Processing +=1;
	}
	if($array[intPaid]==1 and $array[shipped]==0 and $array[status]==1){
	$Approved +=1;
	}
	if($array[intPaid]==1 and $array[shipped]==1 and $array[status]==1){
	$shipped +=1;
	}
	
	}
?>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr  >
    <td height="24" bgcolor="#CCCCCC" class="headR" ><strong> Manage Order:</strong></td>
  </tr>
  <tr>
    <td class="tableBorderDarkGrey">
      <table width=100% border="0" cellpadding="3" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
         <tr align="center" class="headR" >
          <td height="20"><span class="style3">Pending Order</span></td>
          <td><span class="style3">To be Approved </span></td>
          <td><span class="style3">Approved by Admin</span> </td>
          <td><span class="style3">Delivered </span></td>
        </tr>
         <tr class="row1">
          <td align=center>
            <?=$Pending?></td>
          <td align=center>
          <?=$Processing?></td>
          <td align=center><?=$Approved?></td>
          <td align=center>
             <?=$shipped?></td>
        </tr>
         <tr class="row1">
           <td align=center><a href="home.php?PageURL=PendOrder" >View Detail </a></td>
           <td align=center><a href="home.php?PageURL=OrderInProcess" >View Detail </a></td>
           <td align=center><a href="home.php?PageURL=ApprovedOrder" >View Detail </a></td>
           <td align=center><a href="home.php?PageURL=OrderDeliverd" >View Detail </a></td>
         </tr>
         <tr>
          <td height="20" colspan="4" align=center>&nbsp;
           </td>
        </tr>
        
    </table></td>
  </tr>
</table>
 
 <style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style3 {color: #000000; font-weight: bold; }
-->
</style>
<br><br>
	<table width="100%"  border="0" cellspacing="0" cellpadding="0">
	<tr  > 
    <td width="90%" height="24" bgcolor="#CCCCCC" class="headR" ><strong> Processing Order List </strong></td>
    <td width="10%" bgcolor="#CCCCCC" class="headR" ><form name="form1" method="post" action="" >
 	<select name="pending" id="pending" onChange="form1.submit()">
      <option selected value="">View Report</option>
      <option value="today" <? if($_REQUEST[pending]=='today'){ echo "selected";} ?>>Daily</option>
      <option value="week" <? if($_REQUEST[pending]=='week'){ echo "selected";} ?>>Weekly</option>
      <option value="month" <? if($_REQUEST[pending]=='month'){ echo "selected";} ?>>Monthly</option>
    </select>
	  </form></td>
	</tr> 
  <tr>
    <td colspan="2" class="tableBorderDarkGrey"> 	<table width=100% border="0" cellpadding="3" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
      <?
 	 if($_REQUEST[pending]==""){
	 $query="select * from order_mem where status = 1 and intPaid = 1 and shipped = 0";
	 }else{
 	 		if($_REQUEST[pending]=='today'){
			$starttime = time() - 24*60*60;
 			$endtime = time();
 				 $query="select * from order_mem where status = 1 and intPaid = 1 and shipped = 0 and `date` >= '".$starttime."' and `date` <= '".$endtime."'";

			}elseif($_REQUEST[pending]=='week'){
			$starttime = time() - 24*7*60*60;
 			$endtime = time();
 				 $query="select * from order_mem where status = 1 and intPaid = 1 and shipped = 0 and `date` >= '".$starttime."' and `date` <= '".$endtime."'";

			}elseif($_REQUEST[pending]=='month'){
			$starttime = time() - 24*30*60*60;
 			$endtime = time();
 				 $query="select * from order_mem where status = 1 and intPaid = 1 and shipped = 0 and `date` >= '".$starttime."' and `date` <= '".$endtime."'";

			} 
	 }
	 
	 
	 
$result=mysql_query($query) or die(mysql_error());
$Number = mysql_num_rows($result);
if($Number){
	?>
      <tr align="center" class="headR" >
        <td width="10%"><span class="style3">SI NO.</span></td>
        <td  width="15%" height="20"><span class="style3">User Name</span></td>
        <td  width="20%"><span class="style3">Order No.</span></td>
        <td><span class="style3">Shipped</span></td>
        <td><span class="style3">Payment</span></td>
        <td><span class="style3">Status</span></td>
        <td><span class="style3">View</span></td>
        <td><span class="style3">Delete</span></td>
      </tr>
      <?
 $ctr=1;
while($result_rec=mysql_fetch_array($result))
{
?>
      <tr class="row1">
        <td align=center>
          <?=$ctr?>
      .</td>
        <td>
          <?
		  $mem = loginquery('customers_id',$result_rec[memid]);
		  $ARR = mysql_fetch_array($mem);
		  echo $ARR[username];
		  ?>
        </td>
        <td align=center>
          <?=$result_rec[orderid]?>
        </td>
        <td align=center><?
 	if($result_rec[shipped]==0)
 	{
 	?>
            Pending
            <?
 	}else
 	{
 		echo "Complete";
 	}
 	?>
        </td>
        <td align=center>
          <?
 	if($result_rec[intPaid]==0)
 	{
 	?>
      Pending
      <?

	}else
  	{
 		echo "Complete";
 	}
 	?>
        </td>
        <td align=center>

          <?
 	if($result_rec[status]==0)
 	{
 	?>
         Pending
          <?

	}else
  	{
 		echo "Complete";
 	}
 	?>
        </td>
        <td align=center><a href="home.php?PageURL=ViewOrderDetail&id=<?=$result_rec[id]?>">View</a></td>
        <td align=center><a href="home.php?PageURL=ViewOrder&op=del&id=<?=$result_rec[id]?>&orderid=<?=$result_rec[orderid]?>">Delete</a></td>
      </tr>
      <?
 	$ctr=$ctr+1;
 }
 }else{
 ?>
      <tr>
        <td height="20" colspan="8" align=center>
          <table width="95%" border="0">
            <tr>
              <td height="30" align="center" class="headR"   ><p class="errortext">No any complete order Yet!
                      <?=$_REQUEST[cname]?>
              </p></td>
            </tr>
        </table></td>
      </tr>
      <? }?>
    </table></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
   
</table>

