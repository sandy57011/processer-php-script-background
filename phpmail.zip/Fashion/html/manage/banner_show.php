<?
	 
	if($_REQUEST[op]=="del")
	{
		$sq = "SELECT * FROM `ad_banner` where  adid = '".$_REQUEST[adid]."'";
		$res = mysql_query($sq);
		$row = mysql_fetch_array($res);
		$imagefile = $row[adfilevalue];
		if($imagefile!=""){
		if(file_exists("../ad_pic/".$imagefile))
			@unlink("../ad_pic/".$imagefile);
			}
		mysql_query("delete from ad_banner where  adid = '".$_REQUEST[adid]."' ");
	}
	$sq = "SELECT * FROM `ad_banner` ORDER BY 'adid' ASC";
	$res = mysql_query($sq);
	$row = mysql_num_rows($res);
?>

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><form name="form1" method="post" action="editcat.php">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
            <td width="100%"> 
              <table width="99%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#3399CC" celspacing="1">
                <tr> 
                  <td bordercolor="#FFFFFF"><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="#666666"   > 
                        <td colspan="4"  style="color:#FFFFFF;"><!-- <a href="home.php?PageURL=add_banner"> -->
						Manage Banner <a href="home.php?PageURL=add_banner_pic"><font color="#FFFFFF">[ADD]</font></a>                        </td>
                      </tr>
<?
			$srno = 1;
			if($row>0){
?>
                      <tr align="center" bgcolor="#CCCCCC"> 
                        <td width="28"> Sno.</td>
                        <td width="152">View</td>
                        <td width="149">Edit </td>
                        <td width="83">Delete </td>
                      </tr>
                      <? 

						while($row1=mysql_fetch_array($res)){?>
                      <tr align="center" bgcolor="#F5F5F5"> 
                        <td><div align="right"> 
                            <?=$srno++?>
                          </div></td>
                        <td>[<a href="home.php?PageURL=Banner_Detail&adid=<?=$row1[adid]?>">View</a>]</td>
                        <td>[<a href="home.php?PageURL=editad&adid=<?=$row1[adid]?>">Edit</a>]</td>
                        <td>[<a href="home.php?PageURL=banner_show&op=del&adid=<?=$row1[adid]?>">delete</a>]</td>
                      </tr> <? }
						}else{
							?>
                      <tr align="center" bgcolor="#F5F5F5"> 
                        <td height="150" colspan="4">No Banner Added</td>
                      </tr>
                     <? }?>
                  </table> </td>
                </tr>
                <? if($_SESSION[username]){?>
                <? } ?>
              </table></td>
        </tr>
      </table>
    </form></td>
  </tr>
</table>
 