<?
 
if ($_REQUEST[add_banner])
{
$st_date = time();
$num=$_REQUEST[add_pd_in_days]*24*60*60;
$end_date = $st_date + $num;
$sql = "INSERT INTO `ad_banner` (`adid`, `adtype`, `adfilevalue`, `adposition`, `adstartdate`, `ad_no_of_days`, `ad_end_date`, `adstatus`, `adpayconfirm`) VALUES ('', '".$_REQUEST[adtype]."', '".$_REQUEST[file_value]."', '".$_REQUEST[add_position]."', '".$st_date."', '".$_REQUEST[add_pd_in_days]."', '".$end_date."', '".$_REQUEST[status]."', '".$_REQUEST[payconfirm]."')";
$res = mysql_query($sql) or die(mysql_error());
if(!mysql_error())
	{
		$msg = "Your record has been saved successfully";
		echo $msg;
		header ("location:home.php?PageURL=banner_show");
	}
else if(mysql_error())	
	{
		$msg = "Error in saving your record";
		echo $msg;
	}
}	
?>

<style type="text/css">
<!--
.style2 {font-size: 12pt}
.style7 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
<table width="65%" border="0" align="center" cellpadding="3" cellspacing="0" bgcolor="#FFFFFF">
	<tr>
	  <td bgcolor="#666666"><span class="style7">Add Banner (Java Script): </span></td>
  </tr>
	<tr>
		<td>
				<table width="100%" cellpadding="0" cellspacing="0" border="0">
				<form name="add_banner_jscript" method="post" action="" enctype="multipart/form-data" onSubmit="return check(this)">
					<tr>
						<td>
							<table width="100%" border="0" cellpadding="3" cellspacing="0" bgcolor="#CCCCCC">
                 
                <tr> 
                  <td width="36%" align="right"> Ad Type: </td>
                  <td width="64%"> 
						Java Script
                  </td>
                </tr>
                <tr> 
                  <td align="right" valign="top"> Ad File Value:</td>
                  <td align="left" valign="top"><div align="left" id="id_div"> 
                      <textarea name="file_value" cols="40" rows="5" id="file_value"><script>
</script></textarea>
                      <br>
                    </div></td>
                </tr>
                <tr> 
                  <td align="right" valign="top"><font color="#FF0000">Note:</font></td>
                  <td align="left" valign="top"><font color="#FF0000">Please 
                    insert &lt;script&gt; and &lt;/script&gt; tags in the field 
                    for Ad-File value</font></td>
                </tr>
                <tr> 
                  <td align="right"> Ad Position: </td>
                  <td> <select name="add_position" class="select" id="add_position">
                <option value="0" selected>---Select One---</option>
                <option value="topbig">Top Big Banner</option>
				 <option value="topsmallleft">Top Small Left Banner</option>
				 <option value="topsmallright">Top Small right Banner</option>
                <option value="right">Right Banner</option>
                <option value="leftbottom">Left Bottom</option>
				<!--
                <option value="item page">Item Page Banner</option>
				-->
              </select> </td>
                </tr>
                <tr> 
                  <td align="right"> Ad Period in Days: </td>
                  <td> <input type="text" name="add_pd_in_days" class="inputbox" id="add_pd_in_days"> 
                  </td>
                </tr>
                <tr> 
                  <td align="right">Status:</td>
                  <td align="right"><div align="left"><span class="style2"> 
                      <input name="status" type="checkbox" id="status" value="1" checked>
                      </span></div></td>
                </tr>
                <tr> 
                  <td align="right">Pay Confirm: </td>
                  <td align="right"><div align="left"><span class="style2"> 
                      <input name="payconfirm" type="checkbox" id="payconfirm" value="1" checked>
                      </span></div></td>
                </tr>
                <tr> 
                  <td colspan="2" align="right"><div align="center"> 
                      <input name="add_banner" type="submit" class="btnstyle" id="add_banner" value="Submit">
                    </div></td>
                </tr>
              </table>
						</td>
					</tr>
	 			</form>					
			  </table>
 		</td>
	</tr>
</table>

<script language="javascript">
function check(a)
	{
		if(a.file_value.value == "")
			{
				alert("Please enter the value of the file");
				a.file_value.focus();
				return false;
			}
			
		if(a.add_position.value == "0")
			{
				alert("Please select the position on which you want to insert your add");
				a.add_position.focus();
				return false;
			}					
			
		if(a.add_pd_in_days.value == "") 	
			{
				alert("Please enter the number of days for which ad has to be inserted.");
				a.add_pd_in_days.focus();
				return false;
			}
				
		if(isNaN(a.add_pd_in_days.value))
			{
			alert("Ad period should be in days, please enter ad perios in days");
			a.add_pd_in_days.value="";
			a.add_pd_in_days.focus();
			return false;
			}	
			
		return true;
	}			
</script>