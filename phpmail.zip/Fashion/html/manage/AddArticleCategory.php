<?
$AllCat=array();
$sql="select * from categories order by cid desc";
$res=mysql_query($sql);
$i=0;

while($row=mysql_fetch_array($res))
{
  $AllCat[$i]= array(
  "cid"=>$row[cid], 
  "cname"=>$row[cname],
  "pid"=>$row[pid],
  "Childs"=>$row[Childs],
  "LevelFromRoot"=>$row[LevelFromRoot]
  );
  $i++;
}
$NumCat=count($AllCat);

/******************************************/
function GetLevel($ParentId)
{
	global $AllCat, $NumCat;
	//echo "<br>ParentId:".$ParentId;
	$LevelFromRoot=0;
	if($ParentId==0) $LevelFromRoot=1;
	else
	{
		$i=0;
		while($i<$NumCat && $ParentId!=0)
		{
 			if($ParentId==$AllCat[$i]['cid'])
			{
				$LevelFromRoot++;
				$ParentId=$AllCat[$i]['pid'];
				//echo "<br>ParentId:".$ParentId;echo "#LevelFromRoot:".$LevelFromRoot;
 			}
			$i++;
		}
	}
	return $LevelFromRoot;
}
/******************************************/

/******************************************/
function UpdateChilds($ParentId, $NewCat)
{
 	$Childs1=mysql_result(mysql_query("select Childs from categories where cid=$ParentId"),0);
	//echo "<br>Childs1:".$Childs1;
	$OldNewCat=$Childs1.$NewCat.',';
	//echo "<br>OldNewCat:".$OldNewCat;
	$sql="update categories set Childs='".$OldNewCat."' where cid=$ParentId";
	$rs=mysql_query($sql) or die(mysql_error());
}
/******************************************/

if($_REQUEST[btnSubmit])
{
$Image="";
 if($_REQUEST[pid]=='')
	{
		$sql="select * from categories where cname='".$_REQUEST[txtCat]."'";
		$rs=mysql_query($sql);
		if(mysql_num_rows($rs)>=1)
			{
			$flag="no";
			}
		else
			{	
			$insql="INSERT INTO categories (cname,pid, Childs, LevelFromRoot) VALUES ( '".$_REQUEST[txtCat]."', '0', '', 0)";
			$inrs=mysql_query($insql) or die(mysql_error());	
			////////////////////////////////////////////////////////////////
			$FileName = $ExistRow[catimage];
				$File = $_FILES[catImg11][name]; 
				$FileName1 = mt_rand(1,1500).$File;
				if(move_uploaded_file($_FILES[catImg11][tmp_name],"../CatImage/$FileName1"))
				{
				$catimage = "CatImage/$FileName1";
				}
			////////////////////////////////////////////////////////////////
 			$Msg = 1;
 			}
	}
else
	{
	$sql="select * from categories where cname='".$_REQUEST[txtCat]."' and pid='".$_REQUEST[pid]."'";

	$rs=mysql_query($sql);
		

		if(mysql_num_rows($rs)>0){
				$flag="no";
		}else{	
		///////////////////////////////////////////////////
				$FileName = $ExistRow[catimage];
				$File = $_FILES[catImg11][name]; 
				$FileName1 = mt_rand(1,1500).$File;
				if(move_uploaded_file($_FILES[catImg11][tmp_name],"../CatImage/$FileName1"))
				{
				$catimage = "CatImage/$FileName1";
				}
		///////////////////////////////////////////////////
 
				$LevelFromRoot=GetLevel($_REQUEST[pid]);
				//echo "<br>LevelFromRoot:".$LevelFromRoot;
				$insql="INSERT INTO categories (cname, pid, Childs, LevelFromRoot, categories_image) VALUES ('".$_REQUEST[txtCat]."','".$_REQUEST[pid]."', '', $LevelFromRoot, '".$catimage."' )";
				$inrs=mysql_query($insql) or die(mysql_error());
					$Msg = 1;				
				$NewCat=mysql_insert_id();
				UpdateChilds($_REQUEST[pid], $NewCat); 
				$flag="";				
 
				}

			}	
	}
 
?>
<link href="images/class.css" rel="stylesheet" type="text/css">

<br>
<table width="95%" border="0" cellpadding="3" cellspacing="0"  >
  <tr  > 
    <td bgcolor="#CCCCCC" class="headR" ><strong>Add Category</strong></td>
  </tr>
  <tr > 
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return validate(this)">
      <td class="tableBorderDarkGrey"> <table width="100%"  border="0" cellpadding="3" cellspacing="0"  class="text">
          <?
	 if($Msg!="" or $flag!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" class="errortext"> 
              <?
			  if($Msg==1)
			  	{
			  ?>              Category 
              Successfully added.  
              <?
			  	}
			  elseif($flag=='no')
			  	{	
			  ?>               Category 
              already exists. 
              <?
			  	}
			  ?>
            </td>
          </tr>
          <? }?>
          <tr> 
            <td width="50%" align="right"><strong>Parent Category Name:</strong></td>
            <td>
			 <? 
 				if($_REQUEST[cid]==""){?>
			<select name="pid" id="pid" class="textbox">
                <option value="" selected>Select</option>
                <?
							$sql3="select * from categories where pid=0";
							$rs3=mysql_query($sql3);
							//cid, cname, pid, Childs, LevelFromRoot
							while ($row3 = mysql_fetch_array($rs3))
							{
							$AccumulatedNodes= array();
							$NodeLevel= array();
							$NodesToTraverse= array();
							$NodesExpire= array();
							
								
 								array_unshift($AccumulatedNodes, $row3[cid]);
								array_unshift($NodesToTraverse, $row3[cid]);
   								while(count($NodesToTraverse)>0)
								{
									$OpenNodeId=array_shift($NodesToTraverse);
									array_push($NodesExpire, $OpenNodeId);
									$query4="select * from categories where cid=$OpenNodeId";
									$res4=mysql_query($query4);
									$row4 = mysql_fetch_array($res4);
									if($row4[Childs]!="")
									{
										$Childs= array();
										$Childs=explode(',', $row4[Childs]);
										$NumChilds=count($Childs)-1;
										for($i=$NumChilds-1;$i>=0;$i--)
										{
 											array_unshift($AccumulatedNodes, $Childs[$i]);
											array_unshift($NodesToTraverse, $Childs[$i]);
										}
										unset($Childs);
									}
  								}
								$AccumulatedNodes = array_reverse($AccumulatedNodes, false);
								reset($NodesExpire);
								for($i=0;$i<count($NodesExpire);$i++)
								{
									$query5="select * from categories where cid=$NodesExpire[$i]";
									$res5=mysql_query($query5);
									$row5 = mysql_fetch_array($res5);
 									?>
                <option value="<?=$row5[cid]?>"> 
                <? for($j=0;$j<$row5[LevelFromRoot];$j++){ echo ">"; } ?>
                <?=$row5[cname]?>
                </option>
                <?
								}
 							unset($AccumulatedNodes, $NodeLevel, $NodesToTraverse, $NodesExpire);
							}																									
							?>
              </select>
			  <? }else{
				 $sql3="select * from categories where cid='".$_REQUEST[cid]."'";
				 $rs3=mysql_query($sql3) or die(mysql_error());
				$Ar3 = mysql_fetch_array($rs3);
				  	echo stripslashes($Ar3[cname]);
				  ?>
				  	<input name="pid" type="hidden" value="<?=$_REQUEST[cid]?>">
				  <? }?>
			  </td>
          </tr>
          <tr> 
            <td width="50%" align="right"><strong>Category Name:</strong></td>
            <td><input name="txtCat" type="text" id="txtCat"    class="textbox"></td>
            
          </tr>
          <?php /*?><tr>
            <td align="right"><strong>Category  Image:</strong></td>
            <td><input name="catImg11" type="file" id="catImg11" class="textbox">
             </td>
          </tr><?php */?>
 
          <tr align="center"> 
            <td colspan="2"><input name="btnBack" type="button" id="btnBack" value="   &lt;&lt; Back   "  class="button1" onClick="javascript:location.href='home.php?PageURL=ManageCategory'">              <input name="btnSubmit" type="submit" id="btnSubmit" value="   Add Category   " class="button1"></td>
          </tr>
        </table></td>
    </form>
  </tr>
</table>
<script language="JavaScript" type="text/JavaScript">
 
function validate(a)
	{
		if(a.txtCat.value=="")	
			{
				alert("Category name cannot be blank");
				a.txtCat.focus();
				return false;
			}
 
			
		 
 		return true;
	}
</script>
