 <?
 if(isset($_REQUEST[hdn])){
	if($_REQUEST[hdn]==1){
		$sql=mysql_query("update shopper_tbl set shopstatus='".$_REQUEST[Shop_status]."' where shopid=".$_REQUEST[StoreID]) or die(mysql_error());
		$msg="Store View Status Successfully Updated";
	}elseif($_REQUEST[hdn]==2){
		$sql=mysql_query("update shopper_tbl set shopfeatured='".$_REQUEST[StoreFeatured]."' where shopid=".$_REQUEST[StoreID]) or die(mysql_error());
		$msg="Store Feature Status Successfully Updated";	
	}elseif($_REQUEST[hdn]==3){
		$sql=mysql_query("select * from shopper_tbl where shopid=".$_REQUEST[StoreID]) or die(mysql_error());
		$rows=mysql_fetch_array($sql);
		if($rows[shoplogo]!="" and file_exists("../".$rows[shoplogo])){
			unlink("../".$rows[shoplogo]);
		}
		$sql1=mysql_query("select * from products where manufacturers_id=".$_REQUEST[StoreID]) or die(mysql_error());
		$Num1 = mysql_num_rows($sql1);
		if($Num1){
		while($rows1=mysql_fetch_array($sql1)){
		if($rows1[products_image]!="" and file_exists("../".$rows1[products_image])){
			unlink("../".$rows1[products_image]);
		}
 		$sql=mysql_query("delete from products where products_id=".$rows1[ProductID]) or die(mysql_error());		
		}
		}
		$sql=mysql_query("delete from shopper_tbl where shopid=".$_REQUEST[StoreID]) or die(mysql_error());		
		$msg="Store Informaition and it's all product/s Successfully Deleted";			
	}
}
?>
  <br>	 
     <?
	 if($msg){
	 ?><p align="center" class="errortext">
	 	<?=$msg?>
	 	 </p>
		  <?
	 }
	 ?> 
   
 	    <?
		$SQL="select * from shopper_tbl st, bestseller_payment bsp where st.shopid = bsp.shopid and bsp.status = 1 order by st.shopid desc";
		$CatRes=mysql_query($SQL);
		$SearchNumber = mysql_num_rows($CatRes);
		if($SearchNumber>0){
		///////////////////////////////////////
		 $TotalRecords = $SearchNumber;
 				 if(isset($_REQUEST['Pageno'])){
 					$Pageno=$_REQUEST['Pageno'];
 				}else{
 					$Pageno=1;
 				} 
 				$limit=10;//PAGE_LIMIT;
 				$offset = ($Pageno - 1) * $limit; 
 				$intCount=1;
 				$numPages = ceil($SearchNumber / $limit);
 				$SQL = $SQL." limit $offset,$limit";
 				$CatRes= mysql_query($SQL) or die(mysql_error());
		////////////////////////////////////////////
		?>
	 	  <table width="95%" border="0" cellpadding="0" cellspacing="0"  >
  <tr  > 
    <td height="24" bgcolor="#CCCCCC" class="headR" ><strong> Store List </strong></td>
  </tr> 
 <tr > 
   
      <td class="tableBorderDarkGrey">

	  <table width="100%"  border="0" cellpadding="3" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#FFFFFF"   >
	    
 
         <tr  class="headR" >
          <td width="22%" >Store Title </td>
          <td width="16%" height="20" align="center">Store Logo </td>
		 <td width="12%" align="center" nowrap>Added Date </td>
           <td width="12%" align="center" nowrap>Shop Category </td>
           <td width="9%" align="center">  Status </td>
          <td width="7%" align="center">Edit</td>
          <td width="11%" align="center">Delete</td>
          <td width="11%" align="center" nowrap>View Product </td>
        </tr>		
		    
<?
	while($CatRow=mysql_fetch_array($CatRes)){
?>
          <tr class="row1" >
          <td width="22%" ><?=$CatRow[shopname]?></td>
          <td width="16%" align="center"><img src="../<?=$CatRow[shoplogo]?>" width="50" height="50"></td>
		 <td width="12%" align="center"><?=date("M-d, Y",$CatRow[adddate])?></td>
           <td width="12%" align="center"><a href="home.php?PageURL=Shopcategory&shopcatid=<?=$CatRow[shopid]?>"><img src="images/send_note.jpg" border="0"></a></td>
           <td width="9%" align="center">
		  <? 
		  if($CatRow[shopstatus]==1){
		  ?>		  
		  <a href="home.php?PageURL=BestSellerList&Shop_status=0&StoreID=<?=$CatRow[shopid]?>&hdn=1"><img src="images/icon-activate.gif" alt="Activated" width="16" height="16" border="0"></a>
		  <? }else{?>
		  <a href="home.php?PageURL=BestSellerList&Shop_status=1&StoreID=<?=$CatRow[shopid]?>&hdn=1"><img src="images/icon-acl-add.gif" alt="De-Activated" width="16" height="16" border="0"></a>
		  
		  <? }?>
		  </td>
          <td width="7%" align="center"><a href="home.php?PageURL=EditShop&StoreID=<?=$CatRow[shopid]?>"><img src="images/edit.gif" alt="Edit Article" width="12" height="12" border="0" align="absmiddle"></a></td>
          <td width="11%" align="center">  
      <a href="home.php?PageURL=BestSellerList&StoreID=<?=$CatRow[shopid]?>&hdn=3"><img src="images/del.gif" border="0" alt="Delete Article" width="12" height="12" align="absmiddle"></a> </td>
          <td width="11%" align="center"><a href="home.php?PageURL=ViewShopProduct&StoreID=<?=$CatRow[shopid]?>">View</a></td>
        </tr>  <? }?>
      </table> 
   </td>
  </tr> 
 <tr><td><table  border="0" cellspacing="3" cellpadding="1" align="center" class="paging">
  <tr> 
  <td>Pages&nbsp;</td>
    <? 
 						if($Pageno > 1){ 	
 							$PrevPage = $Pageno - 1;
 						?>
    <td><a href="home.php?PageURL=BestSellerList&Pageno=<? echo $PrevPage?>"><img src="../images/pag-bak-of.gif" alt="" align="middle" /></a></td>
	<? }?>
	<? 
	if($Pageno+5>$numPages){
	$End = $numPages;
	}else{
	$End = $Pageno+5;
	}
	$start = $Pageno;
 	for($i=$Pageno;$i<=$End;$i++){?>
     <td>
	 <? if($Pageno==$i){ echo $i; }else{?>
	 <a href="home.php?PageURL=BestSellerList&Pageno=<? echo $i?>"><?=$i?></a>&nbsp;
	 <? }?>
	 </td>
	 <? }
	if($numPages > $Pageno){ 	
  							$NextPage = $Pageno + 1;
 						?>
    <td><a href="home.php?PageURL=BestSellerList&Pageno=<? echo $NextPage?>"><img src="../images/pag-next-on.gif" alt="" align="middle" /></a></td>
	<? }?>
  </tr>
</table></td></tr>
</table> 
 
 <? }else{?>
 <table width="95%" border="0">
  <tr>
    <td height="30" align="center" class="headR"   ><p class="errortext">No Store Yet! 
      <?=$_REQUEST[cname]?>
    </p></td>
  </tr>
</table>
 <? } ?>
<script language="javascript">
function validate()
{
	if(document.form1.searchkey.value==""){
		alert('Enter Search Kery');
		return false;
	}
}
</script>