<?
 if($_REQUEST[btnSubmit]){
 $other="";
   for($n=0;$n<count($_REQUEST[other]);$n++)
  {
    if($n>0)
   $other.=", ".$_REQUEST[other][$n];
   else
   $other.=$_REQUEST[other][$n];
   }
/************   Gallery Image Upload Start   ****************************************/
if($_FILES[gallery_image1][name]!="")
	{ 
	    $intFile=mt_rand();
		$gallery_image1=$intFile.$_FILES[gallery_image1][name];
		move_uploaded_file($_FILES[gallery_image1][tmp_name],"../product_file/product_gallery/".$gallery_image1);
	}
else {	$gallery_image1=$_REQUEST['galfile1'];	}

if($_FILES[gallery_image2][name]!="")
	{ 
	    $intFile=mt_rand();
		$gallery_image2=$intFile.$_FILES[gallery_image2][name];
		move_uploaded_file($_FILES[gallery_image2][tmp_name],"../product_file/product_gallery/".$gallery_image2);
	}
else {	$gallery_image2=$_REQUEST['galfile2'];	}

if($_FILES[gallery_image3][name]!="")
	{ 
	    $intFile=mt_rand();
		$gallery_image3=$intFile.$_FILES[gallery_image3][name];
		move_uploaded_file($_FILES[gallery_image3][tmp_name],"../product_file/product_gallery/".$gallery_image3);
	}
else {	$gallery_image3=$_REQUEST['galfile3'];	}

if($_FILES[gallery_image4][name]!="")
	{ 
	    $intFile=mt_rand();
		$gallery_image4=$intFile.$_FILES[gallery_image4][name];
		move_uploaded_file($_FILES[gallery_image4][tmp_name],"../product_file/product_gallery/".$gallery_image4);
	}
else {	$gallery_image4=$_REQUEST['galfile4'];	}

/****************  Gallery Image Upload End      ****************/ 

/******************   Product Option Array Value Start    *****************/
$productoptionid = $_POST['productoptionid'];
$optionIdArray = "";
$product_option_field_array = "";
for($i=0;$i<sizeof($productoptionid);$i++) {
 
$posttext = "optionarr".$productoptionid[$i];

$posttextnn = $_POST[$posttext];

if($posttextnn!="") {
$optionIdArray .=",".$productoptionid[$i];
$product_option_field_array .=",".$posttextnn;
}
}
$optionIdArray = substr($optionIdArray,1);
$product_option_field_array = substr($product_option_field_array,1);

/******************   Product Option Array Value End    ******************/

		$sql = "INSERT INTO product_option_array_field set p_id = '".$_REQUEST['productid']."', product_option_field_array = '".$product_option_field_array."', product_option_ids = '".$optionIdArray."', price = '".$_REQUEST['price']."', product_image = '".$product_image."', gallery_image1 = '".$gallery_image1."', gallery_image2 = '".$gallery_image2."', gallery_image3 = '".$gallery_image3."', gallery_image4 = '".$gallery_image4."'"; 
		mysql_query($sql) or die(mysql_error());
		
//$insid = mysql_insert_id(); 
//$input_url = $_REQUEST[input_url];
//if($input_url=="") {
//$input_url = "detail-itid-".$insid."-catid-".ucwords($_REQUEST[productCat]);
//mysql_query("update products set input_url = '".$input_url."' where products_id = '".$insid."'") or die(mysql_error());
//} 	 	 
 		//$Msg="<li>Article Successfully Addes";	
		  header("Location:home.php?PageURL=AddOpProduct&cid=$_REQUEST[productCat]&cname=$_REQUEST[cname]&intMSG=<li>Product Successfully Added");
	
}
 
?>
<link href="images/class.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script> 


<h1>Add Product </h1>
<table width="100%" border="0" cellpadding="3" cellspacing="0"  >
  <tr> 
    <form action="" method="post" enctype="multipart/form-data" name="frmArticle" id="frmArticle" onSubmit="javascript:return check()">
      <td class="tableBorderDarkGrey"> 
        <table width="100%"  border="0" cellpadding="0" cellspacing="0"  class="text" >
          <?
	 if($Msg!="" or $_REQUEST[intMSG]!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" align="left" class="errortext"> 
              <?=$Msg?><?=$_REQUEST[intMSG]?>            </td>
          </tr>
          <? }?>
          
		    
            <tr>
              <td colspan="2">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tbl1">
                  <tr align="center"  >
                    <th width="21%" align="right"><span class="style3">*</span><strong>Category Name :</strong></th>
                    <th width="79%" align="left"><? 
 				if($_REQUEST[cid]==""){?>
                        <select name="productCat" id="select2" class="textbox">
                          <option value="" selected="selected">Select</option>
                          <?
							$sql3="select * from categories where pid=0";
							$rs3=mysql_query($sql3);
							//cid, cname, pid, Childs, LevelFromRoot
							while ($row3 = mysql_fetch_array($rs3))
							{
							$AccumulatedNodes= array();
							$NodeLevel= array();
							$NodesToTraverse= array();
							$NodesExpire= array();
							
								
 								array_unshift($AccumulatedNodes, $row3[cid]);
								array_unshift($NodesToTraverse, $row3[cid]);
   								while(count($NodesToTraverse)>0)
								{
									$OpenNodeId=array_shift($NodesToTraverse);
									array_push($NodesExpire, $OpenNodeId);
									$query4="select * from categories where cid=$OpenNodeId";
									$res4=mysql_query($query4);
									$row4 = mysql_fetch_array($res4);
									if($row4[Childs]!="")
									{
										$Childs= array();
										$Childs=explode(',', $row4[Childs]);
										$NumChilds=count($Childs)-1;
										for($i=$NumChilds-1;$i>=0;$i--)
										{
 											array_unshift($AccumulatedNodes, $Childs[$i]);
											array_unshift($NodesToTraverse, $Childs[$i]);
										}
										unset($Childs);
									}
  								}
								$AccumulatedNodes = array_reverse($AccumulatedNodes, false);
								reset($NodesExpire);
								for($i=0;$i<count($NodesExpire);$i++)
								{
									$query5="select * from categories where cid=$NodesExpire[$i]";
									$res5=mysql_query($query5);
									$row5 = mysql_fetch_array($res5);
 									?>
                          <option value="<?=$row5[cid]?>" <? if($row5[cid]==$_REQUEST[productCat]){?>selected <? }?> >
                          <? for($j=0;$j<$row5[LevelFromRoot];$j++){ echo ">"; } ?>
                          <?=$row5[cname]?>
                          </option>
                          <?
								}
 							unset($AccumulatedNodes, $NodeLevel, $NodesToTraverse, $NodesExpire);
							}																									
							?>
                        </select>
                        <? }else{
				 $sql3="select * from categories where cid='".$_REQUEST[cid]."'";
				 $rs3=mysql_query($sql3) or die(mysql_error());
				$Ar3 = mysql_fetch_array($rs3);
				  	echo $Ar3[cname];
				  ?>
                        <input name="productCat" type="hidden" value="<?=$_REQUEST[cid]?>" />
                        <? }?>                    </th>
                         </tr>
<!----------  SubCategory Start   ----------------->
				<tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Sub Category</strong> :</strong></td>
                    <td align="left"><select name="subcat" id="subcat">
                    	<option value="1">-- Select Sub Category --</option>
                    </select>
                    </td>
                  </tr>
<!------------  SubCategory  End  ------------------>  
<!----------  Product List Start   ----------------->
				<tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Product</strong> :</strong></td>
                    <td align="left"><select name="productid" id="productid">
                    	<option value="1">-- Select Product --</option>
                    </select>
                    </td>
                  </tr>
<!------------  Product List  End  ------------------>
<!--------------   Option Array Listing Start  --------------------->
<?php
$allProductOption = getAllProductOption();
if(count(allProductOption)>0) {
foreach($allProductOption as $allProductOptionData) {
?>                
                  <tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> <?php echo $allProductOptionData['name']; ?></strong> :</strong></td>
                    <td align="left">
<!--------------   Option Field Array Listing Start  --------------------->
<?php
$allProductOptionField = getAllProductOptionField($allProductOptionData['op_id']);
if(count(allProductOptionField)>0) { ?>
<input type="hidden" name="productoptionid[]" id="productoptionid" value="<?php echo $allProductOptionData['op_id']; ?>">
<?php 
foreach($allProductOptionField as $allProductOptionFieldData) {
?>

<?php /*?><input type="checkbox" name=[<?php echo $allProductOptionData['op_id'] ?>][] id="" value="<?php echo $allProductOptionFieldData['id']; ?>">&nbsp;<?php */?>

<input type="radio" name="optionarr<?php echo $allProductOptionData['op_id']; ?>" value="<?php echo $allProductOptionFieldData['id']; ?>">&nbsp;

<?php echo $allProductOptionFieldData['product_option_name']; ?>&nbsp;&nbsp;&nbsp;

<?php } } ?>
	

<!--------------   Option Field Array Listing End  --------------------->               
                  
                    </td>
                  </tr>
<?php } } ?> 
<!--------------   Option Array Listing End  --------------------->  
                  
                  <tr align="center"  >
                    <td align="right">Price</td>
                    <td align="left"><input type="text" name="price" id="price" value=""></td>
                  </tr>
<!------------  Gallery Image1  Start  --------------->
 <tr>
     <td align="right" ><span class="txt7"><strong>Product Image :</strong></span></td>
          <td align="left" ><input type="file" name="product_image" id="product_image"></td>
 </tr>
<!------------   Gallery Image1 End   ------------------>                  
                  
<!------------  Gallery Image1  Start  --------------->
 <tr>
     <td align="right" ><span class="txt7"><strong>Gallery Image 1 :</strong></span></td>
          <td align="left" ><input type="file" name="gallery_image1" id="gallery_image1"></td>
 </tr>
<!------------   Gallery Image1 End   ------------------>

<!------------  Gallery Image2  Start  --------------->
 <tr>
     <td align="right" ><span class="txt7"><strong>Gallery Image 2 :</strong></span></td>
          <td align="left" ><input type="file" name="gallery_image2" id="gallery_image2"></td>
 </tr>
<!------------   Gallery Image2 End   ------------------>

<!------------  Gallery Image3  Start  --------------->
 <tr>
     <td align="right" ><span class="txt7"><strong>Gallery Image 3 :</strong></span></td>
          <td align="left" ><input type="file" name="gallery_image3" id="gallery_image3"></td>
 </tr>
<!------------   Gallery Image3 End   ------------------>

<!------------  Gallery Image4  Start  --------------->
 <tr>
     <td align="right" ><span class="txt7"><strong>Gallery Image 4 :</strong></span></td>
          <td align="left" ><input type="file" name="gallery_image4" id="gallery_image4"></td>
 </tr>
<!------------   Gallery Image4 End   ------------------>                   
                  
                   <tr align="center"  >
                    <td align="right">&nbsp;</td>
                    <td align="left">&nbsp;</td>
                  </tr>

                </table>              </td>
          </tr>

          <tr align="center"> 
            <td colspan="2" align="left">
			
			      <?php /*?><input name="btnBack2" type="button" id="btnBack3" value="   &lt;&lt; Back   "  class="btn1" onClick="javascript:location.href='home.php?PageURL=ManageCategory&catid=<?=$_REQUEST[cid]?>&cname=<?=$Ar3[cname]?>'"><?php */?>
			      <input name="btnSubmit" type="submit" id="btnSubmit" value="Add Product Now" class="btn1"></td>
          </tr>
      </table></td>
    </form>
  </tr>
</table>
<script language="javascript">
	function check()
	{
		if(document.frmArticle.productCat.value=="")	
			{
				alert("Please Select Product Category");
				document.frmArticle.productCat.focus();
				return false;
			}
  		if(document.frmArticle.ProductTitle.value=="")	
			{
				alert("Please Enter Product Name");
				document.frmArticle.ProductTitle.focus();
				return false;
			}	
		if(document.frmArticle.brand.value=="")	
			{
				alert("Please Select Brand");
				document.frmArticle.brand.focus();
				return false;
			}
		if(document.frmArticle.shortdesc.value=="")	
			{
				alert("Please Enter Product Short Desc");
				document.frmArticle.shortdesc.focus();
				return false;
			}
		if(document.frmArticle.authorsummary.value=="")	
			{
				alert("Please Enter Product feature");
				document.frmArticle.authorsummary.focus();
				return false;
			}
		if(document.frmArticle.specification.value=="")	
			{
				alert("Please Enter Product specification");
				document.frmArticle.specification.focus();
				return false;
			}					
 		
	}
	</script>