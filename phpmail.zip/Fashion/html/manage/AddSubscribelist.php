 <?
header('Content-Type: text/html; charset=utf-8');
require_once 'Excel/reader.php';

// ExcelFile($filename, $encoding);

$data = new Spreadsheet_Excel_Reader();

// Set output Encoding.

$data->setOutputEncoding('CP1251');



  if($_REQUEST['click_on']=='Upload'){

	$file = $_FILES[dd_file][name];

 	if($_FILES[dd_file][name]==""){

 		$Error = "<font color=red>Please browse for the file to be uploaded.</font>";

	}elseif($_FILES[dd_file][type]!="application/vnd.ms-excel" and $_FILES[dd_file][type]!="application/octet-stream"){

		$Error = "<font color=red>Please locate files only in CSV format.</font>";

	}else{ 

 			$file = mt_rand(1,1000).$file;

			if(move_uploaded_file($_FILES['dd_file']['tmp_name'],"CSVUPLOADER/".$file)) {

 				$data->read("CSVUPLOADER/".$file);
				$tot = 0;
				error_reporting(E_ALL ^ E_NOTICE);
 				for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
 					 $EmailSQL = "select * from subscribe_tbl where email = '".addslashes($data->sheets[0]['cells'][$i][1])."'";
					 $EmailResult = mysql_query($EmailSQL) or die(mysql_error());
					 $EmailNum = mysql_num_rows($EmailResult);
					if($EmailNum==0){
					$sql = "INSERT INTO subscribe_tbl set  email = '".addslashes($data->sheets[0]['cells'][$i][1])."',status = 1"; 
					mysql_query($sql) or die(mysql_error());
					}else{
						$tot += 1;
						$Error = $tot." email id already exist";
					}
					// echo $sql."<br><br><br>";

   					

 

					}	

 				}

					$Msg = 1;

   

			 //	unlink("CSVUPLOADER/".$file);

		}

  }

?>





    <table width=96% border=0 align=center cellpadding="2" cellspacing="0" style="border:1px solid #3399CC">
    <tr>
     <td bgcolor="#3399CC"> <font color="#FFFFFF"><strong>Upload Suscriber List info from 
       CSV/XLS files</strong></font> </td>
    </tr>
    <tr>
      <td><table width="100%" border="0" cellspacing="0" cellpadding="2">
         	 <? if($Msg!=""){?>
 			  <tr>
           <td align="center"><table width="95%" border="0" cellpadding="3" cellspacing="1">
      </table></td>
         </tr>
         <tr>
           <td align="center"><font color="green">The Data has been uploaded successfully.</font></td>
         </tr>
 		<? }?>
 		<? if($Error!=""){?>
         <tr>
           <td align="center"><font color="#FF0000"><?=$Error?></font></td>
         </tr>
 		<? }?>
         <tr> 
           <td><strong>Note: </strong>
             <li>You can upload upto 5000 records at a time.</li>
             <li>The CSV/XLS file which you are uploading must have the following 
           fields and in the sequence as given below:</li> </td>
         </tr>
         <tr> 
           <td><table width="100%" border="0" cellspacing="0" cellpadding="2">
               <tr> 
                 <td width="50%">1) Email in validate format </td>
               </tr>
               <tr>
                 <td>&nbsp;</td>
               </tr>
             </table></td>
         </tr>
       </table></td>
    </tr>
    <tr>
      <td><table width=100% border=0 align=center cellpadding="3" cellspacing=2 bgcolor="#F7F2DF">
         <form method=post enctype=multipart/form-data name="frm" onSubmit="javascript: return validate(this)">
          <tr bgcolor="#FFFFFF">
            <td align=right nowrap><font color=green><b>Locate Csv File </b></font></td>
            <td><input type=file name=dd_file></td>
          </tr>
          <tr bgcolor="#FFFFFF">
            <td align=right><input name="btnBack" type="button" id="btnBack" value="   &lt;&lt; Back   "  class="button1" onClick="javascript:location.href='home.php?PageURL=subdet'"> 
            </td>
            <td align=left><input type=submit class="button1" name=click_on value=Upload>
           </td>
          </tr>
        </form>
      </table></td>
    </tr>
 </table>

 

 <script language="JavaScript">

 	function validate(frm){

		if(frm.dd_file.value==""){

			alert("Please browse for a csv file.");

			frm.dd_file.focus();

			return false;

		}

	}

 </script> 