<? 
if($_REQUEST[op]=='add')
{
if($_FILES[brandImage][name]!="")
	{ 
	$intFile=mt_rand();
	move_uploaded_file($_FILES["brandImage"]["tmp_name"],"../images/brand/".$intFile.$_FILES["brandImage"]["name"]);
	$fileUpload=$intFile.$_FILES["brandImage"]["name"];
    }
	 $Add = mysql_query("insert into brand set name = '".addslashes($_REQUEST[items])."', b_image = '".$fileUpload."'") or die(mysql_error());
	 $msg = "Record added successfully";
	 //header("Location:home.php?PageURL=brand");
}
if($_REQUEST[op]=='del')
{
	 $del= mysql_query("delete from brand where cid = '".$_REQUEST[id]."'") or die(mysql_error());
	$msg = "Record deleted successfully";

}
if($_REQUEST[op]=='edit')
{	
/////  Upload Brand Image  ////////////
if($_FILES[brandImage][name]!="")
	{ 
	$intFile=mt_rand();
	move_uploaded_file($_FILES["brandImage"]["tmp_name"],"../images/brand/".$intFile.$_FILES["brandImage"]["name"]);
	$fileUpload=$intFile.$_FILES["brandImage"]["name"];
	@unlink("../images/brand/".$_REQUEST[hiddenBrandImage]);
    }
if($fileUpload=="")	 {
	$fileUpload=$_REQUEST[hiddenBrandImage];
}
///// ////////////	
	$update = mysql_query("update brand set name = '".addslashes($_REQUEST[items])."', b_image = '".$fileUpload."' where cid = '".$_REQUEST[id]."'") or die(mysql_error());
	$msg = "Record updated successfully"; 
}

?>
  
<script language="javascript">
 	
	function closed()
					{
					document.getElementById("box-warning").style.display = 'none'
					
					}
</script>
<link href="images/class.css" rel="stylesheet" type="text/css">

 <div id="content-content">
   <h1>
							 
							 <a href="javascript:history.back(-1)" class="link-top">Back</a> &nbsp;&nbsp;&nbsp;
 							 <a href="javascript:void(0)" onClick="showaddedit('add',0,0,0)" class="link-top">Add </a> &nbsp;&nbsp;&nbsp;
							 <a href="javascript:void(0)" onClick="document.getElementById('addaward').style.display='none'" class="link-top">Hide  add/edit window </a> 
   </h1>		
   <? if($msg){?>
<p  style="color:green; text-align:center"><? echo $msg;?></p>	  
<? }?>
<fieldset id="addaward" style="width:500px; margin-left:100px; display:none; border:1px dotted #808080;">&nbsp;<legend style="font-weight:bold;">Add </legend>
	<form name="kcr_constant" action="" method="POST" onSubmit="return validate()" style="margin:0px; padding: 0px;" enctype="multipart/form-data">	
  <table width="500" cellpadding="2" cellspacing="0" border="0" class="table-form">
	
<tr class="tr-form">
		<td width="129" align="right" nowrap class="td-form">
			<div class="label-form">
			Name	:	</div>		</td>
		<td width="363" align="left" class="td-form">
			<input name="items" type="text" id="items" onClick="javascript:closed();" class="txtbox1" style="width:290px;" >		</td>
	</tr>
<tr class="tr-form">
		<td width="129" align="right" nowrap class="td-form">
			<div class="label-form">
			Image	:	</div>		</td>
		<td width="363" align="left" class="td-form">
			<input name="brandImage" type="file" id="brandImage" >
            <input type="hidden" name="hiddenBrandImage" id="hiddenBrandImage" />
        </td>
	</tr>    
     
  
<tr class="tr-form">
<td>&nbsp;</td>
  <td  class="td-form"><input type="submit" name="Submit" value="Submit" class="btn1">
    <input name="id" type="hidden" id="id">
    <input name="op" type="hidden" id="op"></td>
  </tr>
</table>	
 </form>	
 </fieldset>
 <br>
	<table width="100%" border="0" cellpadding="0" cellspacing="1" class="tbl1"  >

  <tr>
		<th width="17">Sn.</th>
	  <th width="210" align="left" valign="top">Name</th>
      <th width="305" align="center" valign="top">Image</th>
	  <th width="177">Edit</th>
<!--<th>Middle Name</th>-->
		<th width="172" style="width: 100px;">Delete</th>	
	</tr>
	
	
	
<?
$Query = "select * from brand";
$Ress = mysql_query($Query) or die(mysql_error());
if(mysql_num_rows($Ress)){
$sn = 1;
   while($fetch1 =   mysql_fetch_object($Ress))
   {	  
 ?>	 
			<tr align="center" bgcolor="#FFFFFF" style="font-weight:normal">
			<td><?=$sn++;?></td>
 			<td align="left" bgcolor="#FFFFFF"><?=stripslashes($fetch1->name)?></td>
            <td align="center" valign="middle"><?php if($fetch1->b_image!="") { ?><img src="../images/brand/<?=$fetch1->b_image?>" height="40" /><?php } else { ?><img src="../images/brand/noImage.jpg" height="40" /><?php } ?></td>
	<td align="center"><a href="javascript:void(0)" onClick="showaddedit('edit', '<?=$fetch1->cid?>', '<?=$fetch1->name?>', '<?=$fetch1->b_image?>')" class="link-table">
					<img src="images/edit.gif" border="0" alt="Click here to edit the Member" title="Click here to edit the Member">				</a></td>
		 <td>
 				
				 <a href="home.php?PageURL=brand&id=<? echo $fetch1->cid ?>&op=del" class="link-table" onClick="return confirm('Are you sure, want to delete this record');">
					<img src="images/del.gif" alt="Click here to delete the Member" width="16" height="16" border="0" title="Click here to delete the Member">				</a>			</td>
	  </tr>
	 <? }
	 
	 }else{
	 ?> 		<tr>
								<th align="center" colspan="4">sorry no record found ! </th>
							</tr>
							<? }?>
</table>	 

		       
 </div>
<script language="javascript">
function showaddedit(oper, id, items, bImage)
{
//alert(id);
//alert(items);
//alert(number);
document.getElementById('addaward').style.display='block';
	if(oper=='edit'){
		document.getElementById('id').value=id;
		document.getElementById('items').value=items;
		document.getElementById('hiddenBrandImage').value=bImage;
  		document.getElementById('op').value="edit";
	}else{
		document.getElementById('id').value='';
		document.getElementById('items').value='';
  		document.getElementById('op').value="add";
	}
}

function validate()
{
	if(document.kcr_constant.items.value=='')
	{
		alert("Please Enter item name");
		document.kcr_constant.items.focus();
		return false;
	}
	 
}
</script>