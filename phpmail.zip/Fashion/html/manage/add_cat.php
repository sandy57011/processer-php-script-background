<?
  	if(isset($_REQUEST[btnadd]))
		{
 			if($_FILES['catImg11']['name']!="")
				{
  				$File = $_FILES[catImg11][name]; 
  				$FileName1 = mt_rand(1,1500).$File;
  				if(move_uploaded_file($_FILES[catImg11][tmp_name],"../CatImage/$FileName1"))
					{
 					$catimage = "CatImage/$FileName1";
   					}
 				}
			 	
			echo $Query = "INSERT INTO categories set 
			        cname = '".addslashes($_REQUEST[txtCatName])."',
					pid=0,
					LevelFromRoot='".$_REQUEST[cid]."', 
					categories_image = '".$catimage."'";
		           $Result=mysql_query($Query) or die(mysql_error());
			$Msg=1;
			//$HideCatQuery = "update categories  set  hidestatus=0 where cid = '$_REQUEST[hdnCatId]'";
			//$HideCatResult=mysql_query($HideCatQuery) or die(mysql_error());
			 header("Location:home.php?PageURL=ManageCategory&MSG=Successfully Added.");
 		}
	 
 ?>
<h1>Add Parent Category</h1>

<table width="95%" border="0" cellpadding="3" cellspacing="0"  >

  <tr>
    <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return validate(this)">
      <td class="tableBorderDarkGrey"> <table width="100%"  border="0" cellpadding="3" cellspacing="3"  class="text">
          <?
	 if($Msg!="" or $flag!="")
	 	{
	 ?>
          <tr align="center"> 
            <td class="errortext"> 
              <?
			  if($Msg==1)
			  	{
			  ?>
              Category 
             Successfully Added.  
              <?
			  	}
		  ?>            </td>
          </tr>
          <? }?>
          <tr> 
            <td width="78%"><input name="txtCatName" type="text" value="<?=stripslashes($_REQUEST[txtCatName])?>" class="txtbox1"> 
              <input name="hdnCatId" type="hidden" value="<?=$_REQUEST[CatId]?>"></td>
          </tr>
		 
          <?php /*?><tr>
            <td align="right"><strong>Parent Category New Image:</strong></td>
            <td><input name="catImg11" type="file" id="catImg11">
            <input type="hidden" name="catimagename" value="<?=$_REQUEST[categories_image]?>"></td>
          </tr><?php */?>
           <tr align="center"> 
            <td><input name="btnadd" type="submit" id="btnadd2" value="Add Parent Category" class="btn1"><input name="btnBack" type="button" id="btnBack4" value="   &lt;&lt; Back   "  class="btn1" onClick="javascript:location.href='home.php?PageURL=ManageCategory'">              </td>
          </tr>
      </table></td>
    </form>
  </tr>
</table>
 
 <script language="JavaScript" type="text/JavaScript">
function validate(a)
	{
  		if(a.txtCatName.value=="")	
			{
				alert("Category name cannot be blank");
				a.txtCatName.focus();
				return false;
			}
		 

 		return true;
	}
	
/*function Change_text()
	{
 	document.form1.txtWorkingCat.value=document.form1.txtCatName.value
	}	*/
 
 </script>
