<?
 
if ($_REQUEST[add_banner])
{
$st_date = time();
if($_REQUEST[browse]=="")
	{
	$adfilevalue=$_REQUEST[file_value];
	}else
	{$adfilevalue=$_REQUEST[browse];}
	
$num=$_REQUEST[add_pd_in_days]*24*60*60;
$end_date = $st_date + $num;
$sql = "INSERT INTO `ad_banner` (`adid`, `adtype`, `adfilevalue`, `adposition`, `adstartdate`, `ad_no_of_days`, `ad_end_date`, `adstatus`, `adpayconfirm`) VALUES ('', '".$_REQUEST[adtype]."', '".$_REQUEST[file_value]."', '".$_REQUEST[add_position]."', '".$st_dat."', '".$_REQUEST[add_pd_in_days]."', '".$end_date."', '".$_REQUEST[status]."', '".$_REQUEST[payconfirm]."')";
$res = mysql_query($sql) or die(mysql_error());
if(!mysql_error())
	{
		$msg = "Your record has been saved successfully";
		echo $msg;
		
	}
else if(mysql_error())	
	{
		$msg = "Error in saving your record";
		echo $msg;
	}
else
	{
		header ("location:index.php?p=add_banner");
	}						
}	
?>