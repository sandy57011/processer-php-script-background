<?
$Shopinvoice = '<table width="98%" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F">
  <tr>
    <td align="center" bgcolor="#CCCCCC"><strong>Sn.</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Product Title </strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Quantity</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Price</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Discount</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Total</strong></td>
  </tr>';
  
  	$ctl =1;
		$Pquery = "select * from orders where orderid = '".$_REQUEST[orderid]."' and shopid = '".$Iarray[shopid]."'";
		$Presult = mysql_query($Pquery) or die(mysql_error());
		$intQTY = 0;
		while($Parray = mysql_fetch_array($Presult)){
			$SQl = "select * from products where products_id = '".$Parray[itemsid]."'";
			$RES = mysql_query($SQl) or die(mysql_error());	
			$ARR = mysql_fetch_array($RES);
  
 $Shopinvoice .= '<tr>
    <td align="center">'.$ctl++.'</td>
    <td align="center">'.$ARR[product_title].'</td>
    <td align="center">'.$Parray[quantity].'</td>
    <td align="center">'.$ARR[products_price].'</td>
    <td align="center">'.$ARR[customerdiscount].'</td>';
    	 $GrandTot = (($Parray[quantity]*$ARR[products_price]));
							if($ARR[customerdiscount]!=0){
							$GrandTot =$GrandTot - ($GrandTot*$ARR[customerdiscount]/100);
							 $Shopinvoice .='<td align="center">$'.$GrandTot.'</td>';
							}else{
							 $Shopinvoice .='<td align="center">$'.$GrandTot.'</td>';
 							}			
 						  $intQTY=$intQTY+$GrandTot;
   $Shopinvoice .= '</tr>';
   }
  $Shopinvoice .=  '<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><strong>Total</strong></td>
    <td>'.$intQTY.'</td>
  </tr>
</table>';
?>
