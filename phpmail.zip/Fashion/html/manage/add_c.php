<?
function generateThumb($file,$org_path,$thumbPath,$thumbW,$thumbH) {
		if (!empty($file)) {
			// set parameters needed for creating the thumb
			$sourcefile =$org_path.'/'.$file;
			$destfile = $thumbPath.'/'.$file;

			// check if thumb folder exists, if it doesnt we create it
			if (!file_exists($Path)) {
				@mkdir($Path, 0755);
			}
			// Create thumbnail
			$img_size = getimagesize($sourcefile);	
		   if ($img_size[0] > $thumbW|| $img_size[1] > $thumbH) {
			  $create_thumb =resize_image($sourcefile, $destfile, $thumbW, $thumbH, 0);
		   }else{
			  $create_thumb =resize_image($sourcefile, $destfile, $img_size[0], $img_size[1] , 0);
		   }
			if ($create_thumb === true) {
				//echo "Thumbnail generated successfully.";
				return $file;
			}
			else {
				echo "ERROR: Thumbnail could not be generated.";
				return $file;
			}
		 
		
		}else {
			echo "No file selected to generate thumbnail.";
		}
	}
		function resize_image($sourcefile, $destfile, $forcedwidth=85, $forcedheight=60, $imgcomp=0)  {
		// $imgcomp es la compresion que le damos. 0 best quality | 100 worst quality
		$g_imgcomp = 100-$imgcomp;
		$g_srcfile = $sourcefile;
		$g_dstfile = $destfile;
		$g_fw = $forcedwidth;
		$g_fh = $forcedheight;
		
		if(file_exists($g_srcfile)) {
			$g_is = getimagesize($g_srcfile); // sacamos informacion sobre la imagen large_photo
			$src_width = $g_is[0];
			$src_height = $g_is[1];
			$src_type = $g_is[2]; // 1 = GIF, 2 = JPG, 3 = PNG
			
			if(($src_width-$g_fw)>=($src_height-$g_fh)) {
				$g_iw = $g_fw;
				$g_ih = ($g_fw/$src_width)*$src_height;
			}
			else {
				$g_ih = $g_fh;
				$g_iw = ($g_ih/$src_height)*$src_width;   
			}
			
			$img_src = img_create_from_file($g_srcfile, $src_type);
			$img_dst = img_create($g_iw, $g_ih, $src_type);
			imagecopyresampled($img_dst, $img_src, 0, 0, 0, 0, $g_iw, $g_ih, $src_width, $src_height);
			img_output($img_dst, $g_dstfile, $g_imgcomp, $src_type);
			imagedestroy($img_dst);
			//create_img_border($g_dstfile, $src_type); // draw border
			return true;
		}
		else
		return false;
	}
	function generateImage($file,$org_path,$Path,$W,$H) {
		if (!empty($file)) {
			// set parameters needed for creating the thumb
			$sourcefile =$org_path.'/'.$file;
			$destfile = $Path.'/'.$file;

			// check if thumb folder exists, if it doesnt we create it
			if (!file_exists($Path)) {
				@mkdir($Path, 0755);
			}
			
			// Create thumbnail
			$img_size = getimagesize($sourcefile);			
		    if ($img_size[0] > $W|| $img_size[1] > $H) {
  			   $create_image =resize_image($sourcefile, $destfile, $W, $H, 0);
			}else{
			  $create_image =resize_image($sourcefile, $destfile, $img_size[0], $img_size[1], 0);
			}
			if ($create_image === true) {
				//echo "Image generated successfully.";
				return $file;
			}
			else {
				echo "ERROR: Image could not be generated.";
				return $file;
			}
		}else {
			echo "No file selected to generate Image.";
		}
	}
	function img_create_from_file($g_srcfile, $src_type) {
		ini_set('memory_limit', '32M');
		switch ($src_type) {
			case 1: // for gif
				$a = imagecreatefromgif($g_srcfile);
				return $a;
			case 2: // for jpeg
				$a = imagecreatefromjpeg($g_srcfile);
				return $a;
			case 3: // for png
				$a = imagecreatefrompng($g_srcfile);
				return $a;
		}	
	}
	
	function img_create($g_iw, $g_ih, $src_type) {
		switch ($src_type) {
			case 1: // for gif
				$a = imagecreate($g_iw,$g_ih);
				return $a;
			case (2 || 3): // for jpeg and png
				$a = imagecreatetruecolor($g_iw,$g_ih);
				return $a;
		}		
	}
	function img_output($img_dst, $g_dstfile, $g_imgcomp, $src_type) {
		switch ($src_type) {
			case 1: // for gif
				imagegif($img_dst, $g_dstfile); // for gif
				break;
			case 2: // for jpeg
				imagejpeg($img_dst, $g_dstfile, $g_imgcomp); // for jpeg
				break;
			case 3: // for png
				$g_imgcomp /= 10;
				if($g_imgcomp > 9) $g_imgcomp = 9;
				imagepng($img_dst, $g_dstfile, $g_imgcomp); // for png
				break;
		}		

	} 
if($_REQUEST[ndn]==1)
{

$intFile=mt_rand();
		if($_FILES[browse][name]!="")
		{
		move_uploaded_file($_FILES["browse"]["tmp_name"],"../large_image/".$intFile.$_FILES["browse"]["name"]);
		$Imagname=$intFile.$_FILES["browse"]["name"];
 $thumb=generateThumb($Imagname,"../large_image/","../g_image",100,100);
$middle=generateImage($Imagname,"../large_image/","../large_image",400,400);
		 
 		}
		else
		{
		$Imagname = '';
		}
$Query = "insert into g_image  set cname = '".$_REQUEST[cname]."',year='".$_REQUEST[year]."',ccity='".$_REQUEST[ccity]."',work_shop_ex='".$_REQUEST[work_shop_ex]."',school='".$_REQUEST[school]."',cimage='".$Imagname."',status=1";
 $Result = mysql_query($Query) or die(mysql_error());
         echo "Sucssesfuly submitted";
		 header("Location:home.php?PageURL=g_image");
		 }
		  
 
?>

<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="return validate()">
  <tr height="26" class="headM txtcol">
    <td width="78%" align="center"  >Add Photo </td>
    <td width="22%">  &nbsp; </td>
  </tr>
  <tr>
       <td colspan="2"><table width="100%"  border="0" cellspacing="2" cellpadding="0" >
           <tr>
             <td width="46%" height="30"  align="right">  Name </td>
             <td width="1%" align="center">:</td>
            <td width="53%"> <input name="cname" type="text" id="cname" style="width:300px;">            </td>
         </tr>
           
           <tr>
             <td align="right">Image</td>
             <td align="center">&nbsp;</td>
             <td><input type="file" name="browse" />
             Max Size Up to 2mb </td>
           </tr>
          
          <tr>
            <td align="right">&nbsp;</td>
            <td colspan="2">
              <input name="btnchange" type="submit" id="btnchange" value="Add" class="btnstyle">
            <input name="ndn" type="hidden" id="ndn" value="1">            </td>
          </tr>
      </table></td>
  </tr>
  </form>
</table>
  <script language="javascript">
function validate()
{
   if (document.form1.newstitle.value=="")
	{
		alert("Enter news title");
		document.form1.newstitle.focus();
		return false;
	}

  	if (document.form1.newsdescript.value=="")
	{
		alert("Enter news description");
		document.form1.newsdescript.focus();
		return false;
	}
 
	if (document.form1.newsstatus.value=="")
	{
		alert("Enter news status");
		document.form1.newsstatus.focus();
		return false;
	}
 
 }
 
 </script>
    