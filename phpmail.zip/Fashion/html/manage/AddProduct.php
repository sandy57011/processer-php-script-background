<?
 if($_REQUEST[btnSubmit]){
 $other="";
   for($n=0;$n<count($_REQUEST[other]);$n++)
  {
    if($n>0)
   $other.=", ".$_REQUEST[other][$n];
   else
   $other.=$_REQUEST[other][$n];
   }
  	 $intFile=mt_rand();
if($_FILES[ProductFile][name]!="")
	{ 
		$filename = "product_file/".$intFile.$_FILES[ProductFile][name];
 		move_uploaded_file($_FILES[ProductFile][tmp_name],"../".$filename);
	}
else{	$filename="";	}
if($_FILES[articleFile2][name]!="")
	{ $filename1 = "product_file/".$intFile.$_FILES[articleFile2][name];
 		move_uploaded_file($_FILES[articleFile2][tmp_name],"../".$filename1);
	}
else{	$filename1="";	}
if($_FILES[articleFile3][name]!="")
	{ 
	$filename2 = "product_file/".$intFile.$_FILES[articleFile3][name];
 		move_uploaded_file($_FILES[articleFile3][tmp_name],"../".$filename2);
	}
else{	$filename2="";	} 
/** new added**/
if($_FILES[articleFile4][name]!="")
	{ 
	$filename3 = "product_file/".$intFile.$_FILES[articleFile3][name];
 		move_uploaded_file($_FILES[articleFile4][tmp_name],"../".$filename3);
	}
else{	$filename3="";	} 

if($_FILES[articleFile5][name]!="")
	{ 
	$filename4 = "product_file/".$intFile.$_FILES[articleFile4][name];
 		move_uploaded_file($_FILES[articleFile5][tmp_name],"../".$filename4);
	}
else{	$filename4="";	} 


 
 /**icon image code**/
 $intFile=mt_rand();
	 if($_FILES["icon1"]["name"]!=""){
 	$icon1 = "icon1/".$intFile.$_FILES[icon1][name];					
move_uploaded_file($_FILES[icon1][tmp_name],"../".$icon1);
  				}else{
				$icon1='';
				}
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon2"]["name"]!=""){
 	$icon2 = "icon2/".$intFile.$_FILES[icon2][name];					
move_uploaded_file($_FILES[icon2][tmp_name],"../".$icon2);
  				}else{
				$icon2='';
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon3"]["name"]!=""){
 	$icon3 = "icon3/".$intFile.$_FILES[icon3][name];					
move_uploaded_file($_FILES[icon3][tmp_name],"../".$icon3);
  				}else{
				$icon3='';
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon4"]["name"]!=""){
 	$icon4 = "icon4/".$intFile.$_FILES[icon4][name];					
move_uploaded_file($_FILES[icon4][tmp_name],"../".$icon4);
  				}else{
				$icon4='';
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon5"]["name"]!=""){
 	 	$icon5 = "icon5/".$intFile.$_FILES[icon5][name];					
move_uploaded_file($_FILES[icon5][tmp_name],"../".$icon5);
  				}else{
				$icon5='';
				}																
				
 /*****/ 
$product_make = $_POST[product_make];
 foreach($product_make as $tt){
 	if($tt!="") { 
 	$product_makefav .=",".$tt;
	}
 }
$product_makefav = substr($product_makefav,1); 

if($_REQUEST[weightUnit]=="") {
$weightUnitins = $_REQUEST[customweightUnit];
} else {
$weightUnitins = $_REQUEST[weightUnit];
}
/******************   Product Option Array Value Start    *****************/
$productoptionid = $_POST['productoptionid'];
$optionIdArray = "";
$product_option_field_array = "";
for($i=0;$i<sizeof($productoptionid);$i++) {
 
$posttext = "optionarr".$productoptionid[$i];

$posttextnn = $_POST[$posttext];

if($posttextnn!="") {
$optionIdArray .=",".$productoptionid[$i];
$product_option_field_array .=",".$posttextnn;
}
}
$optionIdArray = substr($optionIdArray,1);
$gotidarray = explode(",",$optionIdArray);
sort($gotidarray);
foreach($gotidarray as $key => $value) {
		$optionvalueidtt11id = $value;
		if($optionvalueidtt11id!="") {
		$searchoptionid11id .=",".$optionvalueidtt11id;		
		}
	}
$searchoptionidsubstr11id = substr($searchoptionid11id,1);	
$optionIdArraynew = $searchoptionidsubstr11id;
 
$product_option_field_array = substr($product_option_field_array,1);

$gotarray = explode(",",$product_option_field_array);
sort($gotarray);
//$searchoptionidsubstrExplode1 = explode()
//print_r($gotarray);

foreach($gotarray as $key => $value) {
		$optionvalueidtt11 = $value;
		if($optionvalueidtt11!="") {
		$searchoptionid11 .=",".$optionvalueidtt11;		
		}
	}
$searchoptionidsubstr11 = substr($searchoptionid11,1);	
$product_option_field_arraynew = $searchoptionidsubstr11;

/******************   Product Option Array Value End    ******************/
		$sql = "INSERT INTO products set input_url = '".$_REQUEST[input_url]."', Seo_Project_Title = '".$_REQUEST[Seo_Project_Title]."', Seo_Project_Description = '".$_REQUEST[Seo_Project_Description]."',  products_model = '".$_REQUEST[products_model]."',product_make = '".$product_makefav."',product_title = '".addslashes($_REQUEST[ProductTitle])."',product_title1 = '".addslashes($_REQUEST[ProductTitle1])."',products_price = '".$_REQUEST[productprice]."',products_oldprice = '".$_REQUEST[productOldPrice]."',  products_date_added = '".time()."', Description= '".$_REQUEST[productSummary]."',  products_quantity_order_min = '".$_REQUEST[minorder]."', master_categories_id = '".$_REQUEST[productCat]."', products_status = '".$_REQUEST[productStatus]."', products_offer = '".$_REQUEST[productOffer]."', products_isFeatured = '".$_REQUEST[productFeatured]."',authorsummary = '".$_REQUEST[authorsummary]."',author = '".$_REQUEST[author]."',sibn = '".$_REQUEST[sibn]."',npage = '".$_REQUEST[npage]."',cover = '".$_REQUEST[cover]."',rarebooks = '".$_REQUEST[rarebooks]."',products_image ='".$filename."',products_image2 ='".$filename1."',products_image3 ='".$filename2."',products_image4 ='".$filename3."',products_image5 ='".$filename4."',dltime = '".$_REQUEST[dltime]."',stock = '".$_REQUEST[stock]."',brand = '".$_REQUEST[brand]."',mrpprice = '".$_REQUEST[mrpprice]."',shortdesc = '".$_REQUEST[shortdesc]."',specification = '".$_REQUEST[specification]."',icon1 ='".$icon1."',icon2 ='".$icon2."',icon3 ='".$icon3."',icon4 ='".$icon4."',icon5 ='".$icon5."',emdvedio='".$_REQUEST[emdvedio]."', weight_qty='".$_REQUEST[productWeight]."', weight_unit='".$weightUnitins."', product_option_field_array = '".$product_option_field_arraynew."', product_option_ids = '".$optionIdArraynew."', freeproduct = '".addslashes($_REQUEST['freeproduct'])."'"; 
		echo $sql;
		mysql_query($sql) or die(mysql_error());
		
$insid = mysql_insert_id(); 
mysql_query("update products set p_id = '".$insid."' where products_id = '".$insid."'") or die(mysql_error());

$input_url = $_REQUEST[input_url];
if($input_url=="") {
$input_url = "detail-itid-".$insid."-catid-".ucwords($_REQUEST[productCat]);
//mysql_query("update products set input_url = '".$input_url."' where products_id = '".$insid."'") or die(mysql_error());
} 	 	 
 		//$Msg="<li>Article Successfully Addes";	
		  header("Location:home.php?PageURL=AddProduct&cid=$_REQUEST[productCat]&cname=$_REQUEST[cname]&intMSG=<li>Product Successfully Added");
	
}
 
?>
<link href="images/class.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script> 


<h1>Add Product </h1>
<table width="100%" border="0" cellpadding="3" cellspacing="0"  >
  <tr> 
    <form action="" method="post" enctype="multipart/form-data" name="frmArticle" id="frmArticle" onSubmit="javascript:return check()">
      <td class="tableBorderDarkGrey"> 
        <table width="100%"  border="0" cellpadding="0" cellspacing="0"  class="text" >
          <?
	 if($Msg!="" or $_REQUEST[intMSG]!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" align="left" class="errortext"> 
              <?=$Msg?><?=$_REQUEST[intMSG]?>            </td>
          </tr>
          <? }?>
          
		    
            <tr>
              <td colspan="2">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tbl1">
                  <tr align="center"  >
                    <th width="21%" align="right"><span class="style3">*</span><strong>Category Name :</strong></th>
                    <th width="79%" align="left"><? 
 				if($_REQUEST[cid]==""){?>
                        <select name="productCat" id="select2" class="textbox">
                          <option value="" selected="selected">Select</option>
                          <?
							$sql3="select * from categories where pid=0";
							$rs3=mysql_query($sql3);
							//cid, cname, pid, Childs, LevelFromRoot
							while ($row3 = mysql_fetch_array($rs3))
							{
							$AccumulatedNodes= array();
							$NodeLevel= array();
							$NodesToTraverse= array();
							$NodesExpire= array();
							
								
 								array_unshift($AccumulatedNodes, $row3[cid]);
								array_unshift($NodesToTraverse, $row3[cid]);
   								while(count($NodesToTraverse)>0)
								{
									$OpenNodeId=array_shift($NodesToTraverse);
									array_push($NodesExpire, $OpenNodeId);
									$query4="select * from categories where cid=$OpenNodeId";
									$res4=mysql_query($query4);
									$row4 = mysql_fetch_array($res4);
									if($row4[Childs]!="")
									{
										$Childs= array();
										$Childs=explode(',', $row4[Childs]);
										$NumChilds=count($Childs)-1;
										for($i=$NumChilds-1;$i>=0;$i--)
										{
 											array_unshift($AccumulatedNodes, $Childs[$i]);
											array_unshift($NodesToTraverse, $Childs[$i]);
										}
										unset($Childs);
									}
  								}
								$AccumulatedNodes = array_reverse($AccumulatedNodes, false);
								reset($NodesExpire);
								for($i=0;$i<count($NodesExpire);$i++)
								{
									$query5="select * from categories where cid=$NodesExpire[$i]";
									$res5=mysql_query($query5);
									$row5 = mysql_fetch_array($res5);
 									?>
                          <option value="<?=$row5[cid]?>" <? if($row5[cid]==$_REQUEST[productCat]){?>selected <? }?> >
                          <? for($j=0;$j<$row5[LevelFromRoot];$j++){ echo ">"; } ?>
                          <?=$row5[cname]?>
                          </option>
                          <?
								}
 							unset($AccumulatedNodes, $NodeLevel, $NodesToTraverse, $NodesExpire);
							}																									
							?>
                        </select>
                        <? }else{
				 $sql3="select * from categories where cid='".$_REQUEST[cid]."'";
				 $rs3=mysql_query($sql3) or die(mysql_error());
				$Ar3 = mysql_fetch_array($rs3);
				  	echo stripslashes($Ar3[cname]);
				  ?>
                        <input name="productCat" type="hidden" value="<?=$_REQUEST[cid]?>" />
                        <? }?>                    </th>
                  </tr>
                  <tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Name</strong> :</strong></td>
                    <td align="left"><input name="ProductTitle" type="text" class="txtbox1" id="ProductTitle" value="<?=$_REQUEST[ProductTitle]?>" size="30" maxlength="255" /></td>
                  </tr>
                  
                  <tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Title</strong> :</strong></td>
                    <td align="left"><input name="ProductTitle1" type="text" class="txtbox1" id="ProductTitle1" value="<?=$_REQUEST[ProductTitle1]?>" size="30" maxlength="255" /></td>
                  </tr>
                  <?php /*?><tr align="center"  >
                    <td align="right"><strong> <span class="style3"> </span><strong> Flavour </strong> :</strong></td>
                    <td align="left"><select name="product_make[]" size="5" class="selbox" id="product_make" multiple="multiple" style="height:60px;">
                        <!-- ************************ Start  Code for select category ***************-->
                        <option  value="">Select flavour</option>
                        <? $makeSql= "select * from flavour ORDER BY name";
 			$makeResult = mysql_query($makeSql) or die(mysql_error());
		while($makeArrayC = mysql_fetch_array($makeResult)){
	  ?>
                        <option value="<?=$makeArrayC[cid]?>"  style="font-size:12px;" <? if($makeArrayC[cid]==$_REQUEST[product_make]){ echo "selected"; }else{?> <? } ?>>
                        <?=$makeArrayC[name]?>
                        </option>
                        <? }?>
                    </select></td>
                  </tr><?php */?>
                  <?php /*?><tr align="center"  >
              <td align="right"><strong> <span class="style3"> </span><strong> Model Name</strong> :</strong></td>
              <td align="left"><select name="products_model" size="1" class="textfield3" id="products_model">
              <!-- ************************ Start  Code for select category ***************-->
              <option  value="">Select model</option>
              <? $modelSql= "select * from model  ";
 			$modelResult = mysql_query($modelSql) or die(mysql_error());
		while($modelArrayC = mysql_fetch_array($modelResult)){
	  ?>
              <option value="<?=$modelArrayC[cid]?>"  style="font-size:12px;" <? if($modelArrayC[cid]==$_REQUEST[products_model]){ echo "selected"; }else{?> <? } ?>>
              <?=$modelArrayC[name]?>
              </option>
              <? }?>
            </select></td>
            </tr><?php */?>
                  <tr align="left"  >
                    <td align="right"><span class="style3">* </span><strong>Brand Name : </strong></td>
                    <td><select name="brand" size="1" class="selbox" id="brand">
                        <!-- ************************ Start  Code for select category ***************-->
                        <option  value="">Select Brand</option>
                        <? $Sql= "select * from brand order by name";
 			$Result = mysql_query($Sql) or die(mysql_error());
		while($ArrayC = mysql_fetch_array($Result)){
	  ?>
                        <option value="<?=$ArrayC[cid]?>"  style="font-size:12px;" <? if($ArrayC[cid]==$_REQUEST[brand]){ echo "selected"; }else{?> <? } ?>>
                        <?=stripslashes($ArrayC[name])?>
                        </option>
                        <? }?>
                    </select></td>
                  </tr>
                </table>              </td>
          </tr>
          <tr align="center"  >
              <td align="right">&nbsp;</td>
              <td align="left">&nbsp;</td>
            </tr>
            
          
		    <tr align="center"  >
		      <td colspan="2" align="left">
              <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tbl1">
<tr align="center"  >
            <th colspan="2" align="left"><span class="style3">* </span><strong>Add Url & Meta Tags </strong></th>
</tr>          
			 <!--<tr  >
            <td width="21%" align="right"><strong><span class="style3">*</span> Input Url : </strong></td>
            <td width="79%"><input name="input_url" type="text" class="txtbox1" /> 
            (Type product name without space)</td>
          </tr>-->  
		   <tr  >
            <td align="right"><strong>Seo Project Title : </strong></td>
            <td><textarea name="Seo_Project_Title" class="txtarea1"></textarea></td>
          </tr>  
		   <tr  >
            <td align="right"><strong>Seo Project Description : </strong></td>
            <td><textarea name="Seo_Project_Description" class="txtarea1"></textarea></td>
          </tr>   
		  <tr  >
            <td align="right"><strong>Seo Project Keyword : </strong></td>
            <td><textarea name="Seo_Project_Keyword" class="txtarea1"></textarea></td>
          </tr>
</table>              </td>
	      </tr>
            <tr align="center"  >
              <td align="right">&nbsp;</td>
              <td align="left">&nbsp;</td>
            </tr>
            <tr align="center"  >
              <td colspan="2">
              <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tbl1">
  <tr>
   <th colspan="2" align="left"><span class="style3">* </span><strong>Product Detail </strong></th>
          </tr>                    
          
           <tr  >
            <td align="right"><strong>Product Image 1 : </strong></td>
            <td><input name="ProductFile" type="file"   id="ProductFile"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Product  Image 2 : </strong></td>
            <td><input name="articleFile2" type="file" id="articleFile2" /></td>
          </tr>
          <tr  >
            <td align="right"><strong>Product Image 3 : </strong></td>
            <td><input name="articleFile3" type="file" id="articleFile3" /></td>
          </tr>
		  <tr  >
            <td align="right"><strong>Product  Image 4 : </strong></td>
            <td><input name="articleFile4" type="file" id="articleFile4" /></td>
          </tr>
		  <tr  >
            <td align="right"><strong>Product Image 5 : </strong></td>
            <td><input name="articleFile5" type="file" id="articleFile5" /></td>
          </tr>
   

          <!--<tr  >
            <td align="right"><strong>SKU : </strong></td>
            <td><input name="sibn" type="text" class="txtbox1" id="sibn" /></td>
          </tr>-->
          
          <tr  >
            <td align="right"><strong>MRP Price : </strong> </td>
            <td><input name="productprice" type="text" class="txtbox1" id="productprice" value="<?=$_REQUEST[productprice]?>" size="10"></td>
          </tr>
          <tr  >
            <td align="right"><strong>OLD </strong><strong>Price : </strong> </td>
            <td><input name="productOldPrice" type="text" class="txtbox1" id="productprice" value="" size="10"></td>
          </tr>
          <tr>
            <td align="right"><strong> Offer Product  : </strong></td>
            <td><input name="productOffer" type="checkbox" class="textbox" id="articleStatus" value="1" <? if($_REQUEST[products_offer]==1){?>checked <? }?>></td>
          </tr>
          <tr  >
            <td align="right"><strong>Stock : </strong></td>
            <td><input name="stock" type="radio" value="1" <? if ($_REQUEST[stock]=="1") {?> checked="checked" <? } ?> />
              <strong> In Stock</strong>
              <input name="stock" type="radio" value="0" <? if ($_REQUEST[stock]=="0") {?> checked="checked" <? } ?> />
              <strong>Out of Stock </strong></td>
          </tr>
          <tr  >
            <td align="right"><strong>Delivery Time : </strong></td>
            <td><input name="dltime" type="text" class="txtbox1" id="dltime" value="<?=$_REQUEST[dltime]?>" /></td>
          </tr>
      
          
          <tr align="center"  >
            <td align="right"><strong>Embed Code : </strong></td>
            <td align="left"><textarea name="emdvedio" class="txtarea1" id="emdvedio"></textarea></td>
          </tr>
          <tr>
            <td align="right"><strong> Offer Free Product  : </strong></td>
            <td><input name="freeproduct" type="text" class="txtbox1" id="freeproduct" value="" /></td>
          </tr>
          <tr align="center"  >
            <td align="right"><strong> View Product  : </strong></td>
            <td align="left"><input name="productStatus" type="checkbox" class="textbox" id="productStatus" value="1" <? if($_REQUEST[productStatus]==1){?>checked <? }?>></td>
          </tr>
          <!--<tr>
            <td align="right"><strong> Product Weight : </strong></td>
            <td><input name="productWeight" type="text" class="txtbox1" id="productWeight" value="<?=$_REQUEST[productWeight]?>"> &nbsp;&nbsp;
            <select name="weightUnit" class="selbox" id="weightUnit" style="width:80px;">
            <option value="" selected="selected">-- Select --</option>
            	<option value="gm" <? if($_REQUEST[weightUnit]=='gm'){?> selected="selected" <? }?>>gm</option>
                <option value="kg"<? if($_REQUEST[weightUnit]=='kg'){?> selected="selected" <? }?> >kg</option>
                <option value="lb" <? if($_REQUEST[weightUnit]=='lb'){?> selected="selected" <? }?>>lb</option>
                <option value="tablets" <? if($myRows[weight_unit]=='tablets'){?> selected="selected" <? }?>>tablets</option>
                <option value="capsules" <? if($myRows[weight_unit]=='capsules'){?> selected="selected" <? }?>>capsules</option>
            </select> 
             &nbsp;&nbsp;<input type="text" name="customweightUnit" id="customweightUnit" value="" />
                       </td>
  </tr>-->
</table>

              </td>
            </tr>
            
 	


          <tr align="center"  >
		      <td colspan="2" align="left">
              <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td colspan="2" align="center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2" align="left"><h2><span class="style3">* </span><strong> About Product:</strong></h2></td>
              </tr>
              <tr>
                <td colspan="2" align="center"> <textarea id="shortdesc" name="shortdesc" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[shortdesc]?></textarea></td>
              </tr>
			  <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'shortdesc',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
             <?php /*?> <tr>
                <td colspan="2" align="center"><span class="style3"> </span> 
                   <span class="style3">* </span><strong> About Product : </strong> </td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                <textarea id="productSummary" name="productSummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[productSummary]?></textarea></td>
                </tr><?php */?> <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'productSummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
	      </tr>
		  <tr align="center"  >
		      <td colspan="2" align="left"><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="text">
              <tr>
                <td colspan="2" align="center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2" align="left"><h2><span class="style3">* </span><strong> Product Feature  : </strong></h2></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                <textarea id="authorsummary" name="authorsummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[authorsummary]?></textarea></td>
                </tr> <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'authorsummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
	      </tr>
		  <tr align="center"  >
		      <td colspan="2" align="left"><table width="100%"  border="0" cellpadding="0" cellspacing="0" class="text">
              <tr>
                <td colspan="2" align="center">&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2" align="left"><h2><span class="style3">* </span><strong> Product Specification  : </strong></h2></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                <textarea id="specification" name="specification" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$_REQUEST[specification]?></textarea></td>
                </tr> <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'specification',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
	      </tr>
          

          <?php /*?><tr  >
            <td align="right"><strong>Combos Mantra  Product :</strong></td>
            <td><input name="productFeatured" type="checkbox" class="textbox" id="productFeatured" value="1" <? if($_REQUEST[productFeatured]==1){?>checked <? }?>></td>
          </tr><?php */?>
          <tr align="center">
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr align="center">
            <td colspan="2">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" class="tbl1">
            <tr>
            <th colspan="2" align="left">&nbsp;</th>
            </tr>
              <!--------------   Option Array Listing Start  --------------------->
<?php
$allProductOption = getAllProductOption();
if(count(allProductOption)>0) {
foreach($allProductOption as $allProductOptionData) {
?>                
                  <tr align="center"  >
                    <td align="right"><span class="style3">* </span><strong> <span class="style3"> </span><strong> <?php echo $allProductOptionData['name']; ?></strong> :</strong></td>
                    <td align="left">
<!--------------   Option Field Array Listing Start  --------------------->
<?php
$allProductOptionField = getAllProductOptionField($allProductOptionData['op_id']);
if(count(allProductOptionField)>0) { ?>
<input type="hidden" name="productoptionid[]" id="productoptionid" value="<?php echo $allProductOptionData['op_id']; ?>">

<select name="optionarr<?php echo $allProductOptionData['op_id']; ?>">
<option value="">-- Select --</option>
<?php 
foreach($allProductOptionField as $allProductOptionFieldData) {
?>

<?php /*?><input type="checkbox" name=[<?php echo $allProductOptionData['op_id'] ?>][] id="" value="<?php echo $allProductOptionFieldData['id']; ?>">&nbsp;<?php */?>

<?php /*?><input type="radio" name="optionarr<?php echo $allProductOptionData['op_id']; ?>" value="<?php echo $allProductOptionFieldData['id']; ?>">&nbsp;<?php */?>
<!--<select name="optionarr<?php echo $allProductOptionData['op_id']; ?>">
	<option value="">-- Select --</option>
	<option value="<?php echo $allProductOptionFieldData['id']; ?>"></option>
</select>-->
<option value="<?php echo $allProductOptionFieldData['id']; ?>"><?php echo $allProductOptionFieldData['product_option_name']; ?></option>

<?php echo $allProductOptionFieldData['product_option_name']; ?>&nbsp;&nbsp;&nbsp;

<?php } ?>
</select>
<?php } ?>
	

<!--------------   Option Field Array Listing End  --------------------->               
                  
                    </td>
                  </tr>
<?php } } ?> 
<!--------------   Option Array Listing End  --------------------->  
            </table></td>
          </tr>
           
          <tr align="center"> 
            <td colspan="2" align="left">
			
			      <?php /*?><input name="btnBack2" type="button" id="btnBack3" value="   &lt;&lt; Back   "  class="btn1" onClick="javascript:location.href='home.php?PageURL=ManageCategory&catid=<?=$_REQUEST[cid]?>&cname=<?=$Ar3[cname]?>'"><?php */?>
			      <input name="btnSubmit" type="submit" id="btnSubmit" value="Add Product Now" class="btn1"></td>
          </tr>
      </table></td>
    </form>
  </tr>
</table>
<script language="javascript">
	function check()
	{
		if(document.frmArticle.productCat.value=="")	
			{
				alert("Please Select Product Category");
				document.frmArticle.productCat.focus();
				return false;
			}
  		if(document.frmArticle.ProductTitle.value=="")	
			{
				alert("Please Enter Product Name");
				document.frmArticle.ProductTitle.focus();
				return false;
			}	
		if(document.frmArticle.brand.value=="")	
			{
				alert("Please Select Brand");
				document.frmArticle.brand.focus();
				return false;
			}
		/*if(document.frmArticle.shortdesc.value=="")	
			{
				alert("Please Enter Product Short Desc");
				document.frmArticle.shortdesc.focus();
				return false;
			}
		if(document.frmArticle.authorsummary.value=="")	
			{
				alert("Please Enter Product feature");
				document.frmArticle.authorsummary.focus();
				return false;
			}
		if(document.frmArticle.specification.value=="")	
			{
				alert("Please Enter Product specification");
				document.frmArticle.specification.focus();
				return false;
			}*/					
 		
	}
	</script>