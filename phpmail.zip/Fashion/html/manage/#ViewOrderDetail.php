<?
if($_REQUEST[hdnstatus]==1){
		$Query1 = "select * from order_mem where id = '".$_REQUEST[id]."'";
		$MOResult = mysql_query($Query1) or die(mysql_error());
		$MOArray = mysql_fetch_array($MOResult);
		$shipping = $MOArray["shipprice"];
		$Packaging = $MOArray["Packingprice"];
			$SQL = "select * from customers where customers_id = '".$MOArray[memid]."'";
			$RES = mysql_query($SQL) or die(mysql_error()); 
			$Row = mysql_fetch_array($RES);
			$serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
   			$serverpath1= dirname(dirname($serverpath));
			
			$footer1 = $serverpath1."/img/footer01.JPG";
			$footer2 = $serverpath1."/img/footer02.JPG";
//////////////////////////////////////////////////////////////////
$invoice = '<table width="100%"  border="0" cellspacing="0" cellpadding="0" class="row11">
<tr align="left" bgcolor="#CCCCCC">
<td width="2%"><strong>Sn.</strong></td>
<td width="23%" nowrap bgcolor="#CCCCCC"><strong>Product Name </strong></td>
<td width="24%" height="20"><strong>Model</strong></td>
<td width="9%"><strong>Quantity</strong></td>
<td width="11%"><strong>Price</strong></td>
<td width="17%"><strong>discount</strong></td>
<td width="14%"><strong>Total</strong></td>
</tr>';
  	  $ctr = 1;
 		$query="select * from orders where orderid='".$MOArray[orderid]."' and waitstatus !=1";
		$result=mysql_query($query);
		while($result_rec=mysql_fetch_array($result)){	
		$itemsid=$result_rec["itemsid"];
		$id=$result_rec["id"];							
		$quantity=$result_rec["quantity"];
 			$sqlitems ="select * from products  where products_id=".$itemsid."";
			$itemsresult=mysql_query($sqlitems);
			$itemRows=mysql_fetch_array($itemsresult);
 $invoice .='<tr><td>'.$ctr.'</td>
            <td>'.$itemRows[product_title].'</td>
            <td>'.$itemRows[products_model].'</td>
            <td>'.$quantity.'</td>
            <td>Rs'.$itemRows[products_price].'</td>
            <td>'.$itemRows[discountpercentage].'% </td>';
 			 $GrandTot = (($quantity*$itemRows[products_price]));
							if($itemRows[discountpercentage]!=0){
							$GrandTot =$GrandTot - ($GrandTot*$itemRows[discountpercentage]/100);
							$invoice .='<td>Rs'.$GrandTot.'</td>';
							//echo "dfgdfgd".$GrandTot;
							}else{
							$invoice .='<td>Rs'.$GrandTot.'</td>';
							//echo "dsfd".$GrandTot;
							}			
 						  $intQTY=$intQTY+$GrandTot;
$invoice .=' </tr>';
		  $ctr=$ctr+1; }
		    
$invoice .='<tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>';
$invoice .='<tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><strong>Item Price</strong></td>
            <td>Rs'.$intQTY.'</td>
          </tr>';
$invoice .='<tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><strong>Shipping Cost </strong></td>
            <td>Rs'.$shipping.'</td>
          </tr>';
$invoice .='<tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td><strong>Packingprice  </strong></td>
            <td>Rs'.$Packaging.'</td>
          </tr>';
$invoice .='<tr bgcolor="#CCCCCC">
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td height="20">&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>Total</td>';
 			 $tot = $intQTY + $shipping + $Packaging;
 $invoice .=	'<td>Rs'.$tot.'</td>
          </tr>
        </table>';
		// echo $invoice;
////////////////////////////////////////////////////////////////////

  	if($_REQUEST[statuschart]==1){
	 	mysql_query("update order_mem set intPaid = 1 where id =".$_REQUEST['id']) or die(mysql_error());
		////////////////////////////////////////////////////////////////////////////////////
		$ShipQuery = mysql_query("select * from shipping_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$ShipArray = mysql_fetch_array($ShipQuery);
		
		$BillSQl = mysql_query("select * from billingaddress_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$BillResult = mysql_fetch_array($BillSQl);
  		$Body = '<style type="text/css">
<!--
.style1 {color: #F9EED0}
.style3 {color: #FBC00A}
-->
</style>

<table width="100%"  border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F ">
  <tr>
    <td ><table width="100%"  border="0" cellspacing="2" cellpadding="1">
      <tr>
        <td colspan="4"><table width="100%" border="0" cellspacing="0" cellpadding="0" background='.$headerbg.'>
          <tr>
            <td width="16%"><img src='.$imgpath.' ></td>
            <td width="84%">&nbsp;</td>
          </tr>
        </table></td>
        </tr>
      <tr bgcolor="#f9eed0">
        <td width="26%" valign="middle">North America SouqElArab Inc. Capitol Office Center 3422 Old Capitol Trail Unit 177, City of Wilmington Delaware 19808-6192 U.S. Of America </td>
        <td width="20%">Middle East SouqElArab Intl SARL Office 51, 6 th Floor St. George Center AlDekwaneh, Beirut Lebanon </td>
        <td width="20%">Postal Address: P. O. Box 1289 Amman , 11821 Jordan</td>
        <td width="20%">E-mail<a href="mailto:fadi.dababneh@smartbuyz.co.in">info@smartbuyz.co.in </a>Website<a href="http://www.smartbuyz.co.in">www.smartbuyz.co.in </a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><p>Dear '.$Row[username].', </p>
          <p>Welcome to smartbuyz.co.in Community. </p>
          <p>It is great to have you as part of the smartbuyz.co.in. Thank you for your order, summarized below, which has been approved and in progress. Any item that could not be placed, is also summarized </p></td>
      </tr>
      <tr>
        <td><table width="80%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #342D1F ">
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Invoice Number </strong></td>
                <td width="3%">&nbsp;</td>
                <td width="77%">'.$_SESSION[shoporderid].'</td>
              </tr>
              <tr>
                <td colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="50%"><strong>Shipping Address </strong></td>
                    <td><strong>Billing Address </strong></td>
                  </tr>
                  <tr>
                    <td>'.$ShipArray[name].'<br />
 '.$ShipArray[address1].'<br />
'.$ShipArray[address2].'<br />
'.$ShipArray[city].'<br />
'.$ShipArray[state].'<br /> 
'.$ShipArray[zipcode].'<br />
'.findcountry($ShipArray[country]).'<br />
'.$ShipArray[phone1].' +'.$ShipArray[std1].'<br />
'.$ShipArray[phone2].' +'.$ShipArray[std2].'</td>
                    <td>'.$BillResult[name].'<br />
 '.$BillResult[address1].'<br />
'.$BillResult[address2].'<br />
'.$BillResult[city].'<br />
'.$BillResult[state].'<br /> 
'.$BillResult[zipcode].'<br />
'.findcountry($BillResult[country]).'<br />
'.$BillResult[phone1].' +'.$BillResult[std1].'<br />
'.$BillResult[phone2].' +'.$BillResult[std2].'</td>
                  </tr>
                </table></td>
                </tr>
              <tr>
                <td><strong>Email:</strong></td>
                <td>&nbsp;</td>
                <td>'.$To.'</td>
              </tr>
              <tr>
                <td><strong>Payment:</strong></td>
                <td>&nbsp;</td>
                <td>Via PayPal</td>
              </tr>
              <tr>
                <td><strong>Comments:</strong></td>
                <td>&nbsp;</td>
                <td>'.$MOArray[comment].'</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td>'.$invoice.'</td>
          </tr>
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Orders from same customers </strong></td>

                <td width="3%">&nbsp;</td>
                <td width="77%">&nbsp;</td>
              </tr>
              <tr>
                <td><strong>Internal Notes: </strong></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><p>The next step is you receiving an e-mail confirming the order has been shipped. You can always track your order status through My Account. </p>
          <p>We highly recommend you: </p>
          <p>1. Update your profile by visiting My Account. </p>
          <p>Why: Introduce yourself to the community. Let people know what s unique about you. </p>
          <p>2. Invite your friends! </p>
          <p>Why: Shopping is way more fun with friends. </p>
          <p>Many features are coming your way, so look forward to Radio Stations from across the Arab region to listen to live, Blogs &amp; Forums, our Institutional Portal to learn more about the organizations across the world that exist to serve Arabs and Middle Easterns, electronic downloads like MP3 s, News Feed from all over the world, Instant Messaging and much much more. </p>
          <p>We have enjoyed building this site for you, hope you have fun on smartbuyz.co.in </p>
          <p>- </p>
          </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center"> <table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td >&nbsp;</td>
        <td width="442" align="center" > <span class="style3"><strong>One World . One Place . Yours </strong>
            <br>
            <strong>www.smartbuyz.co.in </strong></span>
          <p class="style1">&nbsp;</p>         </td>
        <td >&nbsp;</td>
      </tr>
    </table>  </td>
  </tr>
</table>';
// echo $Body ;	
			$To = $Row[customers_email_address];
			$Subject = "Your Payment is approved by webmaster : smartbuyz.co.in";
			$headers = "MIME-Version:1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From:support@smartbuyz.co.in <support@smartbuyz.co.in>\r\n";
			// echo $To. "<br>".$Subject. "<br>".$Body. "<br>".$headers;
			 mail($To,$Subject,$Body,$headers);
		
		
		////////////////////////////////////////////////////////////////////////////////////
	}
	if($_REQUEST[statuschart]==2){
		 	mysql_query("update order_mem set intPaid = 1, status = 1 where id =".$_REQUEST['id']) or die(mysql_error());
		$ShipQuery = mysql_query("select * from shipping_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$ShipArray = mysql_fetch_array($ShipQuery);
		
		$BillSQl = mysql_query("select * from billingaddress_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$BillResult = mysql_fetch_array($BillSQl);
  		$Body = '<!--
.style1 {color: #F9EED0}
.style3 {color: #FBC00A}
-->
</style>

<table width="100%"  border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F ">
  <tr>
    <td><table width="100%"  border="0" cellspacing="2" cellpadding="1">
      <tr>
        <td colspan="4"><table width="100%" border="0" cellspacing="0" cellpadding="0" background='.$headerbg.'>
          <tr>
            <td width="16%"><img src='.$imgpath.' ></td>
            <td width="84%">&nbsp;</td>
          </tr>
        </table></td>
        </tr>
      <tr bgcolor="#f9eed0">
        <td width="26%" valign="middle">North America SouqElArab Inc. Capitol Office Center 3422 Old Capitol Trail Unit 177, City of Wilmington Delaware 19808-6192 U.S. Of America </td>
        <td width="20%">Middle East SouqElArab Intl SARL Office 51, 6 th Floor St. George Center AlDekwaneh, Beirut Lebanon </td>
        <td width="20%">Postal Address: P. O. Box 1289 Amman , 11821 Jordan</td>
        <td width="20%">E-mail<a href="mailto:fadi.dababneh@smartbuyz.co.in">info@smartbuyz.co.in </a>Website<a href="http://www.smartbuyz.co.in">www.smartbuyz.co.in </a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><p>Dear '.$Row[username].', </p>
          <p>Welcome to smartbuyz.co.in Community. </p>
          It is great to have you as part of the smartbuyz.co.in. Thank you for your order, summarized below, which has been shipped. Any item that could not be placed, is also summarized </td>
      </tr>
      <tr>
        <td><table width="80%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #342D1F ">
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Invoice Number </strong></td>
                <td width="3%">&nbsp;</td>
                <td width="77%">'.$_SESSION[shoporderid].'</td>
              </tr>
              <tr>
                <td colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="50%"><strong>Shipping Address </strong></td>
                    <td><strong>Billing Address </strong></td>
                  </tr>
                  <tr>
                    <td>'.$ShipArray[name].'<br />
 '.$ShipArray[address1].'<br />
'.$ShipArray[address2].'<br />
'.$ShipArray[city].'<br />
'.$ShipArray[state].'<br /> 
'.$ShipArray[zipcode].'<br />
'.findcountry($ShipArray[country]).'<br />
'.$ShipArray[phone1].' +'.$ShipArray[std1].'<br />
'.$ShipArray[phone2].' +'.$ShipArray[std2].'</td>
                    <td>'.$BillResult[name].'<br />
 '.$BillResult[address1].'<br />
'.$BillResult[address2].'<br />
'.$BillResult[city].'<br />
'.$BillResult[state].'<br /> 
'.$BillResult[zipcode].'<br />
'.findcountry($BillResult[country]).'<br />
'.$BillResult[phone1].' +'.$BillResult[std1].'<br />
'.$BillResult[phone2].' +'.$BillResult[std2].'</td>
                  </tr>
                </table></td>
                </tr>
              <tr>
                <td><strong>Email:</strong></td>
                <td>&nbsp;</td>
                <td>'.$To.'</td>
              </tr>
              <tr>
                <td><strong>Payment:</strong></td>
                <td>&nbsp;</td>
                <td>Via PayPal</td>
              </tr>
              <tr>
                <td><strong>Comments:</strong></td>
                <td>&nbsp;</td>
                <td>'.$MOArray[comment].'</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td>'.$invoice.'</td>
          </tr>
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Orders from same customers </strong></td>

                <td width="3%">&nbsp;</td>
                <td width="77%">&nbsp;</td>
              </tr>
              <tr>
                <td><strong>Internal Notes: </strong></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><p>You can always track your order status through My Account. </p>
          <p>We highly recommend you: </p>
          <p>1. Update your profile by visiting My Account. </p>
          <p>Why: Introduce yourself to the community. Let people know what is unique about you. </p>
          <p>2. Invite your friends! </p>
          <p>Why: Shopping is way more fun with friends. </p>
          <p>Many features are coming your way, so look forward to Radio Stations from across the Arab region to listen to live, Blogs &amp; Forums, our Institutional Portal to learn more about the organizations across the world that exist to serve Arabs and Middle Easterns, electronic downloads like MP3 s, News Feed from all over the world, Instant Messaging and much much more. </p>
          <p>We have enjoyed building this site for you, hope you have fun on smartbuyz.co.in </p>
          </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td >&nbsp;</td>
        <td width="442" align="center" > <span class="style3"><strong>One World . One Place . Yours </strong>
            <br>
            <strong>www.smartbuyz.co.in </strong></span>
          <p class="style1">&nbsp;</p>         </td>
        <td >&nbsp;</td>
      </tr>
    </table>  </td>
  </tr>
</table>';
// echo $Body ;	
			$To = $Row[customers_email_address];
			$Subject = "Your Order is under process : smartbuyz.co.in";
			$headers = "MIME-Version:1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From:support@smartbuyz.co.in <support@smartbuyz.co.in>\r\n";
			// echo $To. "<br>".$Subject. "<br>".$Body. "<br>".$headers;
			 mail($To,$Subject,$Body,$headers);

	}
	if($_REQUEST[statuschart]==3){
		 	mysql_query("update order_mem set intPaid = 1, status = 1, shipped =1 where id =".$_REQUEST['id']) or die(mysql_error());
					
					$ShipQuery = mysql_query("select * from shipping_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$ShipArray = mysql_fetch_array($ShipQuery);
		
		$BillSQl = mysql_query("select * from billingaddress_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$BillResult = mysql_fetch_array($BillSQl);

			
   		$Body = '<!--
.style1 {color: #F9EED0}
.style3 {color: #FBC00A}
-->
</style>

<table width="100%"  border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F ">
  <tr>
    <td><table width="100%"  border="0" cellspacing="2" cellpadding="1">
      <tr>
        <td colspan="4"><table width="100%" border="0" cellspacing="0" cellpadding="0" background='.$headerbg.'>
          <tr>
            <td width="16%"><img src='.$imgpath.' ></td>
            <td width="84%">&nbsp;</td>
          </tr>
        </table></td>
        </tr>
      <tr bgcolor="#f9eed0">
        <td width="26%" valign="middle">North America SouqElArab Inc. Capitol Office Center 3422 Old Capitol Trail Unit 177, City of Wilmington Delaware 19808-6192 U.S. Of America </td>
        <td width="20%">Middle East SouqElArab Intl SARL Office 51, 6 th Floor St. George Center AlDekwaneh, Beirut Lebanon </td>
        <td width="20%">Postal Address: P. O. Box 1289 Amman , 11821 Jordan</td>
        <td width="20%">E-mail<a href="mailto:fadi.dababneh@smartbuyz.co.in">info@smartbuyz.co.in </a>Website<a href="http://www.smartbuyz.co.in">www.smartbuyz.co.in </a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><p>Dear '.$Row[username].', </p>
          <p>Welcome to smartbuyz.co.in Community. </p>
          It is great to have you as part of the smartbuyz.co.in. Thank you for your order, summarized below, which has been shipped. Any item that could not be placed, is also summarized </td>
      </tr>
      <tr>
        <td><table width="80%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #342D1F ">
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Invoice Number </strong></td>
                <td width="3%">&nbsp;</td>
                <td width="77%">'.$_SESSION[shoporderid].'</td>
              </tr>
              <tr>
                <td colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="50%"><strong>Shipping Address </strong></td>
                    <td><strong>Billing Address </strong></td>
                  </tr>
                  <tr>
                    <td>'.$ShipArray[name].'<br />
 '.$ShipArray[address1].'<br />
'.$ShipArray[address2].'<br />
'.$ShipArray[city].'<br />
'.$ShipArray[state].'<br /> 
'.$ShipArray[zipcode].'<br />
'.findcountry($ShipArray[country]).'<br />
'.$ShipArray[phone1].' +'.$ShipArray[std1].'<br />
'.$ShipArray[phone2].' +'.$ShipArray[std2].'</td>
                    <td>'.$BillResult[name].'<br />
 '.$BillResult[address1].'<br />
'.$BillResult[address2].'<br />
'.$BillResult[city].'<br />
'.$BillResult[state].'<br /> 
'.$BillResult[zipcode].'<br />
'.findcountry($BillResult[country]).'<br />
'.$BillResult[phone1].' +'.$BillResult[std1].'<br />
'.$BillResult[phone2].' +'.$BillResult[std2].'</td>
                  </tr>
                </table></td>
                </tr>
              <tr>
                <td><strong>Email:</strong></td>
                <td>&nbsp;</td>
                <td>'.$To.'</td>
              </tr>
              <tr>
                <td><strong>Payment:</strong></td>
                <td>&nbsp;</td>
                <td>Via PayPal</td>
              </tr>
              <tr>
                <td><strong>Comments:</strong></td>
                <td>&nbsp;</td>
                <td>'.$MOArray[comment].'</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td>'.$invoice.'</td>
          </tr>
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Orders from same customers </strong></td>

                <td width="3%">&nbsp;</td>
                <td width="77%">&nbsp;</td>
              </tr>
              <tr>
                <td><strong>Internal Notes: </strong></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><p>You can always track your order status through My Account. </p>
          <p>We highly recommend you: </p>
          <p>1. Update your profile by visiting My Account. </p>
          <p>Why: Introduce yourself to the community. Let people know what is unique about you. </p>
          <p>2. Invite your friends! </p>
          <p>Why: Shopping is way more fun with friends. </p>
          <p>Many features are coming your way, so look forward to Radio Stations from across the Arab region to listen to live, Blogs &amp; Forums, our Institutional Portal to learn more about the organizations across the world that exist to serve Arabs and Middle Easterns, electronic downloads like MP3 s, News Feed from all over the world, Instant Messaging and much much more. </p>
          <p>We have enjoyed building this site for you, hope you have fun on smartbuyz.co.in </p>
          </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td >&nbsp;</td>
        <td width="442" align="center" > <span class="style3"><strong>One World . One Place . Yours </strong>
            <br>
            <strong>www.smartbuyz.co.in </strong></span>
          <p class="style1">&nbsp;</p>         </td>
        <td >&nbsp;</td>
      </tr>
    </table>   </td>
  </tr>
</table>';
// echo $Body ;	
			$To = $Row[customers_email_address];
			$Subject = "Your Order is Delivered : smartbuyz.co.in";
			$headers = "MIME-Version:1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From:support@smartbuyz.co.in <support@smartbuyz.co.in>\r\n";
			// echo $To. "<br>".$Subject. "<br>".$Body. "<br>".$headers;
			 mail($To,$Subject,$Body,$headers);

	}
}
 /////////////////////////////////////////////////////////////////////////////////////////
if($_REQUEST[op]=='sendinvoice')
{
////////////////////////////////////////////////////////////////////////////////
$Query1 = "select * from order_mem where id = '".$_REQUEST[id]."'";
		$MOResult = mysql_query($Query1) or die(mysql_error());
		$MOArray = mysql_fetch_array($MOResult);
 			$SQL = "select * from customers where customers_id = '".$MOArray[memid]."'";
			$RES = mysql_query($SQL) or die(mysql_error()); 
			$Row = mysql_fetch_array($RES);
			$serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
   			$serverpath1= dirname(dirname($serverpath));
			
			$footer1 = $serverpath1."/img/footer01.JPG";
			$footer2 = $serverpath1."/img/footer02.JPG";
$ShipQuery = mysql_query("select * from shipping_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$ShipArray = mysql_fetch_array($ShipQuery);
		
		$BillSQl = mysql_query("select * from billingaddress_tbl where memid = '".$Row[customers_id]."'") or die(mysql_error());
		$BillResult = mysql_fetch_array($BillSQl);
////////////////////////////////////////////////////////////////////////////////
	$Iquery = "select distinct shopid from orders where orderid = '".$_REQUEST[orderid]."'";
	$Iresult = mysql_query($Iquery) or die(mysql_error());
	while($Iarray = mysql_fetch_array($Iresult)){
		$ShSql = "select * from shopper_tbl where shopid = '".$Iarray[shopid]."'";
		$ShRes = mysql_query($ShSql) or die(mysql_error());
		$ShArr = mysql_fetch_array($ShRes);
		////////////////////////////////////////////
		$Shopinvoice = '<table width="98%" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F">
  <tr>
    <td align="center" bgcolor="#CCCCCC"><strong>Sn.</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Product Title </strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Quantity</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Price</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Discount</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Total</strong></td>
  </tr>';
  
  	$ctl =1;
		$Pquery = "select * from orders where orderid = '".$_REQUEST[orderid]."' and shopid = '".$Iarray[shopid]."'";
		$Presult = mysql_query($Pquery) or die(mysql_error());
			$intQTY = 0;
		while($Parray = mysql_fetch_array($Presult)){
			$SQl = "select * from products where products_id = '".$Parray[itemsid]."'";
			$RES = mysql_query($SQl) or die(mysql_error());	
			$ARR = mysql_fetch_array($RES);
  
 $Shopinvoice .= '<tr>
    <td align="center">'.$ctl++.'</td>
    <td align="center">'.$ARR[product_title].'</td>
    <td align="center">'.$Parray[quantity].'</td>
    <td align="center">'.$ARR[products_price].'</td>
    <td align="center">'.$ARR[customerdiscount].'</td>';
    	 $GrandTot = (($Parray[quantity]*$ARR[products_price]));
							if($ARR[customerdiscount]!=0){
							$GrandTot =$GrandTot - ($GrandTot*$ARR[customerdiscount]/100);
							 $Shopinvoice .='<td align="center">$'.$GrandTot.'</td>';
							}else{
							 $Shopinvoice .='<td align="center">$'.$GrandTot.'</td>';
 							}			
 						  $intQTY=$intQTY+$GrandTot;
   $Shopinvoice .= '</tr>';
   }
  $Shopinvoice .=  '<tr bgcolor="#CCCCCC">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center"><strong>Total</strong></td>
    <td align="center">'.$intQTY.'</td>
  </tr>
</table>';
 		///////////////////////////////////////////////////////////////////////////
			
   		$Body = '<!--
.style1 {color: #F9EED0}
.style3 {color: #FBC00A}
-->
</style>

<table width="100%"  border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F ">
  <tr>
    <td><table width="100%"  border="0" cellspacing="2" cellpadding="1">
      <tr>
        <td colspan="4"><table width="100%" border="0" cellspacing="0" cellpadding="0" background='.$headerbg.'>
          <tr>
            <td width="16%"><img src='.$imgpath.' ></td>
            <td width="84%">&nbsp;</td>
          </tr>
        </table></td>
        </tr>
      <tr bgcolor="#f9eed0">
        <td width="26%" valign="middle">North America SouqElArab Inc. Capitol Office Center 3422 Old Capitol Trail Unit 177, City of Wilmington Delaware 19808-6192 U.S. Of America </td>
        <td width="20%">Middle East SouqElArab Intl SARL Office 51, 6 th Floor St. George Center AlDekwaneh, Beirut Lebanon </td>
        <td width="20%">Postal Address: P. O. Box 1289 Amman , 11821 Jordan</td>
        <td width="20%">E-mail<a href="mailto:fadi.dababneh@smartbuyz.co.in">info@smartbuyz.co.in </a>Website<a href="http://www.smartbuyz.co.in">www.smartbuyz.co.in </a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><p>Dear '.$Row[username].', </p>
          <p>Welcome to smartbuyz.co.in Community. </p>
          It is great to have you as part of the smartbuyz.co.in. Thank you for your order, summarized below, which has been shipped. Any item that could not be placed, is also summarized </td>
      </tr>
      <tr>
        <td><table width="80%"  border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #342D1F ">
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Invoice Number </strong></td>
                <td width="3%">&nbsp;</td>
                <td width="77%">'.$_SESSION[shoporderid].'</td>
              </tr>
              <tr>
                <td colspan="3"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="50%"><strong>Shipping Address </strong></td>
                    <td><strong>Billing Address </strong></td>
                  </tr>
                  <tr>
                    <td>'.$ShipArray[name].'<br />
 '.$ShipArray[address1].'<br />
'.$ShipArray[address2].'<br />
'.$ShipArray[city].'<br />
'.$ShipArray[state].'<br /> 
'.$ShipArray[zipcode].'<br />
'.findcountry($ShipArray[country]).'<br />
'.$ShipArray[phone1].' +'.$ShipArray[std1].'<br />
'.$ShipArray[phone2].' +'.$ShipArray[std2].'</td>
                    <td>'.$BillResult[name].'<br />
 '.$BillResult[address1].'<br />
'.$BillResult[address2].'<br />
'.$BillResult[city].'<br />
'.$BillResult[state].'<br /> 
'.$BillResult[zipcode].'<br />
'.findcountry($BillResult[country]).'<br />
'.$BillResult[phone1].' +'.$BillResult[std1].'<br />
'.$BillResult[phone2].' +'.$BillResult[std2].'</td>
                  </tr>
                </table></td>
                </tr>
              <tr>
                <td><strong>Email:</strong></td>
                <td>&nbsp;</td>
                <td>'.$To.'</td>
              </tr>
              <tr>
                <td><strong>Payment:</strong></td>
                <td>&nbsp;</td>
                <td>Via PayPal</td>
              </tr>
              <tr>
                <td><strong>Comments:</strong></td>
                <td>&nbsp;</td>
                <td>'.$MOArray[comment].'</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td>'.$Shopinvoice.'</td>
          </tr>
          <tr>
            <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="20%"><strong>Orders from same customers </strong></td>

                <td width="3%">&nbsp;</td>
                <td width="77%">&nbsp;</td>
              </tr>
              <tr>
                <td><strong>Internal Notes: </strong></td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><p>You can always track your order status through My Account. </p>
          <p>We highly recommend you: </p>
          <p>1. Update your profile by visiting My Account. </p>
          <p>Why: Introduce yourself to the community. Let people know what is unique about you. </p>
          <p>2. Invite your friends! </p>
          <p>Why: Shopping is way more fun with friends. </p>
          <p>Many features are coming your way, so look forward to Radio Stations from across the Arab region to listen to live, Blogs &amp; Forums, our Institutional Portal to learn more about the organizations across the world that exist to serve Arabs and Middle Easterns, electronic downloads like MP3 s, News Feed from all over the world, Instant Messaging and much much more. </p>
          <p>We have enjoyed building this site for you, hope you have fun on smartbuyz.co.in </p>
          </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td >&nbsp;</td>
        <td width="442" align="center" > <span class="style3"><strong>One World . One Place . Yours </strong>
            <br>
            <strong>www.smartbuyz.co.in </strong></span>
          <p class="style1">&nbsp;</p>         </td>
        <td >&nbsp;</td>
      </tr>
    </table>   </td>
  </tr>
</table>';
 // echo $Body ;	
			$To = $Row[customers_email_address];
			$Subject = "Product Order from : smartbuyz.co.in";
			$headers = "MIME-Version:1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From:support@smartbuyz.co.in <support@smartbuyz.co.in>\r\n";
			// echo $To. "<br>".$Subject. "<br>".$Body. "<br>".$headers;
			 mail($To,$Subject,$Body,$headers);
		
		
		///////////////////////////////////////////////////////////////////////////
	}
	
	

}
/////////////////////////////////////////////////////////////////////////////////////////



$query="select * from order_mem  where id =".$_REQUEST['id'];
$result=mysql_query($query);
$result_rec=mysql_fetch_array($result);
if($result_rec[status]==0 and $result_rec[shipped]==0 and $result_rec[intPaid]==0){
$Status= 'Pending';
	}
	if($result_rec[intPaid]==1 and $result_rec[shipped]==0 and $result_rec[status]==0){
	$Status= 'Processing';
 	}
	if($result_rec[intPaid]==1 and $result_rec[shipped]==0 and $result_rec[status]==1){
	$Status= 'Approved';
 	}
	if($result_rec[intPaid]==1 and $result_rec[shipped]==1 and $result_rec[status]==1){
	$Status= 'shipped';
 	}
	
	//echo "Order Status".$Status;
 ?>
 <TABLE  border=0 width=100%>
  <TR> 
    <TD align=left colspan=4 class="headR"><FONT COLOR="#FF0066">Order Detail</FONT></B></TD>
  </TR>
  <TR align="center"> 
    <TD width="25%" class="headR"><input name="btnBack" type="button" id="btnBack" value="Edit Order"  class="button1" onClick="javascript:location.href='home.php?PageURL=ViewOrderDetail&id=<?=$_REQUEST[id]?>&op=edit'"></TD>
    <TD width="25%" class="headR"><input name="btnBack" type="button" id="btnBack" value="Send Invoice To ShopKeeper"  class="button1" onClick="javascript:location.href='home.php?PageURL=ViewOrderDetail&orderid=<?=$result_rec[orderid]?>&id=<?=$_REQUEST[id]?>&op=sendinvoice'"></TD>
    <TD width="25%" class="headR"><input name="btnBack" type="button" id="btnBack" value="  Invoice  "  class="button1" onClick="javascript:location.href='home.php?PageURL=Invoice&OID=<?=$_REQUEST[id]?>'"></TD>
    <TD width="25%" class="headR"><input name="btnBack" type="button" id="btnBack" value="Packing slip"  class="button1" onClick="javascript:location.href='home.php?PageURL=PackingSlip&OID=<?=$_REQUEST[id]?>'"></TD>
  </TR>
  <? if($_REQUEST[op]=='edit'){?>
    <TR class="headR">
      <TD align=left  ><strong>Set Order Status </strong></TD>
      <TD align=left  ><form name="form1" method="post" action="">
        <select name="statuschart" id="statuschart" onChange="form1.submit()">
		 <option value="" selected>Set Order Status</option>
          <option value="1">Order Approved</option>
          <option value="2">Order In Process</option>
          <option value="3">Order Deliverd</option>
        </select>
        <input name="hdnstatus" type="hidden" id="hdnstatus" value="1">
      </form></TD>
      <TD align=left  >&nbsp;</TD>
      <TD align=left  >&nbsp;</TD>
    </TR>
	 
	<? }?>
     <TR> 
    <TD align=left colspan=4 >
	<table width="96%"  border="0" align="center" cellpadding="1" cellspacing="3">
  <TR class="headR">
    <TD height="30" align=left >User Detail</TD>
    <TD height="30" align=left >Payment Info: </TD>
  </TR>
  <TR class="row11"> 
    <td width="50%" valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr class="row11">
        <TD align=right width=26%><B>User Name :</B></TD>
    <TD width="56%" > 
     <?
		  $mem = loginquery('customers_id',$result_rec[memid]);
		  $ARR = mysql_fetch_array($mem);
		  echo $ARR[username];
		  ?> </TD>
  </TR>
  <TR class="row11"> 
    <TD align=right width=26%><b>Email :</b></TD>
    <TD width="56%"> 
	 <?=$ARR[customers_email_address]?>      </TD>
  </TR>
  <TR class="row11"> 
    <TD align=right width=26%><B>Address :</B></TD>
    <TD width="56%"> 
      <?=$ARR[address]?>&nbsp;<?=$ARR[address2]?><br>    <?=$ARR[city]?><br>    <?=$ARR[state]?><br><?=findcountry($ARR[country])?><br>    <?=$ARR[pincode]?>   </TD>
  </TR>
  <TR class="row11"> 
    <TD align=right width=26%><b>Phone :</b></TD>
    <TD width="56%"> 
      <?=$ARR[customers_telephone]?>    </TD>
  </TR>
  
  <TR class="row11"> 
    <TD align=right width=26%><b>Order date :</b></TD>
    <TD width="56%"> 
      <?=date('m/d/y',$result_rec['date'])?>    </TD>
      </tr>
    </table></td>
	<td valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0" class="row11">
      <tr>
        <td colspan="2"><div class="titlebg"><strong>Order Summry </strong></div></td>
      </tr>
      <tr>
        <td>Items: </td>
        <td align="right"><?=$result_rec[itemprice]?></td>
      </tr>
      <tr>
        <td>Shipping</td>
        <td align="right"><?=$result_rec[shipprice]?></td>
      </tr>
      <tr>
        <td> Packaging Cost </td>
        <td align="right"><?=$result_rec[Packingprice]?></td>
      </tr>
      <tr>
        <td colspan="2"><hr></td>
      </tr>
      <tr>
        <td>Order Total </td>
        <td align="right"><? $SumTotal = $result_rec[itemprice] + $result_rec[shipprice] + $result_rec[Packingprice];
		echo "$".$SumTotal;
		?></td>
      </tr>
    </table></td>
  </TR>
</table></TD>
  </TR>
  <TR> 
    <TD align=left colspan=4> 
      <?
  		$query="select * from orders where orderid='".$result_rec[orderid]."' and waitstatus !=1";
		$result=mysql_query($query);
		if(mysql_num_rows($result)){
 	  ?>  						 
    <TR> 
    <TD align=left colspan=4> 	  
	  <table width="96%"  border="0" align="center" cellpadding="0" cellspacing="0">
        <tr  >
          <td width="13%" height="24" bgcolor="#CCCCCC" class="headR" ><strong>Order Status</strong></td>
          <td width="87%" bgcolor="#CCCCCC" class="headR" ><?=$Status?></td>
        </tr>
        <tr  > 
    <td height="24" colspan="2" bgcolor="#CCCCCC" class="headR" ><strong> Order List </strong></td>
  </tr> 
  <tr>
    <td colspan="2" class="tableBorderDarkGrey"><table width=100% border="0" cellpadding="3" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
       
      <tr align="center" class="headR" >
        <td height="20" colspan="2">&nbsp;</td>
        </tr>
		<?
		while($result_rec=mysql_fetch_array($result)){	
		$itemsid=$result_rec["itemsid"];
		$id=$result_rec["id"];							
		$quantity=$result_rec["quantity"];
			$sqlitems ="select * from products  where products_id=".$itemsid."";
			$itemsresult=mysql_query($sqlitems);
			$itemRows=mysql_fetch_array($itemsresult);
		?>
       <tr>
        <td align=center>
    <img src="../<?=$itemRows[products_image]?>" alt="" class="frm-bord" border="0" height="75" hspace="2" vspace="2" width="75">  </td>  
   <td width="78%" valign="middle" align="left" class="row11"><?=$itemRows[product_title]?> - <?=$itemRows[products_model]?><br><div class="price"><?="$".$itemRows[products_price]?></div>Quantity- <?=$quantity?><br> Sold By - smartbuyz.co.in</td>
        </tr>
      <?
 	$ctr=$ctr+1;
 }
 }else{
 ?>
      <tr>
        <td height="20" align=center colspan="2">
          <table width="95%" border="0">
            <tr>
              <td height="30" align="center" class="headR"   ><p class="errortext">No any Pending order Yet!
                      <?=$_REQUEST[cname]?>
              </p></td>
            </tr>
        </table></td>
      </tr>
      <? }?>
    </table></td>
  </tr>
      </table> </TD>
  </TR>
   <TR> 
    <TD colspan=4 height=40 align=center> 
      <input type=button name=back value=" Back " class=btnstyle onclick="window.location.href='home.php?PageURL=ViewOrder'">    </TD>
  </TR>
</TABLE>

