<?
if($_REQUEST[hdn]==1)
{
	$FindShop = "select * from shopper_tbl where shopname = '".$_REQUEST[shopname]."'";
 	$FindRes = mysql_query($FindShop) or die(mysql_error());
	$FindNum = mysql_num_rows($FindRes);
	if($FindNum==0){
	$USerShop = "select * from shopper_tbl where shopusername = '".$_REQUEST[username]."'";
 	$USerRes = mysql_query($USerShop) or die(mysql_error());
	$USerNum = mysql_num_rows($USerRes);
	if($USerNum==0){
	///////////////////////////////////////////////////////////////////
			if($_FILES['shoplogo']['name']!="")
				{
 				$ext=array("exe", "sh", "pl", "php", "cgi", "html", "htm", "asp", "aspx");
				$articleFile=$_FILES['shoplogo']['name'];
					$path_parts = pathinfo($articleFile);
 					if(in_array($path_parts["extension"], $ext))
					{
 						$intFlag=1;
						$Err = $articleFile."File could not be loaded. You can try again from edit your Company Profile <br>";
					}else{
 					$File = $_FILES[shoplogo][name]; 
					$FileName1 = mt_rand(1,1500).$File;
 					if(move_uploaded_file($_FILES[shoplogo][tmp_name],"../Companylogo/$FileName1"))
						{
 						$ShopLogo = "Companylogo/$FileName1";
						}
 					}
					}
 	/////////////////////////////////////////////////////////////////////
	$AllCAtegory = $_REQUEST[comptype];
	for($j=0;$j<=count($AllCAtegory);$j++){
				if($AllCAtegory[$j]!=""){
					$CAtName.=$AllCAtegory[$j].", ";
				}
			}
		$CAtName=substr($CAtName, 0 , strlen($CAtName)-2);
	//////////////////////////////////////////////////////////////////////////////////////
	
	
		 $Shopsql = "INSERT INTO shopper_tbl (shopusername, shoppass, shopname, shoptype, shopowner, shoplogo, shopphone, shopfax, shopemail, shopaddress, shopcity, shopstate, shopcountry, shopstatus, compdetail, shopfeatured, adddate, IsLebanon) VALUES ('".$_REQUEST[username]."', '".$_REQUEST[pass]."', '".$_REQUEST[shopname]."', '".$CAtName."', '".$_REQUEST[shopowner]."', '".$ShopLogo."', '".$_REQUEST[shopphone]."', '".$_REQUEST[shopfax]."', '".$_REQUEST[shopemail]."', '".$_REQUEST[shopaddress]."', '".$_REQUEST[shopcity]."', '".$_REQUEST[shopstate]."', '".$_REQUEST[shopcountry]."', '".$_REQUEST[viewstore]."', '".$_REQUEST[compsummry]."', '".$_REQUEST[featuredstore]."', '".time()."', '".$_REQUEST[IsLebanon]."')"; 
	 mysql_query($Shopsql) or die(mysql_error());
	 $shopid = mysql_insert_id();
 	$Msg = "Company has been successfuliy registerd";
	// header("Location:index.php?PageURL=MyAccount");
	//////////Mail to Store Owner////////////////////////////////////////////////
		$serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		$serverpath1= dirname($serverpath);
		$imgpath = $serverpath1."/images/logo.jpg";
 		$to = $_REQUEST[shopemail];
		$Body='<table width="472" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F">
   <tr>
    <td align="left"><a href="'.$serverpath1.'"><img src="'.$imgpath.'" width="150" height="150" border="0"></a></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="83%" align="center"><table width="100%"  border="0" align="center" cellpadding="2" cellspacing="0">
          <tr>
            <td colspan="2"><strong>Dear Mr./Mrs./Miss. '.$_REQUEST[shopowner].', </strong>
                <blockquote>Congratulations, this is an auto generated mail to inform you that you have successfully registered at the site smartbuyz.co.in your Login details are given below:</blockquote></td>
          </tr>
          <tr>
            <td align="right">Username : </td>
            <td>'.$_REQUEST[username].'</td>
          </tr>
          <tr>
            <td align="right">Password : </td>
            <td>'.$_REQUEST[pass].'</td>
          </tr>
          <tr>
            <td colspan="2">To View the full details of this user, please login to the Store Login of the site for view the details of your account and manage Your Store. </td>
          </tr>
          <tr>
            <td colspan="2"><strong>Regards<br>
      smartbuyz.co.in Mailer </strong></td>
          </tr>
        </table> </td>
      </tr>
    </table></td>
  </tr>
</table>';
 $Subject = "Registration Successful: smartbuyz.co.in";
 $headers = "MIME-Version:1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From:info@smartbuyz.co.in<info@smartbuyz.co.in>\r\n";
//echo $Body;
 mail($to,$Subject,$Body,$headers);
 	////////////////////////////////////////////////////////////////////////////
	}else{
		$ERR = "USername already exist"; 
	}
	}else{
		$ERR = "This Company already registerd"; 
	}
}

?>


<table width="95%" border="0"  cellpadding="3" cellspacing="0"  >
  <tr  > 
    <td bgcolor="#CCCCCC" class="headR" ><strong>Add Store  </strong></td>
  </tr>
  <tr > 
<form action="" method="post" enctype="multipart/form-data" name="create_account" onsubmit="return check_form(create_account);">
      <td class="tableBorderDarkGrey"> <table width="100%"  border="0" cellpadding="3" cellspacing="1"  class="text" >
          <?
	 if($Msg!="" or $_REQUEST[intMSG]!="" or $ERR!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" class="errortext"> 
              <?=$Msg?><?=$_REQUEST[intMSG]?><?=$ERR?>
            </td>
          </tr>
          <? }?>
          <tr> 
            <td width="50%" align="center" ><table width="100%"  border="0" cellpadding="3" cellspacing="4" class="text">
              <tr>
                <td><span class="style3">*</span><strong>Store Name: </strong></td>
                <td><input name="shopname" type="text" id="shopname" value="<?=$_REQUEST[shopname]?>"> 
                 </td>
              </tr>
              <tr>
                <td nowrap><span class="style3">* </span><strong> Select Store categories </a> :</strong></td>
                <td><select name="comptype[]" size="7" multiple id="artistname" >
 				<? $CatQuery = "select * from categories where pid = 0";
				$CatResult = mysql_query($CatQuery) or die(mysql_error());
				while($CatArray = mysql_fetch_array($CatResult)){
				?>
                   <option value="<?=$CatArray[cid]?>"><?=$CatArray[cname]?></option>
				  <? }?>
                 </select><br>
                <font color="#FF0000"><strong><u>Note</u>:&nbsp;</strong>Press 'Ctrl + click' to select more than one category.</font></td>
              </tr>
              <tr>
                <td>*<strong>Owner Name</strong>:</td>
                <td><input name="shopowner" value="<?=$_REQUEST[shopowner]?>" type="text" id="shopowner"></td>
              </tr>
             <tr>
                <td>*<strong>Store UserName</strong>:</td>
                <td><input name="username" type="text" value="<?=$_REQUEST[username]?>" id="shopowner2"></td>
              </tr>
              <tr>
                <td>*<strong>Store Password</strong>:</td>
                <td><input name="pass" type="text" value="<?=$_REQUEST[pass]?>" id="shopowner3"></td>
              </tr>
            </table>              </td>
            <td align="center"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><span class="style3"> </span> 
                   <span class="style3">* </span><strong> Store Summary : </strong> </td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
                  <textarea name="compsummry" cols="47" rows="5" class="textarea" id="compsummry"><?=$_REQUEST[compsummry]?></textarea>
                  </td>
                </tr>
            </table>              </td>
          </tr>
          <tr align="center"  >
            <td colspan="2"><span class="style3">* </span><strong>Store Detail </strong></td>
          </tr>            
           <tr  >
            <td align="right"><strong>Store Logo:</strong></td>
            <td><input name="shoplogo" type="file" id="shoplogo"></td>
          </tr>
		   <tr  >
            <td align="right"><strong>Store Phone:</strong></td>
            <td><input name="shopphone" value="<?=$_REQUEST[shopphone]?>" type="text" id="shopphone"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Store Fax:</strong></td>
            <td><input name="shopfax" value="<?=$_REQUEST[shopfax]?>" type="text" id="shopfax"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Store Email</strong>: </td>
            <td><input name="shopemail" value="<?=$_REQUEST[shopemail]?>" type="text" id="shopemail" onBlur="check_mail()"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Store Address</strong></td>
            <td><textarea name="shopaddress"   cols="30" rows="4" id="shopaddress"><?=$_REQUEST[shopaddress]?></textarea></td>
          </tr>
          <tr  >
            <td align="right"><strong>If Shopkeeper from 


 Lebanon</strong>/<strong>Jordan (Please Check)</strong></td>
            <td><input name="IsLebanon" type="checkbox" id="IsIsLebanon" value="1"></td>
          </tr>
          <tr  >
            <td align="right"> <strong>City</strong>:</td>
            <td><input name="shopcity" value="<?=$_REQUEST[shopcity]?>" type="text" id="shopcity"></td>
          </tr>
          <tr  >
            <td align="right"><strong>State:</strong></td>
            <td><input name="shopstate" value="<?=$_REQUEST[shopstate]?>" type="text" id="shopstate"></td>
          </tr>
			 
          <tr  >
            <td align="right"><strong> Country:</strong></td>
            <td><select name="shopcountry" id="country" >
              <option value="">Please Choose Your Country</option>
              <?
  	$CountrySql = "select * from countrylist";
	$CountryRes = mysql_query($CountrySql) or die(mysql_error());
	while($CountryArr = mysql_fetch_array($CountryRes)){
  ?>
              <option value="<?=$CountryArr[id]?>" <? if($_REQUEST[shopcountry]==$CountryArr[id]){echo "selected"; }?>>
              <?=$CountryArr[cname]?>
              </option>
              <? }?>
            </select></td>
          </tr>          
          <tr  >
            <td align="right"><strong>View Status: </strong></td>
            <td><input name="viewstore" type="checkbox" class="textbox" id="viewstore" value="1" <? if($_REQUEST[viewstore]==1){?>checked <? }?>></td>
          </tr>
          <tr  >
            <td align="right"><strong>Store Featured   :</strong></td>
            <td><input name="featuredstore" type="checkbox" class="textbox" id="articleFeatured" value="1" <? if($_REQUEST[featuredstore]==1){?>checked <? }?>></td>
          </tr>
          <tr align="center"> 
            <td colspan="2"><input name="btnBack" type="button" id="btnBack" value="   &lt;&lt; Back   "  class="button1" onClick="javascript:location.href='home.php?PageURL=MamageStore'">              <input name="btnSubmit" type="submit" id="btnSubmit" value="Add Store Now" class="button1">
             <input name="hdn" type="hidden" id="hdn" value="1">           
          </tr>
        </table></td>
    </form>
  </tr>
</table>
 <script language="javascript">
 function check_form()
 {
 	if(document.create_account.shopname.value=="")
	{
		alert('Please Enter Company Name');
		document.create_account.shopname.focus();
		return false;
	}
	if(document.create_account.comptype.value=="")
	{
		alert('Select Company Type');
		document.create_account.comptype.focus();
		return false;
	}
	if(document.create_account.username.value=="")
	{
		alert('Enter Username for shop login');
		document.create_account.username.focus();
		return false;
	}
	if(document.create_account.pass.value=="")
	{
		alert('Enter Password for shop login');
		document.create_account.pass.focus();
		return false;
	}
	if(document.create_account.shopowner.value=="")
	{
		alert('Enter Owner Name');
		document.create_account.shopowner.focus();
		return false;
	}
	if(document.create_account.shoplogo.value=="")
	{
		alert('Enter Company Logo');
		document.create_account.shoplogo.focus();
		return false;
	}
	if(document.create_account.shopphone.value=="")
	{
		alert('Enter Company Phone Number');
		document.create_account.shopphone.focus();
		return false;
	}
	if(document.create_account.shopemail.value=="")
	{
		alert('Enter Company E-MAIL');
		document.create_account.shopemail.focus();
		return false;
	}
	if(document.create_account.shopaddress.value=="")
	{
		alert('Enter Company Address');
		document.create_account.shopaddress.focus();
		return false;
	}
	if(document.create_account.shopcity.value=="")
	{
		alert('Enter Company City name');
		document.create_account.shopcity.focus();
		return false;
	}
	if(document.create_account.shopstate.value=="")
	{
		alert('Enter Company State name');
		document.create_account.shopstate.focus();
		return false;
	}
	if(document.create_account.shopcountry.value=="")
	{
		alert('Enter Company Country name');
		document.create_account.shopcountry.focus();
		return false;
	} 
 }
 function check_mail(){
 if (!isEmailAddr(document.create_account.shopemail.value))
		{
			alert("Please enter a complete email address in the form: yourname@yourdomain.com");
			document.create_account.shopemail.focus();
			return false;
		}
	}	

 function isEmailAddr(email)
	{
	  var result = false;
	  var theStr = new String(email);
	  var index = theStr.indexOf("@");
	  if (index > 0)
	  {
		var pindex = theStr.indexOf(".",index);
		if ((pindex > index+1) && (theStr.length > pindex+1))
		result = true;
	  }
	  return result;
	}
 </script>