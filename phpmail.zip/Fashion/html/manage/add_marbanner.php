<?
 if($_REQUEST[applly]==1)
{
		 $serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		 $serverpath1= dirname($serverpath);
		$f_name=$_FILES["c_file"]["name"];
		$intFile=mt_rand();

				if($_FILES["c_file"]["name"]!=""){
  						move_uploaded_file($_FILES["c_file"]["tmp_name"],"../mbanner/".$intFile.$_FILES["c_file"]["name"]);

						$fileUpload=$intFile.$_FILES["c_file"]["name"];

				}else{

					$fileUpload="";

				} 
		$cname=$_REQUEST[cname];
 
 		
		$query="insert into marbanner set cname='".$_REQUEST[cname]."',
	 	 name='".$_REQUEST[name]."',m_image='".$fileUpload."'";
		$result=mysql_query($query) or die(mysql_error());
 		$MSG="Upload Successfully Added.";
  header("Location:home.php?PageURL=marbanner");
}
?>
<form action="" method="post" enctype="multipart/form-data" name="upforapp" id="upforapp" onSubmit="return upass()">
<table width="100%" border="0" cellpadding="3" cellspacing="1">

                                  <tr class="headM txtcolor">
                                    <td height="27" colspan="2" >Add </td>
                                  </tr>
                                  
                                  <tr>
                                    <td width="30%" >link<span class="error">*</span></td>
                                    <td width="30%"><label>
                                      <input type="text" name="cname" id="cname" class="tultxtbox" value="<?=$_REQUEST[cname]?>"/>
                                    </label></td>
                                  </tr>
                                  
                                  <tr>
                                    <td >Attach  <span class="txt9"><span class="error">Image</span></span></td>
                                    <td><label>
                                      <input type="file" name="c_file" id="c_file" />
                                    <br />Size must be( width:151, height:45)</label></td>
                                  </tr>
                                  
                                  <tr>
                                    <td >&nbsp;</td>
                                    <td><label>
                                      <input type="submit" name="button" id="button" value="Submit" class="login" />
                                    </label></td>
                                  </tr>
                                  
                                  <tr>
                                    <td>&nbsp;</td>
                                    <td><input name="applly" type="hidden" id="applly" value="1" /></td>
                                  </tr> 
                                </table>
</form>
<script language="JavaScript" type="text/javascript">
function upass()
{
 
 if(document.upforapp.cname.value=="")
  {
  alert("Please Enter Name");
	document.upforapp.cname.focus();
	return false;
  }
 	 
 if (document.upforapp.c_file.value=="")
	{
	alert("Please Upload File");
	document.upforapp.c_file.focus();
	return false;
	}	
		 

}

</script>
