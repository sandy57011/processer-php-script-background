<?
 
if ($_REQUEST[add_banner])
{
	$BannerURL = $_REQUEST[bannerurl];
 $st_date = mktime(0,0,0,date('m'),date('d'),date('Y'));
//$num=$_REQUEST[add_pd_in_days]*24*60*60;
//$end_date = $st_date + $num;
$filename = $_FILES[browse][name];
$randno = mt_rand(1,1000);
$filename = "$randno$filename";
copy($_FILES[browse][tmp_name],"../ad_pic/".$filename);
$sql = "INSERT INTO `ad_banner` (`adid`, `adtype`, `adfilevalue`, `adposition`, `adstartdate`, `adstatus`, bannerurl) VALUES ('', 'image', '".$filename."', 'topbig', '".$st_date ."', '".$_REQUEST[status]."', '".$BannerURL."')";
$res = mysql_query($sql) or die(mysql_error());
if(!mysql_error())
	{
		copy($_FILES[browse][tmp_name],'../ad_pic/'.$filename); 

 header('Location:home.php?PageURL=banner_show');		
}
else if(mysql_error())	
	{
		$msg = "Error in saving your record";
		echo $msg;
	}
}	
?>
  <table width="99%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#3399CC" celspacing="1">
<form name="add_banner_pic" action="" enctype="multipart/form-data" method="post" onSubmit="return check(this)">
    <tr> 
      <td bgcolor="#666666"><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
          <tr bgcolor="#666666"> 
            <td colspan="2"  background="../images/newsletter/tm.jpg"><span class="style7"><font color="#FFFFFF"><strong>Add 
              Banner (Image)</strong></font></span></td>
          </tr>
       <?php /*?>   <tr bgcolor="#F5F5F5"> 
            <td width="50%" align="right"> Ad Type: </td>
            <td width="50%"> 
              <?=ucwords($_REQUEST[adtype])?>            </td>
          </tr><?php */?>
          <tr bgcolor="#F5F5F5"> 
            <td align="right" valign="top"> Upload Advertisement File:</td>
            <td align="left" valign="top"><div align="left" id="id_div"> 
                <input type="file" name="browse" id="browse" class="inputbox">
              <br />
              size(width :689px height :233px;)</div></td>
          </tr>
          <?php /*?><tr bgcolor="#F5F5F5"> 
            <td align="right"> Ad Position: </td>
            <td> <select name="add_position" class="select" id="add_position">
                <option value="0" selected>---Select One---</option>
                <option value="topbig">Top Big Banner</option>
				 <option value="topsmallleft">Top Small Left Banner</option>
				 <option value="topsmallright">Top Small right Banner</option>
                <option value="right">Right Banner</option>
                <option value="leftbottom">Left Bottom</option>
				<!--
                <option value="item page">Item Page Banner</option>
				-->
              </select> </td>
          </tr><?php */?>
          <?php /*?><tr bgcolor="#F5F5F5"> 
            <td align="right"> Ad Period in Days: </td>
            <td> <input type="text" class="inputbox" name="add_pd_in_days" id="add_pd_in_days"> 
            </td>
          </tr><?php */?>
 <?php /*?>         <tr bgcolor="#F5F5F5">
            <td align="right">Banner URL:(Do not include:&quot;http://&quot;) </td>
            <td align="left"><input type="text" class="inputbox" name="bannerurl" id="bannerurl"></td>
          </tr><?php */?>
          <tr bgcolor="#F5F5F5"> 
            <td align="right">Status:</td>
            <td align="right"><div align="left"><span class="style2"> 
                <input name="status" type="checkbox" id="status" value="1" checked>
                </span></div></td>
          </tr>
          
          <tr bgcolor="#F5F5F5"> 
            <td colspan="2" align="right"><div align="center">
                 
                <input name="add_banner" type="submit" class="btnstyle" id="add_banner" value="Submit">
              </div></td>
          </tr>
      </table> </td>
    </tr>
  </form>
</table>
<script language="javascript">
function check(a)
	{
		if(a.browse.value == "")
			{
				alert("Please enter the value of the file");
				a.browse.focus();
				return false;
			}
	 	 
		return true;
	}			
</script>