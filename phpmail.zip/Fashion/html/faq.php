<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab : </title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="megamenu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="megamenu/css/webslidemenu.css" />
<script type="text/javascript" src="megamenu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="megamenu/font-awesome/css/font-awesome.min.css" />


</head>

<body>
<? include"header.php"?>

<div class="inner-banner ib-s">
<div><a href="index.php">Home</a> &raquo; FAQs</div>
</div>

<div class="container">
<div class="content">
<h1><span>FAQ's</span></h1>
<? $coroff=mysql_fetch_array(mysql_query("select cont_title,contents,id from contents where id=2"));?>
<?=stripslashes($coroff[contents])?>
</div>
</div>
<? include"footer.php"?>
</body>
</html>