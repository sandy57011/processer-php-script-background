<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab : </title>
<link href="css/style.css" rel="stylesheet" type="text/css" />

<link href="slide/slide.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="slide/jquery-1.2.6.min.js"></script>
<script type="text/javascript">
function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');
    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 4000 );
});
</script>


<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu.css" />
<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu-v.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="top-menu/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

ddsmoothmenu.init({
	mainmenuid: "smoothmenu2", //Menu DIV id
	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
	//customtheme: ["#804000", "#482400"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<script type="text/javascript" src="js/form_vail.js"></script>
<script type="text/javascript" src="js/cleartxtbox.js"></script>


</head>

<body>
<center>
<? include"header.php"?>
<div class="main">
<div class="page_content">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td width="3%" align="left" valign="top" class="left"><? include"left.php"?></td>
    <td width="97%" valign="top" class="content"> 
      <h1>Login Error</h1>
	  <div >
                        <?
 if($_REQUEST[customerlogin]==1){
 $SQL = "select * from customers where customers_email_address  =  '".$_REQUEST[txt_usernanme]."' and customers_password = '".$_REQUEST[txt_password]."'";
  $res = mysql_query($SQL) or die(mysql_error());
 $num = mysql_num_rows($res);
 if($num>0)
 {
  // echo $SQL;die();
  	$arr = mysql_fetch_array($res);
	if($arr[customers_authorization]==1){
	$_SESSION[MemId] = $arr[customers_id];
	$_SESSION[name] = $arr[customers_firstname]."&nbsp;".$arr[customers_lastname];
	$_SESSION[username] = $arr[username];
	$_SESSION[email] = $arr[customers_email_address]; 
 	if($_REQUEST[page]!=""){
	header("Location:$_REQUEST[page]");
	}else{
	header("Location:MyAccount.php");
	}
	}else{?>
	<br><br>
	<fieldset><legend style="color:#cc6600; ">Permission denied</legend>
 <table width="90%"  border="0" style='background:#fff url(bg-popup.gif) bottom repeat-x;' align="center" cellspacing="5" cellpadding="1">
  <tr>
    <td colspan="2"><h1 style="color:#cc6600; font-size:12px"></h1></td>
  </tr>
  <tr>
    <td colspan="2">Your acccount is disabled, If you have already activated your account, and this problem is new, please  contact info@fashionfab.in and get it re-activated again</td>
  </tr>
   <tr>
    <td width="50%" align="center"><a href="contact.php?type=Customer" class="link1"> Click To contact us </a></td>
    <td align="center">&nbsp;</td>
   </tr>
</table></fieldset>
<?	}
}else{?>
 <br><br>
 <fieldset><legend style="color:#cc6600; ">Login Error</legend>
 <table width="90%"  border="0" style='background:#fff url(bg-popup.gif) bottom repeat-x;' align="center" cellspacing="5" cellpadding="1">
  <tr>
    <td colspan="2"><h1 style="color:#cc6600; font-size:12px"></h1></td>
  </tr>
  <tr>
    <td colspan="2"><a href="login.php" class="link1">Invalid Username or Password. Try Again!.</a></td>
  </tr>
   <tr>
    <td width="50%" align="center"><a href="ForGotPassword.php?type=Customer" class="link1">Forget Password</a></td>
    <td align="center"> 
      
       
	<form action="login.php" method="post" enctype="multipart/form-data" name="addcart2">
	  <input type="hidden" name="page" value="<?=$serverpath?>">
	<input type="hidden" name="quantity" value="1"><input type="submit" name="Submit" value="Registration"   /></form>	</td>
   </tr>
</table></fieldset>
 <? } 
 }
 ?> 
            </div>
      <p>&nbsp;</p></td>
  </tr>
</table>
</div>
</div>
<? include"footer.php"?>
</center>
</body>
</html>