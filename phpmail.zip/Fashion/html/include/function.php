<?
function getChildCategories($categories, $id, $recursive = true)
{
	if ($categories == NULL) {
		$categories = fetchCategories();
		
	}
	
	$n     = count($categories);
	$child = array(); //echo $id='16';
	for ($i = 0; $i < $n; $i++) {
		$catId    = $categories[$i]['cid'];
		  $parentId = $categories[$i]['pid'];//echo "<br>";
		 // echo $id=16;
		if ($parentId == $id) {   $id;
			$child[] = $catId;
			if ($recursive) {
				$child   = array_merge($child, getChildCategories($categories, $catId));
			}	
		}
	}
	
	return $child;
}
function fetchCategories()
{
    $sql = "SELECT cid,pid,cname FROM categories ORDER BY pid,pid ";
    $result = dbQuery($sql);
    
    $cat = array();
    while ($row = dbFetchAssoc($result)) {
        $cat[] = $row;
		
    }
	
	return $cat;
}
function dbQuery($sql)
{
	$result = mysql_query($sql) or die(mysql_error());
	
	return $result;
}
function dbFetchAssoc($result)
{
	return mysql_fetch_assoc($result);
}

function dbFetchRow($result) 
{
	return mysql_fetch_row($result);
}
	/////////////////////////////////////////////////////////////
	function php_vote($item_id,$type){
	if($_SESSION[MemId]==""){
		$Msg = "Please login to rate this product! !";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");
	}else{
      $sql_voteexist="select * from rating where phid='".$item_id."' and mid='".$_SESSION[MemId]."' ";
 	 $res_voteexist=mysql_query($sql_voteexist) or die(mysql_error());
	 $num_vote=mysql_num_rows($res_voteexist);
	 if($num_vote>0){ 
	 $Msg = "You already rated on this item!";
 	 header("Location:product_detail.php?itid=$item_id&Msg=$Msg");
  	 }else{
		$date = getdate();
		$date = mktime($date['hours'], $date['minutes'], $date['seconds'], $date['mon'], $date['mday'], $date['year']);	 
		$sql_in = "INSERT INTO rating (mid, phid, points, adddate, ipaddress ) VALUES ('".$_SESSION[MemId]."', '".$item_id."', '".$type."', '".$date."', '".$_SERVER['REMOTE_ADDR']."' )"; 
		$res_in=mysql_query($sql_in) or die(mysql_error());
		$numAve=number_format(php_avgvote($item_id,"music"),2,'.',',');
		$sql_in = mysql_query("update products  set aveg_rating='".$numAve."' where products_id =".$item_id) or die(mysql_error()); 
		 $Msg = "Thank you for rating!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");		
 	}
	}
} 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function php_votecat($item_id,$type){
       $sql_voteexist="select * from catrating where catid='".$item_id."' and mid='".$_SESSION[RegId]."' ";
 	 $res_voteexist=mysql_query($sql_voteexist) or die(mysql_error());
	 $num_vote=mysql_num_rows($res_voteexist);
	 if($num_vote>0){ 
 		$date = getdate();
		$date = mktime($date['hours'], $date['minutes'], $date['seconds'], $date['mon'], $date['mday'], $date['year']);	 
		$sql_in = "INSERT INTO catrating (mid, catid, points, adddate, ipaddress ) VALUES ('".$_SESSION[RegId]."', '".$item_id."', '".$type."', '".$date."', '".$_SERVER['REMOTE_ADDR']."' )"; 
		$res_in=mysql_query($sql_in) or die(mysql_error());
		$numAve=number_format(php_avgcatvote($item_id,"music"),2,'.',',');
		$sql_in = mysql_query("update categories set aveg_rating='".$numAve."' where cid =".$item_id) or die(mysql_error()); 
		?>
		<script language="javascript">
		alert('thank your for reating');
		</script>
		<?
   	}
 } 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function php_favorite($item_id){
     if($_SESSION[MemId]==""){ 
		$Msg = "Please login to add this item to your Favorite List!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");
 	}else{
      $sql_voteexist="select * from myfavrites where itemid='".$item_id."' and memid='".$_SESSION[MemId]."'";
 	 $res_voteexist=mysql_query($sql_voteexist) or die(mysql_error());
 	 $num_vote=mysql_num_rows($res_voteexist);
 	 if($num_vote>0){ 
		$Msg = "this item already added to your Favorite List!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");  	
		 }else{
 		   $date = getdate();
 		   $date = mktime($date['hours'], $date['minutes'], $date['seconds'], $date['mon'], $date['mday'], $date['year']);	 
 			$sql_in = "INSERT INTO myfavrites (memid, itemid ) VALUES ('".$_SESSION[MemId]."', '".$item_id."')"; 
 			$res_in=mysql_query($sql_in) or die(mysql_error());
  			$sql_in = mysql_query("update products set num_favorite=num_favorite+1 where products_id=".$item_id) or die(mysql_error()); 
		$Msg = "Thank you for adding this product in your Favorite List!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");  
	   }

	}

} 
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	function php_wishlist($item_id){
     if($_SESSION[MemId]==""){ 
		$Msg = "Please login to add this item to your Wish List!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");
		
 	}else{
      $sql_voteexist="select * from mywishlist where itemid='".$item_id."' and memid='".$_SESSION[MemId]."'";
 	 $res_voteexist=mysql_query($sql_voteexist) or die(mysql_error());
 	 $num_vote=mysql_num_rows($res_voteexist);
 	 if($num_vote>0){ 
		$Msg = "this item already added to your Wish List!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");  	
		 }else{
 		   $date = getdate();
 		   $date = mktime($date['hours'], $date['minutes'], $date['seconds'], $date['mon'], $date['mday'], $date['year']);	 
 			$sql_in = "INSERT INTO mywishlist (memid, itemid ) VALUES ('".$_SESSION[MemId]."', '".$item_id."')"; 
 			$res_in=mysql_query($sql_in) or die(mysql_error());
  			$sql_in = mysql_query("update products set num_favorite=num_favorite+1 where products_id=".$item_id) or die(mysql_error()); 
		$Msg = "Thank you for adding this product in your Wish List!";
 	 	header("Location:product_detail.php?itid=$item_id&Msg=$Msg");  
	   }

	}

}
function findcountry($CID)
{
	$CIDsql = "select * from countrylist where id = '".$CID."'";
	$CIDres = mysql_query($CIDsql) or die(mysql_error());
	$CIDarr = mysql_fetch_array($CIDres);
	return($CIDarr[cname]);
 }
$MemInfoSql = "select * from customers where customers_id = '".$_SESSION[MemId]."'";
$MemInfoRes = mysql_query($MemInfoSql) or die(mysql_error());
$MemInfoArr = mysql_fetch_array($MemInfoRes);
if($MemInfoArr[memimage]!=""){
$MemPhoto = $MemInfoArr[memimage];
}else{
$MemPhoto = "images/comm.jpg";
}


function totalshopping()
{
				$query="select * from orders where orderid='".$_SESSION["shoporderid"]."'";
				$result=mysql_query($query);
				$rsCount=mysql_num_rows($result);
				if($rsCount>0){
					$rec=0;
						while($result_rec=mysql_fetch_array($result)){	
 							$itemsid=$result_rec["itemsid"];
							$id=$result_rec["id"];							
							$quantity=$result_rec["quantity"];
								$sqlitems ="select * from products  where products_id=".$itemsid."";
								$itemsresult=mysql_query($sqlitems);
								$itemRows=mysql_fetch_array($itemsresult);
								$rec=$rec+1;
  							if($itemRows[customerdiscount]!=0 or $itemRows[fes_discountpercentage]!=0){
							
							$GrandTot = (($quantity*$itemRows[products_price]));
				  $GrandTot =floor(($GrandTot - ($GrandTot*(($itemRows[customerdiscount]+$itemRows[fes_discountpercentage])/100))));

  							} else{
 							$GrandTot = (($quantity*$itemRows[products_price]));
 							}
							if($result_rec[waitstatus]!=1){
 						  $Totalprice=$Totalprice+$GrandTot;
						  }
						}
				}else{
					$Totalprice = 0;
				}
				return $Totalprice;
						  
} 

   //================================
   function php_avgvote($item_id, $type){
	$sum=0; 
	$average;
	$sql_avg="select * from rating where phid='".$item_id."'";
	$res_avg=mysql_query($sql_avg) or die(mysql_error());
	$num_avg=mysql_num_rows($res_avg);
		while($row_avg=mysql_fetch_array($res_avg)){
			$sum=$sum+$row_avg[points];
		}
		if($num_avg!=0){ 
			$average=$sum/$num_avg;
			return $average;
		}else{
			return 0;
		} 
}
 function checkproductposition($itid)
{
	$ProductSQL = "select * from  products where products_id = '".$itid."'";
	$ProductRES = mysql_query($ProductSQL) or die(mysql_error());
	$ProductARR = mysql_fetch_array($ProductRES);
	if($ProductARR[manufacturers_id]!=0)
	{
		$Query = "select * from shopper_tbl where shopid = '".$ProductARR[manufacturers_id]."'";
		$Result = mysql_query($Query) or die(mysql_error());
		$Array = mysql_fetch_array($Result);
		if($Array[IsLebanon]==1)
		{
			return 'Lebanon';
		}else{
			return 0;
		}
	}else{
		return 0;
	}
}
 function MemJoin($field,$memberid,$statusvalue){
 		$MemQuery = "select * from members_join where ".$field." = '".$memberid."' and status = '".$statusvalue."'";
 		$MemResult= mysql_query($MemQuery) or die(mysql_error());
 		if(mysql_num_rows($MemResult)>0){
 			return($MemResult);
 		}else{
 			return 0;
 		}
 	} 

function loginquery($field, $value){
 		$query = "select * from customers where ".$field." = '".$value."'";
 		$result= mysql_query($query) or die(mysql_error());
 		if(mysql_num_rows($result)>0){
 			return $result;
 		}else{
 			return 0 ;
 		}
 	}
	function browser_detection( $which_test ) {

	// initialize the variables
	$browser = '';
	$dom_browser = '';

	// set to lower case to avoid errors, check to see if http_user_agent is set
	$navigator_user_agent = ( isset( $_SERVER['HTTP_USER_AGENT'] ) ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';

	// run through the main browser possibilities, assign them to the main $browser variable
	if (stristr($navigator_user_agent, "opera")) 
	{
		$browser = 'opera';
		$dom_browser = true;
	}

	elseif (stristr($navigator_user_agent, "msie 4")) 
	{
		$browser = 'msie4'; 
		$dom_browser = false;
	}

	elseif (stristr($navigator_user_agent, "msie")) 
	{
		$browser = 'msie'; 
		$dom_browser = true;
	}

	elseif ((stristr($navigator_user_agent, "konqueror")) || (stristr($navigator_user_agent, "safari"))) 
	{
		$browser = 'safari'; 
		$dom_browser = true;
	}

	elseif (stristr($navigator_user_agent, "gecko")) 
	{
		$browser = 'mozilla';
		$dom_browser = true;
	}
	
	elseif (stristr($navigator_user_agent, "mozilla/4")) 
	{
		$browser = 'ns4';
		$dom_browser = false;
	}
	
	else 
	{
		$dom_browser = false;
		$browser = false;
	}

	// return the test result you want
	if ( $which_test == 'browser' )
	{
		return $browser;
	}
	elseif ( $which_test == 'dom' )
	{
		return $dom_browser;
		//  note: $dom_browser is a boolean value, true/false, so you can just test if
		// it's true or not.
	}
}

	/*function calcshippingPrice()
	{
		$ShipLabnon = 0;
		$ShipOther = 0;
		$Query = "select * from orders where orderid = '".$_SESSION["shoporderid"]."'";
		$Result = mysql_query($Query) or die(mysql_error());
		while($row = mysql_fetch_array($Result))
		{
			$query1 = "select * from products where products_id = '".$row[itemsid]."'";
			$result1 = mysql_query($query1) or die(mysql_error());
			$row1 = mysql_fetch_array($result1);
			$query2 = mysql_query("select * from shopper_tbl where shopid '".$row1[manufacturers_id]."'") or die(mysql_error());
			$row2 = mysql_fetch_array($query2);
			if($row2[IsLebanon]==1)
			{
				$SQL = "select * from order_mem where orderid = '".$_SESSION["shoporderid"]."'";
				$Res = mysql_query($SQL) or die(mysql_error()); 
				$ARR = mysql_fetch_array($Res);
				if($ARR[ShippingOption]==1){
				$ShipLabnon += 5;
				$flag = 1;
				}else{
				$ShipLabnon += 8;
				}
			}else{
				$ShipOther += 10;
			}
		}
		if($ShipLabnon){
			if($flag = 1){
			$ShipLabnon += 10;
			}else{
			$ShipLabnon += 18;
			}
		}
		if($ShipOther)
		{
			$ShipOther +=20;
		}
		$Gtotal = $ShipLabnon + $ShipOther;
	} */
function getOptionNameById($id) {
	$queryRes = mysql_fetch_array(mysql_query("select * from product_option where op_id = '".$id."'")) or die(mysql_error());
	return $queryRes['name'];
}
function getOptionFieldNameById($id) {
	$queryRes = mysql_fetch_array(mysql_query("select * from product_option_field where id = '".$id."'")) or die(mysql_error());
	return $queryRes['product_option_name'];
}

function getOptionIdById($id) {
	$queryRes = mysql_fetch_array(mysql_query("select * from product_option_field where id = '".$id."'")) or die(mysql_error());
	return $queryRes['product_option_id'];
}
function getAllProductOption() {
	$query =mysql_query("select * from product_option") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}	
function getAllProductOptionField($id) {
	$query =mysql_query("select * from product_option_field where product_option_id = '".$id."'") or die(mysql_error());
	while($data=mysql_fetch_array($query)){
		$result_data[] = $data;		
	}
	return $result_data;
}
function getOptionFieldDetails($id) {

}
	?>
	