  <?
 
if($_REQUEST[shiptype])
{
	$_SESSION[shipaddress] =$_REQUEST[shiptype]; 
	if($_SESSION[shipaddress]=="customer"){
		$namess = $MemInfoArr[companyname];
		$address1 = $MemInfoArr[address];
		$address2 = $MemInfoArr[address2];
		$city = $MemInfoArr[city];
		$state = $MemInfoArr[state];
		$Zip = $MemInfoArr[pincode];
		$country = $MemInfoArr[country];
		$std1 = $MemInfoArr[std1];
		$std2 = $MemInfoArr[std2];
		$phone1 = $MemInfoArr[customers_telephone];
		$phone2 = $MemInfoArr[phone2];
	}else if($_SESSION[shipaddress]=="ship"){
		$ShSQL = "select * from shipping_tbl where memid = '".$_SESSION[MemId]."'";
		$ShRES = mysql_query($ShSQL) or die(mysql_error());
		$ShArr = mysql_fetch_array($ShRES);
		$namess = $ShArr[name];
		$address1 = $ShArr[address1];
		$address2 = $ShArr[address2];
		$city = $ShArr[city];
		$state = $ShArr[state];
		$Zip = $ShArr[zipcode];
		$country = $ShArr[country];
		$std1 = $ShArr[std1];
		$std2 = $ShArr[std1];
		$phone1 = $ShArr[phone1];
		$phone2 = $ShArr[phone2];
	} 
}
////////////Total Friend/////////////////////////////////////////////////////
$clientid  = array();
$NumFriends = MemJoin('invitor_id', $_SESSION[MemId], 1);
if($NumFriends!=0){
	while($numFriendArray=mysql_fetch_array($NumFriends)){
	$clientid[] = $numFriendArray[joined_id];
}				
}else{
	$NumFriendsTo = 0;
}
$NumFriends1= MemJoin('joined_id', $_SESSION[MemId], 1);
if($NumFriends1!=0){
	while($numFriendArray=mysql_fetch_array($NumFriends1)){
	$clientid[] = $numFriendArray[invitor_id];
}				
}else{
	$NumFriendsFrom = 0;
}
$clientid = array_unique($clientid);
 $SearchNumber1 = count($clientid);
// echo "Total Friend".$SearchNumber1;
 ////////////Total Comment//////////////////////////////////////////////
$CommentSql1 = "select * from memcomment_tbl where memid = '".$_SESSION[MemId]."'";
//echo $CommentSql1;
	$CommentRes1 = mysql_query($CommentSql1) or die(mysql_error());
	$CommentNum1 = mysql_num_rows($CommentRes1);
///////////////////////Total Message//////////////////////////////
$MessageSql1 = "select * from member_msg_tbl where memid = '".$_SESSION[MemId]."'";
//echo $MessageSql1;
 	$MessageRes1 = mysql_query($MessageSql1) or die(mysql_error());
	$MessageNum1 = mysql_num_rows($MessageRes1);
////////////////////////////////////////////////////////////////
$ProductTitle = array();
$ProductMake = array();
$ProductModel = array();
$MetaSql = "select * from products";
$MetaRes = mysql_query($MetaSql) or die(mysql_error()); 
while($MetaArr = mysql_fetch_array($MetaRes))
{
	$ProductTitle = $ProductTitle.",".$MetaArr[product_title];
	$ProductMake = $ProductMake.",".$MetaArr[product_make];
	$ProductModel = $ProductModel.",".$MetaArr[products_model];
}


///////////////////////////////////////////////////////////////////////////
$ShipLabnon = 0;
		$ShipOther = 0;
		$PackageLabnon = 0;
		$PackageOther = 0;
		$Query = "select * from orders where orderid = '".$_SESSION["shoporderid"]."'";
		$Result = mysql_query($Query) or die("1".mysql_error());
		while($row = mysql_fetch_array($Result))
		{
			$query1 = "select * from products where products_id = '".$row[itemsid]."'";
			$result1 = mysql_query($query1) or die("2".mysql_error());
			$row1 = mysql_fetch_array($result1);
			$query2 = mysql_query("select * from shopper_tbl where shopid = '".$row1[manufacturers_id]."'") or die("3".mysql_error());
			$row2 = mysql_fetch_array($query2);
			if($row2[IsLebanon]==1)
			{
				$SQL = "select * from order_mem where orderid = '".$_SESSION["shoporderid"]."'";
				$Res = mysql_query($SQL) or die("4".mysql_error()); 
				$ARR = mysql_fetch_array($Res);
				if($ARR[ShippingOption]==1){
				$ShipLabnon += 5*$row[quantity];
				$flag = 1;
				}else{
				$ShipLabnon += 8*$row[quantity];
				}
				$PackageLabnon += .75*$row[quantity];
			}else{
				$PackageOther += 1.50*$row[quantity];
				$ShipOther += 10*$row[quantity];
			}
		}
		if($ShipLabnon){
			if($flag==1){
			$ShipLabnon += 10;
			}else{
			$ShipLabnon += 18;
			}
		}
		if($ShipOther)
		{
			$ShipOther +=20;
		}
		//echo "flag".$flag."<br>";
		//echo "ShipLabnon".$ShipLabnon."<br>";
		//echo "ShipOther".$ShipOther."<br>";
		$Gtotal = $ShipLabnon + $ShipOther;
		$GTotalPackage = $PackageLabnon + $PackageOther;
 		//echo "".$Gtotal;

////////////////////////////////////////////////////////////////////////////////
?>