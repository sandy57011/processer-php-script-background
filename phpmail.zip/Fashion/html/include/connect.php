<? session_start()?>
<? ob_start()?>
<?
error_reporting(0);
if($_SERVER['HTTP_HOST']=='localhost'){
	$hostname='localhost';
	$dbusername='root';
	$dbpassword='vertrigo';
	$database='fashion-2016';
}else{
	$hostname = 'localhost';
	$dbusername='bookmz1o_fashion';
	$dbpassword='bookmyorder';
	$database='bookmz1o_fashion'; 
}
$pagetitle = "::Fashion Fab::";
$link=mysql_connect($hostname,$dbusername,$dbpassword);
mysql_select_db($database,$link);

   $date = getdate();
   $date = mktime($date['hours'], $date['minutes'], $date['seconds'], $date['mon'], $date['mday'], $date['year']);
 	if($_SESSION["shoporderid"]==""){
   	$_SESSION["shoporderid"]=mt_rand();  
  	}
//==================================
if($_REQUEST[yourkey]!="")
{
	$_SESSION[yourkey] = $_REQUEST[yourkey];
}
  //===================================
 	$serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
	$serverpath = dirname($serverpath);
if($_REQUEST[Sendhdn]==1){
		if($_SESSION[MemId]!="")
		{
			$CheckSql = "select * from comment_tbl where itid = '".$_REQUEST[itid]."' and postedby = '".$_SESSION[MemId]."'";
			$CheckRes = mysql_query($CheckSql);
			$CheckNum = mysql_num_rows($CheckRes);
			if($CheckNum==0){
			$sql = "INSERT INTO comment_tbl (itid, date_added, postedby, comment) VALUES ('".$_REQUEST[itid]."', '".time()."', '".$_SESSION[MemId]."', '".$_REQUEST[comment]."')"; 
			mysql_query($sql) or die(mysql_error());
			$Msg = "Thank You for posting your comment!.";
 			header("product_detail.php?itid=$_REQUEST[itid]&catid=$_REQUEST[catid]&Msg=$Msg");
			}else{
			$Msg = "Sorry, Your comment for this product is already posted!.";
 			header("Location:product_detail.php?itid=$_REQUEST[itid]&catid=$_REQUEST[catid]&Msg=$Msg");
			}
		}else{
			$Msg = "Please Login To add Your comment.!.";
			$page="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
 			header("Location:login.php?page=$page");
		}
	}

if($_REQUEST[subscribehdn]==1){
	$SubSql = "select * from subscribe_tbl where email = '".$_REQUEST[emailsubscribe]."'";
	$SubRes = mysql_query($SubSql) or die(mysql_error());
	$SubNum = mysql_num_rows($SubRes);
	if($SubNum==0){
	$Emailsql = "INSERT INTO subscribe_tbl (email, status) VALUES ('".$_REQUEST[emailsubscribe]."', 1)";
	mysql_query($Emailsql) or die(mysql_error());
	$Msg = "Thank You, for suscribe.!.";
	header("Location:index.php?&Msg=$Msg");
	}else{
	$Msg ="This email id has been suscribed already.";
	header("Location:index.php?&Msg=$Msg");
	}
}
if($_REQUEST[yourkey]!="")
{
$_SESSION[yourkey] = $_REQUEST[yourkey];
$MemJoin = mysql_query("select * from members_join where joinkey = '$_SESSION[yourkey]'") or die(mysql_error());
$MemJoinum = mysql_num_rows($MemJoin);
if($MemJoinum>0)
$MemJoiarr = mysql_fetch_array($MemJoin);
if($MemJoiarr[joined_id]!=0){
mysql_query("update members_join set status = 1 where joinkey = '$_SESSION[yourkey]'") or die(mysql_error());
}
}
 ?>
 