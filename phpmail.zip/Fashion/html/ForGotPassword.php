<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab : </title>
<link href="css/style.css" rel="stylesheet" type="text/css" />

<link href="slide/slide.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="slide/jquery-1.2.6.min.js"></script>
<script type="text/javascript">
function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');
    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 4000 );
});
</script>


<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu.css" />
<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu-v.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="top-menu/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

ddsmoothmenu.init({
	mainmenuid: "smoothmenu2", //Menu DIV id
	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
	//customtheme: ["#804000", "#482400"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<script type="text/javascript" src="js/form_vail.js"></script>
<script type="text/javascript" src="js/cleartxtbox.js"></script>


</head>
<?
if(isset($_REQUEST["hddnn"]))
{
	if($_REQUEST["hddnn"]==4)
	{
		$serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		$serverpath1= dirname($serverpath);
		$imgpath = $serverpath1."/images/logo.jpg";
		$email=$_REQUEST[email];
 		if($_REQUEST[type]=='Customer'){
 			$arr_banner= mysql_query("SELECT * FROM customers  WHERE  customers_email_address ='".$_REQUEST[email]."'");
			$num = mysql_num_rows($arr_banner);
			$row=mysql_fetch_array($arr_banner);
			$username = $row[username];
			$password = $row[customers_password];
			$name = $row[customers_firstname]." ".$row[customers_lastname];
			}elseif($_REQUEST[type]=='store'){
  			$arr_banner= mysql_query("SELECT * FROM shopper_tbl  WHERE  shopemail ='".$_REQUEST[email]."'");
			$num = mysql_num_rows($arr_banner);
			$row=mysql_fetch_array($arr_banner);
			$username = $row[shopusername];
			$password = $row[shoppass];
			$name = $row[shopowner];
 			}
				if ($num>0) {
 				$subject="Forgot Password From : www.BodyKart.in";
				$to = $email;
 				$message='<table width="472" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #342D1F">
    
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="83%" align="center"><table width="100%"  border="0" align="center" cellpadding="2" cellspacing="0">
          <tr>
            <td colspan="2"><strong>Dear Mr./Mrs./Miss. '.$name.', </strong>
                <blockquote>Congratulations, this is an auto generated mail to retrive your password successfully from the site www.BodyKart.in. your Login details are given below:</blockquote></td>
          </tr>
          <tr>
            <td align="right">Username : </td>
            <td>'.$username.'</td>
          </tr>
          <tr>
            <td align="right">Password : </td>
            <td>'.$password.'</td>
          </tr>
          <tr>
            <td colspan="2"><strong>Regards<br>
      www.BodyKart.in Mailer </strong></td>
          </tr>
        </table> </td>
      </tr>
    </table></td>
  </tr>
</table>';
  				$headers = "MIME-Version:1.0\r\n";
				$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
				$headers .= "From:info@fashionfab.in<info@fashionfab.in>\r\n";
				 // echo $to."<br>".$subject."<br>".$message."<br>".$headers;
				 mail($to, $subject, $message, $headers);		  
				 $msg1="Your Password Successfuly Sent in your email Account.<br><br>";
 
				}

				else
				{
				$msg="Enter Valid Email ID...<br><br>";
				}
 	}
	
}

 
?>
<body>
<center>
<? include"header.php"?>
<div class="main">
<div class="page_content">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td width="3%" align="left" valign="top" class="left"><? include"left.php"?></td>
    <td width="97%" valign="top" class="content"> 
      <h1>Get Password</h1>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="box2">
             
                <tr>
                  <td valign="top"><form action="" method="post" name="frmAdd" id="frmAdd" onSubmit="return validate()">
        <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
          <tr>
            <td align="center" class="catlist"> Enter your email address below to have your account information resent to you. </td>
          </tr>
          <tr>
            <td>
              <? if($msg!=""){?>
              <span class="verd12"><font color="#511111"> <b> <font color="#FF0000">Please correct these fields:</font></b><font color="#FF0000"><br>
&#149; The email address you have submitted does not exist in our database.<br>
        Please check for errors or enter a different email address.</font><br>
              </font></span>
              <? }else{?>
              <div align="center"><strong><font color="#FF0000">
                <?  echo $msg1; }  ?>
            </font></strong></div></td>
          </tr>
          <tr>
            <td height="70" align="center">
              <table border="0" cellpadding="0" cellspacing="0">
                <input name="hddnn" type="hidden" id="hddnn3" value="4">
                <tr>
                  <td><span class="texttabelnew"><font color="#1f1f1f">EMAIL ADDRESS</font><font color="black"></font></span><font color="black"><span class="verd12"><span class="verdana10"><br>
                                                                </span></span></font>
                                              <table border="0" cellpadding="0" cellspacing="0" width="64" height="1">
                                                <tr>
                                                  <td></td>
                                                </tr>
                                              </table>
                                              <span class="verd12">
                                              <input name="email" type="text" size="30" maxlength="255"   >
                                            </span></td>
                  <td width="10"></td>
                  <td><font color="white"><span class="arial10"><span class="verdana10">.</span></span></font><span class="verd12"><font color="black"><span class="verdana10"><br>
                    </span></font></span>
                      <table border="0" cellpadding="0" cellspacing="0" width="64" height="1">
                        <tr>
                          <td></td>
                        </tr>
                      </table>
                      <input type="submit" name="Submit" value="    Reset Password Now    " class="buttons" >
                      <input name="type" type="hidden" id="type" value="Customer">                  </td>
                </tr>
            </table></td>
          </tr>
        </table>
      </form></td>
                </tr>
          </table></td>
  </tr>
</table>
</div>
</div>
<? include"footer.php"?>
</center>
</body>
</html>