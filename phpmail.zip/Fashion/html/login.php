<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab : </title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="megamenu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="megamenu/css/webslidemenu.css" />
<script type="text/javascript" src="megamenu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="megamenu/font-awesome/css/font-awesome.min.css" />

<script type="text/javascript" src="js/form_vail.js"></script>
<script type="text/javascript" src="js/cleartxtbox.js"></script>
 <script language="javascript" type="text/javascript" src="js/form_vail.js"></script> 
 <script language="javascript" type="text/javascript" src="js/CapImg.js"></script>
<script language="javascript" type="text/javascript" src="js/UnameSuggestions.js"></script>

</head>

<body>
<? include"header.php"?>
<div class="inner-banner ib-s">
<div><a href="index.php">Home</a> &raquo; About us</div>
</div>

<div class="container">
<div class="content">
<h1><span>Login to Fashion Fab</span></h1>

<div class="row">
<div class="col-md-4"></div>
<div class="col-md-4">
<form action="" method="get">
  <label for="textfield2">User ID:</label>
  <input type="text" name="textfield2" id="textfield2" placeholder="Enter user id" />
  <label for="textfield3">Password:</label>
  <input type="password" name="textfield3" id="textfield3" placeholder="Enter password" />
  <input type="submit" name="button2" id="button2" value="Login" class="btn btn-success" />
</form>
</div>
<div class="col-md-4"></div>
</div>
</div>
</div>
<? include"footer.php"?>
</body>
</html>