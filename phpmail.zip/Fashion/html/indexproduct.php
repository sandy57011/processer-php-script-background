<link rel="stylesheet" type="text/css" href="wraper/skin.css">
<link href="css/style.css" rel="stylesheet" type="text/css" />


<link rel="stylesheet" type="text/css" href="carousel/responsive.css">
<script type="text/javascript" src="carousel/jquery.js"></script>
<script type="text/javascript" src="carousel/jquery.jcarousel.min.js"></script>
<script type="text/javascript" src="carousel/responsive.js"></script>



<?   
	//$SQLL= "select * from categories where pid=0 and home_page=1 order by cname ";// ORDER BY  orderby  ASC
	$RESS = mysql_query("select * from categories where pid=0 and home_page=1 order by cname ") or die(mysql_error());
	$numcp=mysql_num_rows($RESS);
	while($rec_res=mysql_fetch_array($RESS)){?>
<h2><span><a href="products.php?catid=<? echo $rec_res[cid]; ?>&cname=<?=$rec_res[cname]?>"><?	echo $rec_res[cname];?></a></span></h2>
<div class="jcarousel-wrapper">
<div class="jcarousel">
<? 
$catId  = (isset($rec_res[cid]) && $rec_res[cid] != '1') ? $rec_res[cid] : 0;
 $pdId   = (isset($_GET['p']) && $_GET['p'] != '') ? $_GET['p'] : 0;
 $children = array_merge(array($catId), getChildCategories(NULL, $catId));
   $children = ' (' . implode(', ', $children) . ')';
  ?>
  <? 
  //$SearchQueryx = "select * from products where (master_categories_id in $children) and products_status=1 and products_id = p_id order by products_id DESC limit 0,10";
  $SearchQueryx = "select * from products where (master_categories_id in $children) and products_status=1 ORDER BY RAND() DESC limit 0,10";
   				$SearchResultx= mysql_query($SearchQueryx) or die(mysql_error());
 				$SearchNumberx= mysql_num_rows($SearchResultx);
 				if($SearchNumberx==0){
  			?>
          <center>
            <span style="color:red">No record found. </span>
          </center>
          <? 
 			}
			else
			{
  				$intCounta=1;
  				// $SearchQueryx = $SearchQueryx."limit  0,3 ";
 				$selResultx= mysql_query($SearchQueryx) or die(mysql_error());
 			?>
	<ul>
		<? 
		$intCounta=0;
		while($selArrayx = mysql_fetch_array($selResultx)){
 
			  ?><li>
<div class="box1" style="width:84%; margin:2% 8%">
<a href="detail-itid-<?=$selArrayx[products_id]?>-catid-<?=$selArrayx[master_categories_id]?>.html" class="box1_i">
 
<div class="img-part">
<?php
if($selArrayx[input_url]!="") {
?> 
		
<?php } else { ?>           
<?php } ?>		  
<? if($selArrayx[products_image]!="" and file_exists($selArrayx[products_image])){?>
<img src="<?=$selArrayx[products_image]?>" /> 
<? }else{?>
<img src="product_file/no-img.jpg"/> 
<? }?>
</div>


<div class="box1-detail">

<div class="proname">
<?php
if($selArrayx[input_url]!="") {
?>  		
<?php } else { ?>                  
<?php } ?>          
<?php
if($selArrayx[product_title1]!="") {
?>
<?=ucwords(substr($selArrayx[product_title1],0,51))?><?php if(strlen($selArrayx[product_title1])>51) { echo "..."; } ?>
<?php } else { ?>
<?=ucwords(substr($selArrayx[product_title],0,51))?><?php if(strlen($selArrayx[product_title])>51) { echo "..."; } ?>
<?php } ?>
</div>


<div class="row">
<div class="col-xs-6">
<div class="old"><i class="fa fa-inr" aria-hidden="true"></i> <?php echo $selArrayx[products_oldprice]; ?>/-</div>
</div>
<div class="col-xs-6">
<div class="price"><i class="fa fa-inr" aria-hidden="true"></i> <?=$selArrayx[products_price]?> /-</div>
</div>
<div class="col-xs-12">
<button type="button" class="btn1"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add to cart</button>
</div>
</div>
</div>

<div class="off-s">
<!---------  Discount Shown Start   ----------->
<?php
if($selArrayx[products_oldprice]!="" && $selArrayx[products_price]!="" && $selArrayx[products_oldprice]>=$selArrayx[products_price]) {
$discountCalc = (($selArrayx[products_oldprice]-$selArrayx[products_price])/$selArrayx[products_oldprice])*100;
echo ceil($discountCalc)."% <br />OFF";
}
?>
<!---------  Discount Shown End   ----------->
</div>


</a>
</div>
</li>

<? }?>
</ul>
<? }?>    
</div>
		<a href="#" class="jcarousel-control-prev">&lsaquo;</a>
        <a href="#" class="jcarousel-control-next">&rsaquo;</a>
<p class="jcarousel-pagination"></p>
</div>
<? 	}
	 ?>