<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab::Contact us</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />

<link href="slide/slide.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="slide/jquery-1.2.6.min.js"></script>
<script type="text/javascript">
function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');
    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 4000 );
});
</script>


<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu.css" />
<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu-v.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="top-menu/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

ddsmoothmenu.init({
	mainmenuid: "smoothmenu2", //Menu DIV id
	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
	//customtheme: ["#804000", "#482400"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<script language="javascript" type="text/javascript">
function validate()
    { 
		//alert();
        doc =document.reuq_form;
		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		var r_name = doc.r_name.value;
		var r_email = doc.r_email.value;
		var r_mob = doc.r_mob.value;
		var r_comment = doc.r_comment.value;
		var captcha = doc.captcha.value;
        if(r_name=="")
        {
        alert('Please Enter Name');
        doc.r_name.focus();
        return false;
        }
		if(r_email=="")
        {
        alert('Please Enter Email');
        doc.r_email.focus();
        return false;
        }
		if(reg.test(r_email) == false) { 
        alert('Invalid Email Address');
        doc.r_email.value ="";
        doc.r_email.focus();
        return false;
        }
		if(r_mob=="")
        {
        alert('Please Enter Mobile Number');
        doc.r_mob.focus();
        return false;
        }
		if(isNaN(r_mob))
        {
        alert("Enter the valid Mobile Number(Like : 9566137117)");
        doc.r_mob.focus();
        return false;
        } 
		if(r_comment=="")
        {
        alert('Please Enter Message');
        doc.r_comment.focus();
        return false;
        }
		if(captcha=="")
        {
        alert('Please Enter Captcha Code');
        doc.captcha.focus();
        return false;
        }   
    }
</script>
</head>
<? if($_REQUEST[hdnenq]==1)
{
 
 	 $serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		 $serverpath1= dirname($serverpath);
		$email=$_REQUEST[r_email];
		$name=$_REQUEST[r_name];
		$contact_no=$_REQUEST[r_mob];
		$comments=$_REQUEST[r_comment];
		
$captcha = $_POST['captcha'];
$sescaptcha = $_SESSION['cap_code'];
 if($_POST['captcha'] != $_SESSION['cap_code']) {
      $captchaError = "ERROR";
	  $errloc = $_SERVER[REQUEST_URI];
	  header("Location:$errloc?er=1");
	  exit();
    }	else { 
		
	  $body='<table width="600" style="border:1px solid #943600; background-color:#F5F5F5" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" cellpadding="4" cellspacing="0">
       
      <tr>
        <td height="40" colspan="2" bgcolor="#808000" style="font-family:Trebuchet MS; font-size:14px; font-weight:bold; text-transform:uppercase; text-align:center;">Enquiry  Information For Bulk</td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
        </tr>
      <tr>
        <td width="51%" align="left"><strong>Name</strong></td>
        <td width="49%" align="left"><span style="float:left; width:270px;">'.$name.'</span></td>
        </tr>
      
      <tr>
        <td align="left"><strong>Email:</strong></td>
        <td align="left"><span style="float:left; width:270px;">'.$email.'</span></td>
      </tr>
      <tr>
        <td align="left"><STRONG>Phone:</STRONG></td>
        <td align="left"><span style="float:left; width:270px;">'.$contact_no.'</span></td>
      </tr>
      <tr>
        <td align="left"><STRONG><span class="txt4">Query</span>:</STRONG></td>
        <td align="left"><span style="float:left; width:270px;">'.$comments.'</span></td>
      </tr>
    </table></td>
  </tr>
</table>';  
 $to = "info@fashionfab.in";
$body;
 //exit();
		$subject = "Contact Information";
 		$headers = "MIME-Version:1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$from = "info@fashionfab.in";
		@mail($to,$subject,$body,$headers);
          header("Location:thankyou.php?msg=Successfully Send");
 	 
        
    } 
       

   
 
 
 }
	//$serverpath = dirname(dirname($_SERVER['HTTP_REFERER']));
?>
<body>
<center>
<? include"header.php"?>
<div class="main">
<div class="page_content">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td width="2%" valign="top" class="left"><? include"left.php"?></td>
    <td valign="top" class="content"> 
      <h1>Enquiry For Wholesale / Bulk</h1>
      <p>&nbsp;</p>
      <form action="" method="post" name="reuq_form" id="reuq_form" onSubmit="return validate()">
          <div class="txt8"><?php if($_REQUEST['er']==1) { echo "Not A Valid Code"; } ?></div>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><strong>Name:</strong></td>
                  </tr>
                  <tr>
                    <td><input name="r_name" type="text" class="txtfield" id="textfield2" /></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td><strong>Email:</strong></td>
                  </tr>
                  <tr>
                    <td><label>
                    <input name="r_email" type="text" class="txtfield" id="textfield3" />
                    </label></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td><strong>Mobile:</strong></td>
                  </tr>
                  <tr>
                    <td><label>
                    <input name="r_mob" type="text" class="txtfield" id="textfield" />
                    </label></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td><strong>Message/ Comments:</strong></td>
                  </tr>
                  <tr>
                    <td><span style="height:53px;">
                      <label>
                      <textarea name="r_comment" rows="3" class="txtarea_1" id="textarea"></textarea>
                      </label>
                    </span></td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                   <tr>
                    <td><strong>Security Code:</strong></td>
                  </tr>
                  <tr>
                    <td>
                     <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="32%"><input name="captcha" type="text" class="txtfield" id="captcha"  maxlength="6" style="width:200px;"/></td>
    <td width="68%"><img src="captcha.php"/></td>
  </tr>
</table>

                      
                      
                    </td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td>
                    <input name="input" type="image" src="images/submit.jpg" style="margin-top:2px" />
                    <input name="hdnenq" type="hidden" id="hdnenq" value="1" />                    </td>
                  </tr>
                </table>
              <div></div>
              <div></div>
              <div></div>
              </form></td>
  </tr>
</table>
</div>
</div>
<? include"footer.php"?>
</center>
</body>
</html>