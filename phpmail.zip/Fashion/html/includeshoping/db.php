<?
	@mysql_connect("localhost","root","vertrigo") or die("Demo is not available, please try again later");
	@mysql_select_db("autob") or die("Demo is not available, please try again later");
	session_start();
?>