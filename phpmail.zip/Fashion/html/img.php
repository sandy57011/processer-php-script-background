
<img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" />