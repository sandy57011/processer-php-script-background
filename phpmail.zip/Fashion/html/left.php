<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="scroller/jquery.mCustomScrollbar.css" rel="stylesheet" type="text/css" />
<!--<script type="text/javascript" src="scroller/jquery.min.js"></script>-->
<script src="scroller/jquery-ui.min.js"></script>
<!--<script type="text/javascript" src="scroller/jquery.easing.1.3.js"></script> -->
<script type="text/javascript" src="scroller/jquery.mousewheel.min.js"></script>
<script src="scroller/jquery.mCustomScrollbar.js"></script>
<script type='text/javascript' src="autocomp/jquery.autocomplete.js"></script>
<script type='text/javascript'>
 var $4444 = jQuery.noConflict();
</script>
<script>
$(window).load(function() {
	mCustomScrollbars();
});

function mCustomScrollbars(){
	/* 
	malihu custom scrollbar function parameters: 
	1) scroll type (values: "vertical" or "horizontal")
	2) scroll easing amount (0 for no easing) 
	3) scroll easing type 
	4) extra bottom scrolling space for vertical scroll type only (minimum value: 1)
	5) scrollbar height/width adjustment (values: "auto" or "fixed")
	6) mouse-wheel support (values: "yes" or "no")
	7) scrolling via buttons support (values: "yes" or "no")
	8) buttons scrolling speed (values: 1-20, 1 being the slowest)
	*/
	$4444("#mcs_container").mCustomScrollbar("vertical",400,"easeOutCirc",1.05,"auto","yes","yes",10); 
}

/* function to fix the -10000 pixel limit of jquery.animate */
$4444.fx.prototype.cur = function(){
    if ( this.elem[this.prop] != null && (!this.elem.style || this.elem.style[this.prop] == null) ) {
      return this.elem[ this.prop ];
    }
    var r = parseFloat( jQuery.css( this.elem, this.prop ) );
    return typeof r == 'undefined' ? 0 : r;
}

/* function to load new content dynamically */
function LoadNewContent(id,file){
	$4444("#"+id+" .customScrollBox .content").load(file,function(){
		mCustomScrollbars();
	});
}
</script>




<link href="v_ticker/v_ticker.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="v_ticker/jquery.vticker-min.js"></script>
<script type='text/javascript'>
 var $3333 = jQuery.noConflict();
</script>
<script type="text/javascript">
$(function(){
	$3333('#news-container').vTicker({ 
		speed: 1500,
		pause: 5000,
		animation: 'fade',
		mousePause: false,
		showItems: 1
	});
});
</script>

<? if($_REQUEST[hdnenq]==1)
{
 
 	 $serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		 $serverpath1= dirname($serverpath);
		$email=$_REQUEST[r_email];
		$name=$_REQUEST[r_name];
		$contact_no=$_REQUEST[r_mob];
		$comments=$_REQUEST[r_comment];
	 
		
	  $body='<table width="600" style="border:1px solid #943600; background-color:#F5F5F5" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" cellpadding="4" cellspacing="0">
       
      <tr>
        <td height="40" colspan="2" bgcolor="#808000" style="font-family:Trebuchet MS; font-size:14px; font-weight:bold; text-transform:uppercase; text-align:center;">enquiry  Information</td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
        </tr>
      <tr>
        <td width="51%" align="left"><strong>Name</strong></td>
        <td width="49%" align="left"><span style="float:left; width:270px;">'.$name.'</span></td>
        </tr>
      
      <tr>
        <td align="left"><strong>Email:</strong></td>
        <td align="left"><span style="float:left; width:270px;">'.$email.'</span></td>
      </tr>
      <tr>
        <td align="left"><STRONG>Phone:</STRONG></td>
        <td align="left"><span style="float:left; width:270px;">'.$contact_no.'</span></td>
      </tr>
      <tr>
        <td align="left"><STRONG><span class="txt4">Query</span>:</STRONG></td>
        <td align="left"><span style="float:left; width:270px;">'.$comments.'</span></td>
      </tr>
    </table></td>
  </tr>
</table>';  
 $to = "info@fashionfab.in";
 $body;
		$subject = "Contact Information";
 		$headers = "MIME-Version:1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$headers .= "From:info@fashionfab.in<info@fashionfab.in>\r\n";
		@mail($to,$subject,$body,$headers);
          header("Location:thankyou.php?msg=Successfully Send");
 }
	//$serverpath = dirname(dirname($_SERVER['HTTP_REFERER']));
?>





<table width="100%" border="0" cellspacing="0" cellpadding="0"> 
  <tr>
    <td>
	<?  if($_REQUEST[catid]!=''){
$ssql1 = "select pid from categories where cid = $_REQUEST[catid]";
$RESl1 = mysql_query($ssql1) or die(mysql_error());
$ARR11 = mysql_fetch_array($RESl1);
$ppidcat = $ARR11['pid'];
if($ppidcat=='0')  {	
  $SQL = "select * from categories where pid = $_REQUEST[catid] order by cname";
 } else {
 $SQL = "select * from categories where pid = $ppidcat order by cname";
 } 
	$RES = mysql_query($SQL) or die(mysql_error());
	$numcp=mysql_num_rows($RES); 
	if($numcp!=0) {?>
<div class="leftbox">
<div class="leftbox_b2">
<div>
<ul>
<?php
	while($ARR = mysql_fetch_array($RES)){
	?>
<?php
$cntSql = mysql_query("select master_categories_id from products where master_categories_id = '$ARR[cid]' and products_status = 1");
$numsubmenu = mysql_num_rows($cntSql);
if($numsubmenu>0) {
?>    
 	<li><a href="detail-catid-<?=$ARR[cid]?>-cname-<?=$ARR[cname]?>.html"><? echo $ARR[cname]; ?></a> </li>
<? }?>	
<? }?>
</ul>
</div>
</div>
</div>
<? } ?>






<? @$fectahparrent=mysql_fetch_array(mysql_query("select Childs,cid,pid,cname from categories where cid=$_REQUEST[catid]"));

if($numcp==0) {   
$fectahparrent[pid];
  $SQLx = "select * from categories where pid = $fectahparrent[pid] order by cname";
	$RESx = mysql_query($SQLx) or die(mysql_error());
	$numcpx=mysql_num_rows($RESx); 
	if($numcpx!=0) {?>
	<?php /*?><div class="leftbox">
<div>
  <h3>CATEGORIES</h3>
</div>
<div class="leftbox_b">
<div id="smoothmenu2" class="ddsmoothmenu-v">
<ul>
<?
	while($ARRx = mysql_fetch_array($RESx)){
	?>
 	<li><a href="detail-catid-<?=$ARRx[cid]?>-cname-<?=$ARRx[cname]?>.html"><? echo $ARRx[cname]; ?></a> </li><? }?>
</ul>
</div>
</div>
</div><?php */?>


<?

 }

} }
if($_REQUEST[catid]==''){
/*
  $SQL = "select * from categories where pid=0  order by cname ";
	$RES = mysql_query($SQL) or die(mysql_error());
	$numcp=mysql_num_rows($RES); 
	if($numcp!=0) {?>
<div class="leftbox">
 
<div>
  <h3>CATEGORIES</h3>
</div>
<div class="leftbox_b">
<div id="smoothmenu2" class="ddsmoothmenu-v">
<ul>
<?
	while($ARR = mysql_fetch_array($RES)){
	?>
 	<li><a href="detail-catid-<?=$ARR[cid]?>-cname-<?=$ARR[cname]?>.html"><? echo $ARR[cname]; ?></a> </li><? }?>
</ul>
</div>
</div>
</div>
<? } */?>


<?  } ?></td>
  </tr>
  
 <?php
  $SQL = "select * from products where products_offer = 1 order by products_id ASC";
 $RES = mysql_query($SQL) or die(mysql_error());
 $offercount = mysql_num_rows($RES);
 if($offercount>0) {
 ?> 
  
  
  <tr>
    <td>
    <div class="leftbox">
<h3>NEW OFFER</h3>
<div class="leftbox_b">
  <div id="news-container">
          <ul>
<?php           
                 

	while($ARR = mysql_fetch_array($RES)){
?>	
<!--  Offer Product Listing Start -->          
            <li>
            <strong><a href="detail-itid-<?=$ARR[products_id]?>-catid-<?=ucwords($ARR[master_categories_id])?>.html"><?=ucwords(substr($ARR[product_title],0,25))?><?php if(strlen($ARR[product_title])>25) { echo "..."; } ?></a></strong>
            <img src="<?php echo $ARR[products_image]; ?>" alt="elcom" width="75" height="75" /><br /><span>Rs. <?php echo $ARR[products_oldprice]; ?>/-</span><br />
            Price: <?php echo $ARR[products_price]; ?>/-</li>
           
<? } ?>            
          </ul>
        </div>
</div>
</div>
    </td>
  </tr>
  
  
<?php } ?>  
  
  
  <tr>
    <td>
    
    <form   method="post" name="quicksearch" id="quicksearch" action="result.php" >
    <div class="leftbox">
    	<h3>BROWSE BY BRAND</h3>
        <div class="leftbox_b" style="padding:10px 0 10px 10px;">
        <div id="mcs_container">
	<div class="customScrollBox">
		<div class="container">
    		<div class="content">
        <?
$brandx="";
//print_r($_REQUEST[mothertonguearray]);
for($kk=0;$kk<count($_REQUEST[brand]);$kk++)
  {
   if($kk>0)
   $brandx.=",".$_REQUEST[brand][$kk];
   else
   $brandx.=$_REQUEST[brand][$kk];
   }
   $brandxxx = explode(",",$brandx);
if($sql!="") {
//$rrss = mysql_query($sql);
} 



 
$Sql= "select * from brand order by name";
//$forleftSQL = 
//echo $_REQUEST[catid];
$Sql= "select distinct brand from products where  master_categories_id = '".$_REQUEST[catid]."' order by master_categories_id";
if($sqlleftall!="") {
$Sql = $sqlleftall;
}
//echo $sqlleftall;
//echo $Sql;

$Result = mysql_query($Sql) or die(mysql_error());

if($sqlleftall!="") {
//echo $sqlleftall;
$ArrayC11 = mysql_fetch_array($Result);
$masterCatidd11 = $ArrayC11['master_categories_id'];

$Sql90= "select distinct brand from products where  master_categories_id = '".$masterCatidd11."' order by master_categories_id";
$Result = mysql_query($Sql90) or die(mysql_error());
}
$bbrandd = mysql_num_rows($Result);
while($ArrayC1 = mysql_fetch_array($Result)){
	$brandArr .= ",".$ArrayC1['brand'];
}

$brandArr = substr($brandArr,1);
$brandArr = explode(",",$brandArr);
$brandArr11 = explode(",",$brandArr);
sort($brandArr);
$brandArr = array_unique($brandArr);

//$numbrand = mysql_num_rows($Result);

//while($ArrayC = mysql_fetch_array($Result)){
//echo count($brandArr);
//if(count($brandArr)>0) {
//echo $_REQUEST['catid'];
?>

<input type="hidden" name="catid" id="catid" value="<?php if($_REQUEST['catid']!="") { echo $_REQUEST['catid']; } else { echo $masterCatidd11; } ?>" />

<?php
if($_REQUEST[catid]!="") {
$Sqlleft= "select distinct brand from products where  master_categories_id = '".$_REQUEST[catid]."' order by master_categories_id";
} else {
$Sqlleft= "select distinct brand from products where  master_categories_id = '".$masterCatidd11."' order by master_categories_id";
}
$Resultleft = mysql_query($Sqlleft) or die(mysql_error());
$bbranddleft = mysql_num_rows($Resultleft);
while($ArrayC1left = mysql_fetch_array($Resultleft)){
	$brandArrleft .= ",".$ArrayC1left['brand'];
}
$brandArrleft = substr($brandArrleft,1);
$brandArrleft = explode(",",$brandArrleft);
//$brandArrleft11 = explode(",",$brandArrleft);
sort($brandArrleft);
$brandArrleft = array_unique($brandArrleft);
?>
<?php
//echo $bbranddleft;
//echo "<br>";
//echo $bbrandd;
?>

<?php
if($bbranddleft>0) {
foreach($brandArrleft as $x=>$x_value) {
?>
<div class="txt5">
<input type="radio" name="brand[]"  id="rdobrand<?=$x_value?>" onclick="submit();"  value="<?=$x_value?>"
<?php /*?><? if(strstr($brandx,$ArrayC[brand])){?> checked<? }?>  /><?php */?>
<?php if(in_array($x_value, $brandxxx)) { ?> checked="checked" <?php } ?> />
<label for="rdobrand<?=$x_value?>">
<?php
$arrbdARR = mysql_fetch_array(mysql_query("select name from brand where cid = '".$x_value."'"));
echo $arrbdARR['name'];
?></label></div>
<? } } ?>

        </div>
        
		</div>
		<div class="dragger_container">

    		<div class="dragger"></div>
		</div>
	</div>
    <a href="#" class="scrollUpBtn"></a> <a href="#" class="scrollDownBtn"></a>
</div>
</div>    
</div>

<!----------------------------------->
<?php

?>


<?php
//if($_REQUEST['itid']!="") {
include("opoption.php");
if(count($opidsArray)>0) {
foreach($opidsArray as $key => $value) { ?>


<div class="leftbox">
<h3>Browse By 
<?php    
	echo getOptionNameById($key); ?></h3>
	<input type="hidden" name="leftoption_id[]" id="leftoption_id" value="<?php echo $key; ?>" />
<div class="leftbox_b">    
<?php    
/***************/
$rdocnt =0;
foreach($resultArrayField as $key11 => $value11) {
$rdocnt++;
?>
<!------------------->
<?php
$ssqlz = mysql_query("select * from product_option_field where id = '".$value11."' and product_option_id = '".$key."' order by product_option_id ASC");
$rowz = mysql_fetch_array($ssqlz);
//echo $rowz['id'];

$searchoptionidsubstr11Explods = explode(",",$searchoptionidsubstr11);
?>
<?php if($rowz['id']!="") { ?>
<p><input id="leftrdo<?php echo $rowz['product_option_id']; ?><?php echo $rdocnt; ?>" type="radio" name="leftrdo<?php echo $rowz['product_option_id']; ?>[]" value="<?php echo $rowz['id']; ?>" onclick="submit();" 

<?php
foreach($searchoptionidsubstr11Explods as $key2 => $value2) {
?>
<?php if($value2==$rowz['id']) { ?> checked="checked" <?php }  } ?>
/>
<label for="leftrdo<?php echo $rowz['product_option_id']; ?><?php echo $rdocnt; ?>">
<?php echo $rowz['product_option_name']; }?></label></p>
<?php } ?>
</div></div>
<?php	
}  } //}
?> 




<!----------------------------------->

<div class="leftbox">
<h3>Browse By Price</h3>
<div class="leftbox_b">
<p><input id="0" name="price" type="radio" value="1" <? if($_REQUEST['price'] =='1') { ?> checked="checked" <? }?> onclick="submit();"/><label for="0">&nbsp;0-500</label></p>
<p><input id="500" name="price" type="radio" value="2" <? if($_REQUEST['price'] =='2') { ?> checked="checked" <? }?> onclick="submit();"/>
<label for="500"> 500-1000</label></p>
<p>
<input id="1000" name="price" type="radio" value="3" <? if($_REQUEST['price'] =='3') { ?> checked="checked" <? }?> onclick="submit();"/>
<label for="1000"> 1000-1500</label></p>
<p>
<input id="1500" name="price" type="radio" value="4" <? if($_REQUEST['price'] =='4') { ?> checked="checked" <? }?> onclick="submit();"/>
<label for="1500"> 1500-2000</label></p>
<p>
<input id="2000" name="price" type="radio" value="5" <? if($_REQUEST['price'] =='5') { ?> checked="checked" <? }?> onclick="submit();" />
<label for="2000"> 2000 above</label></p>
</div>
</div>
</form>
   </td>
  </tr>
</table>