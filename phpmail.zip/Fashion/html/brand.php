<h2><span>Browse by Brand</span></h2>
<div class="brand-marquee">
<form method="post" name="quicksearch" id="quicksearch" action="result.php" >
<?php
//$Query = "select * from brand where b_image!=''";
$Ress = mysql_query("select * from brand where b_image!=''") or die(mysql_error());
   while($fetch =  mysql_fetch_array($Ress))
   {
?>
<div class="item"><a href="result.php?bbrand=<?php echo $fetch[cid]; ?>"><img src="images/brand/<?php echo $fetch[b_image]; ?>" /></a>                    
</div>
 <?php
}
?>
</form>
<div class="clear"></div>
</div>