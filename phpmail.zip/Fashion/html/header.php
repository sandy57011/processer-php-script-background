<script type='text/javascript' src="autocomp/jquery.autocomplete.js"></script>
<link rel="stylesheet" type="text/css" href="autocomp/jquery.autocomplete.css" />
<script type='text/javascript'>
 var $2222 = jQuery.noConflict();
</script>

<script type="text/javascript">
$().ready(function() {
//alert();
	$2222("#textfield").autocomplete("autocomplete.php", {
	width: 280,
	matchContains: true,
	selectFirst: false
});
});
</script>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/style2.css" rel="stylesheet" type="text/css" />



<header>
<div class="container">
<div class="row">
<div class="col-md-4">
<a href="index.php"><img src="images/logo.png" alt="Fashion Fab" /></a>
</div>


<div class="col-md-4 h-c">
<a href="login.php">Login</a> | <a href="#">Register</a>
</div>


<div class="col-md-4">
<div style="width:1px; height:1px; overflow:hidden"><? include("search_by.php");?></div>
<div class="search">
		    <form id="t-search" name="t-search" method="post" action="result.php">
		    	<input type="text" name="textfield" id="textfield" value="" placeholder="search...">
				<button name="button" type="submit" id="button" value=""><i class="fa fa-search" aria-hidden="true"></i></button>
			</form>
		</div> 
</div>


</div>
</div>
</header>



<div class="side-panel">



<div class="cart">
<a href="shoppingcart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span><?=count($_SESSION['cart']);?></span></a>
</div>

<div class="cart">
<a href="#" title="Favourite"><i class="fa fa-heart" aria-hidden="true"></i></a>
</div>

<div class="social">
<ul>
<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
</ul>
</div>


<div class="call">
+91-98765 43210 <i class="fa fa-phone" aria-hidden="true"></i>
</div>


</div>


<div class="t-menu">
<div class="wsmenucontainer">
  <div class="wsmenuexpandermain slideRight"><a id="navToggle" class="animated-arrow slideLeft" href="#"><span></span></a></div>
  <div class="wsmenucontent overlapblackbg"></div>
  <div>
 <!--Menu HTML Code-->
<nav class="wsmenu slideLeft clearfix">
		<ul class="mobile-sub wsmenu-list">          
          <li><a href="<?php echo $rootpath; ?>/">Home</a></li>
          <li><a href="about-us.php">About Us</a></li>          
          
          
        
<!-- dynamic pages -->
<? //$SQL = "select * from categories where pid = 0  order by cname  ";
	$RES = mysql_query("select * from categories where pid = 0  order by cname limit 0,9") or die(mysql_error());
	while($ARR = mysql_fetch_array($RES)){
	?>    
<li><a href="detail-catid-<? echo $ARR[cid]; ?>-cname-<?=stripslashes($ARR[cname])?>.html"><? echo stripslashes($ARR[cname]); ?></a>


  <?
	//$SUBCATSQL = "select * from categories where pid = '$ARR[cid]' order by cname";
	$SUBCATres = mysql_query("select * from categories where pid = '$ARR[cid]' order by cname") or die(mysql_error());
	while($SUBCATARR = mysql_fetch_array($SUBCATres)){ 
	//$SUBCATSQLS = "select * from categories where pid = '$SUBCATARR[cid]' order by cname";  ?>
    
<?php
$cntSql1 = mysql_query("select master_categories_id from products where master_categories_id = '$SUBCATARR[cid]' and products_status  = 1");
$numsubmenu1 = mysql_num_rows($cntSql1);
if($numsubmenu1>0) {
?>    
    
	
<?php 
$cntSql1 = mysql_query("select master_categories_id from products where master_categories_id = '$SUBCATARR[cid]' and products_status  = 1");
$numsubmenu1 = mysql_num_rows($cntSql1);
if($numsubmenu1>0) { ?>
<ul class="wsmenu-submenu">
<?php
$SUBCATres = mysql_query("select * from categories where pid = '$ARR[cid]' order by cname") or die(mysql_error());
	while($SUBCATARR = mysql_fetch_array($SUBCATres)){
?>

<?php
$cntSql = mysql_query("select master_categories_id from products where master_categories_id = '$SUBCATARR[cid]' and products_status  = 1");
$numsubmenu = mysql_num_rows($cntSql);
if($numsubmenu>0) {
?>    
    <li><a href="detail-catid-<? echo $SUBCATARR[cid]; ?>-cname-<?=stripslashes($SUBCATARR[cname])?>.html"  ><? echo stripslashes($SUBCATARR[cname]); ?></a></li> 
<? } ?>	

    
 <? } ?>	   
    
    
   </ul>
   <? } ?>
   
  <? } ?>  
   
   
   
  
   
<? }?> 


  
   
   
   
   
   
</li>
<? }?>
</li>
<li><a href="contact-us.php">Contact Us</a></li>
<!-- Dynamic pages end --> 


</ul>
</nav>
</div> 
</div>
</div>



  