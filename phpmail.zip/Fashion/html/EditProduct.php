<?
 if($_REQUEST[btnSubmit]){
//.exe, .sh, .pl, .php, .cgi, .asp, .aspx
$other="";
   for($n=0;$n<count($_REQUEST[other]);$n++)
  {
    if($n>0)
   $other.=", ".$_REQUEST[other][$n];
   else
   $other.=$_REQUEST[other][$n];
   }
   	
$intFile=mt_rand();
	 if($_FILES["articleFile"]["name"]!=""){
 						if($_REQUEST[ExistImage]!=""){
 							@unlink($_REQUEST[ExistImage]);
  						}
	$filename1 = "product_file/".$intFile.$_FILES[articleFile][name];					
move_uploaded_file($_FILES[articleFile][tmp_name],"../".$filename1);
  				}else{
				$filename1=$_REQUEST[ExistImage];
				}
	 if($_FILES["articleFile2"]["name"]!=""){
 						if($_REQUEST[ExistImage2]!=""){
 							@unlink($_REQUEST[ExistImage2]);
  						}
	$filename2 = "product_file/".$intFile.$_FILES[articleFile2][name];					
move_uploaded_file($_FILES[articleFile2][tmp_name],"../".$filename2);
  				}else{
				$filename2=$_REQUEST[ExistImage2];
				}
	if($_FILES["articleFile3"]["name"]!=""){
 						if($_REQUEST[ExistImage3]!=""){
 							@unlink($_REQUEST[ExistImage3]);
  						}
	$filename3 = "product_file/".$intFile.$_FILES[articleFile3][name];					
move_uploaded_file($_FILES[articleFile3][tmp_name],"../".$filename3);
  				}else{
				$filename3=$_REQUEST[ExistImage3];
				}
 /**icon image code**/
 $intFile=mt_rand();
	 if($_FILES["icon1"]["name"]!=""){
 						if($_REQUEST[Existicon1]!=""){
 							@unlink($_REQUEST[Existicon1]);
  						}
	$icon1 = "icon1/".$intFile.$_FILES[icon1][name];					
move_uploaded_file($_FILES[icon1][tmp_name],"../".$icon1);
  				}else{
				$icon1=$_REQUEST[Existicon1];
				}
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon2"]["name"]!=""){
 						if($_REQUEST[Existicon2]!=""){
 							@unlink($_REQUEST[Existicon2]);
  						}
	$icon2 = "icon2/".$intFile.$_FILES[icon2][name];					
move_uploaded_file($_FILES[icon2][tmp_name],"../".$icon2);
  				}else{
				$icon2=$_REQUEST[Existicon2];
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon3"]["name"]!=""){
 						if($_REQUEST[Existicon3]!=""){
 							@unlink($_REQUEST[Existicon3]);
  						}
	$icon3 = "icon3/".$intFile.$_FILES[icon3][name];					
move_uploaded_file($_FILES[icon3][tmp_name],"../".$icon3);
  				}else{
				$icon3=$_REQUEST[Existicon3];
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon4"]["name"]!=""){
 						if($_REQUEST[Existicon4]!=""){
 							@unlink($_REQUEST[Existicon4]);
  						}
	$icon4 = "icon4/".$intFile.$_FILES[icon4][name];					
move_uploaded_file($_FILES[icon4][tmp_name],"../".$icon4);
  				}else{
				$icon4=$_REQUEST[Existicon4];
				}	
/***************************/
 $intFile=mt_rand();
	 if($_FILES["icon5"]["name"]!=""){
 						if($_REQUEST[Existicon5]!=""){
 							@unlink($_REQUEST[Existicon5]);
  						}
	$icon5 = "icon5/".$intFile.$_FILES[icon5][name];					
move_uploaded_file($_FILES[icon5][tmp_name],"../".$icon5);
  				}else{
				$icon5=$_REQUEST[Existicon5];
				}																
				
 /*****/
				//products_isFeatured = '".$_REQUEST[productFeatured]."',
	    $sql = "update products set products_model = '".$_REQUEST[products_model]."',product_make = '".$_REQUEST[	product_make]."',product_title = '".$_REQUEST[ProductTitle]."',
	  icon1 ='".$icon1."',icon2 ='".$icon2."',icon3 ='".$icon3."',icon4 ='".$icon4."',icon5 ='".$icon5."',
	  products_image ='".$filename1."',products_image2='".$filename2."',products_image3='".$filename3."',products_price = '".$_REQUEST[productprice]."', Description = '".$_REQUEST[productSummary]."', products_date_added = '".time()."', products_quantity_order_min = '".$_REQUEST[minorder]."', customerdiscount = '".$_REQUEST[customerdiscount]."',discountpercentage = '".$_REQUEST[discount]."', master_categories_id = '".$_REQUEST[productCat]."', products_status = '".$_REQUEST[productStatus]."',authorsummary = '".$_REQUEST[authorsummary]."',author = '".$_REQUEST[author]."',sibn = '".$_REQUEST[sibn]."',npage = '".$_REQUEST[npage]."',cover = '".$_REQUEST[cover]."',rarebooks = '".$_REQUEST[rarebooks]."',dltime = '".$_REQUEST[dltime]."',stock = '".$_REQUEST[stock]."',brand = '".$_REQUEST[brand]."',mrpprice = '".$_REQUEST[mrpprice]."',shortdesc = '".$_REQUEST[shortdesc]."',specification = '".$_REQUEST[specification]."',emdvedio='".$_REQUEST[emdvedio]."' where products_id = '".$_REQUEST[ProductID]."'"; 
		mysql_query($sql) or die(mysql_error());
		$articleID=$_REQUEST[ProductID];
 	 		 
		  header("Location:home.php?PageURL=EditProduct&ProductID=$_REQUEST[ProductID]&catid=$_REQUEST[productCat]&cname=$_REQUEST[cname]&intMSG=<li>Product Successfully Updated&articleID=".$_REQUEST[articleID]);
	
	 
}
  $SQL=mysql_query("select * from products where products_id='".$_REQUEST[ProductID]."'") or die(mysql_error());
 $myRows=mysql_fetch_array($SQL);
?>
<link href="images/class.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
.style3 {color: #FF0000; font-weight: bold; }
-->
</style>
<br>
     <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="ckfinder/ckfinder.js"></script> 

<table width="95%" border="0" cellpadding="3" cellspacing="0"  >
  <tr  > 
    <td bgcolor="#CCCCCC" class="headR" ><strong>Edit Product  </strong></td>
  </tr>
  <tr > 
    <form action="" method="post" enctype="multipart/form-data" name="frmArticle" id="frmArticle" onSubmit="return validate()">
      <td class="tableBorderDarkGrey"> <table width="100%"  border="0" cellpadding="3" cellspacing="1"  class="text" >
          <?
	 if($Msg!="" or $_REQUEST[intMSG]!="")
	 	{
	 ?>
          <tr align="center"> 
            <td colspan="2" class="errortext"> 
              <?=$Msg?><?=$_REQUEST[intMSG]?>            </td>
          </tr>
          <? }?>
          <tr> 
            <td width="50%" align="center" ><table width="100%"  border="0" cellpadding="3" cellspacing="4" class="text">
              <tr>
                <td><span class="style3">*</span><strong>Category Name :</strong></td>
                <td>  
                  <select name="productCat" id="select2" class="textbox">
                    <option value="" selected>Select</option>
                    <?
							$sql3="select * from categories where pid=0";
							$rs3=mysql_query($sql3);
							//cid, cname, pid, Childs, LevelFromRoot
							while ($row3 = mysql_fetch_array($rs3))
							{
							$AccumulatedNodes= array();
							$NodeLevel= array();
							$NodesToTraverse= array();
							$NodesExpire= array();
							
								
 								array_unshift($AccumulatedNodes, $row3[cid]);
								array_unshift($NodesToTraverse, $row3[cid]);
   								while(count($NodesToTraverse)>0)
								{
									$OpenNodeId=array_shift($NodesToTraverse);
									array_push($NodesExpire, $OpenNodeId);
									$query4="select * from categories where cid=$OpenNodeId";
									$res4=mysql_query($query4);
									$row4 = mysql_fetch_array($res4);
									if($row4[Childs]!="")
									{
										$Childs= array();
										$Childs=explode(',', $row4[Childs]);
										$NumChilds=count($Childs)-1;
										for($i=$NumChilds-1;$i>=0;$i--)
										{
 											array_unshift($AccumulatedNodes, $Childs[$i]);
											array_unshift($NodesToTraverse, $Childs[$i]);
										}
										unset($Childs);
									}
  								}
								$AccumulatedNodes = array_reverse($AccumulatedNodes, false);
								reset($NodesExpire);
								for($i=0;$i<count($NodesExpire);$i++)
								{
									$query5="select * from categories where cid=$NodesExpire[$i]";
									$res5=mysql_query($query5);
									$row5 = mysql_fetch_array($res5);
 									?>
                    <option value="<?=$row5[cid]?>" <? if($row5[cid]==$myRows[master_categories_id]){?>selected <? }?> >
                    <? for($j=0;$j<$row5[LevelFromRoot];$j++){ echo ">"; } ?>
                    <?=$row5[cname]?>
                    </option>
                    <?
								}
 							unset($AccumulatedNodes, $NodeLevel, $NodesToTraverse, $NodesExpire);
							}																									
							?>
                  </select>                 </td>
              </tr>
               
            </table>              </td>
            <td align="left"><table width="100%" border="0" class="text">
              <tr>
                <td><span class="style3">* </span><strong>  Name :</strong></td>
                <td><input name="ProductTitle" type="text"    class="textbox" id="ProductTitle" value="<?=$myRows[product_title]?>" size="30" maxlength="255" /></td>
              </tr>
            </table></td>
          </tr>
          
        
          <tr align="center"  >
            <td colspan="2"><table width="100%" border="0" cellspacing="3" cellpadding="2">
              <tr>
                <th scope="row"><table width="100%" border="0" cellpadding="3" cellspacing="4" class="text">
                    <tr>
                      <td align="left" valign="top"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Make </strong> :</strong></td>
                      <td align="left" valign="top"><input name="product_make" type="text"    class="textbox" id="product_make" value="<?=$myRows[product_make]?>" size="30" maxlength="255" /></td>
                    </tr>
                </table></th>
                <td><table width="100%" border="0" cellpadding="3" cellspacing="4" class="text">
                    <tr>
                      <td align="left" valign="top"><span class="style3">* </span><strong> <span class="style3"> </span><strong> Model Name</strong> :</strong></td>
                      <td align="left" valign="top"><input name="products_model" type="text"    class="textbox" id="products_model" value="<?=$myRows[products_model]?>" size="30" maxlength="255" /></td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr align="center"  >
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr align="center"  >
            <td colspan="2"><span class="style3">* </span><strong>Product Detail </strong></td>
          </tr>          <tr align="center" >
            <td colspan="2">&nbsp; </td>
            </tr>  
			        
			<?
			if($myRows[products_image]!=""){
			?>
          <tr  >
            <td align="right"><strong>Existing Product Related File 1 : </strong></td>
            <td><img src="../<?=$myRows[products_image]?>" width="100" height="100">
			<input type="hidden" name="ExistImage" value="<?=$myRows[products_image]?>" />			</td>
          </tr>
		  <? } ?>
          <tr  >
            <td align="right"><strong>Product Related File 1 : </strong></td>
            <td><input name="articleFile" type="file" id="articleFile"></td>
          </tr>
		  <?
			if($myRows[products_image2]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product Related File 2 :</strong></td>
		     <td><img src="../<?=$myRows[products_image2]?>" width="100" height="100">
			 <input type="hidden" name="ExistImage2" value="<?=$myRows[products_image2]?>" /></td>
	      </tr>
		    <? } ?>
		   <tr  >
		     <td align="right"><strong>Product Related File 2 :</strong></td>
		     <td><input name="articleFile2" type="file" id="articleFile2" /></td>
	      </tr>
		   <?
			if($myRows[products_image3]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product Related File 3 :</strong></td>
		     <td><img src="../<?=$myRows[products_image3]?>" width="100" height="100">
			 <input type="hidden" name="ExistImage3" value="<?=$myRows[products_image3]?>" /></td>
	      </tr>
		   <? } ?>
		   <tr  >
		     <td align="right"><strong>Product Related File 3 :</strong></td>
		     <td><input name="articleFile3" type="file" id="articleFile3" /></td>
	      </tr>
		 <?
			if($myRows[icon1]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product icon1 :</strong></td>
		     <td><img src="../<?=$myRows[icon1]?>"  >
			 <input type="hidden" name="Existicon1" value="<?=$myRows[icon1]?>" /></td>
	      </tr>
		   <? } ?>
          <tr  >
            <td align="right"><strong>icon1</strong></td>
            <td><input name="icon1" type="file" id="icon1" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
           <?
			if($myRows[icon2]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product icon2 :</strong></td>
		     <td><img src="../<?=$myRows[icon2]?>"  >
			 <input type="hidden" name="Existicon2" value="<?=$myRows[icon2]?>" /></td>
	      </tr>
		   <? } ?>
          <tr  >
            <td align="right"><strong>icon2</strong></td>
            <td><input name="icon2" type="file" id="icon2" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
		   <?
			if($myRows[icon3]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product icon3 :</strong></td>
		     <td><img src="../<?=$myRows[icon3]?>"  >
			 <input type="hidden" name="Existicon3" value="<?=$myRows[icon3]?>" /></td>
	      </tr>
		   <? } ?>
          <tr  >
            <td align="right"><strong>icon3</strong></td>
            <td><input name="icon3" type="file" id="icon3" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
		  		   <?
			if($myRows[icon4]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product icon4 :</strong></td>
		     <td><img src="../<?=$myRows[icon4]?>"  >
			 <input type="hidden" name="Existicon4" value="<?=$myRows[icon4]?>" /></td>
	      </tr>
		   <? } ?>
          <tr  >
            <td align="right"><strong>icon4</strong></td>
            <td><input name="icon4" type="file" id="icon4" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
		  		  		   <?
			if($myRows[icon5]!=""){
			?> 
		   <tr  >
		     <td align="right"><strong>Existing Product icon5 :</strong></td>
		     <td><img src="../<?=$myRows[icon5]?>"  >
			 <input type="hidden" name="Existicon5" value="<?=$myRows[icon5]?>" /></td>
	      </tr>
		   <? } ?>
          <tr  >
            <td align="right"><strong>icon5</strong></td>
            <td><input name="icon5" type="file" id="icon5" />
              image size (width:45,/\Height:45px;) </td>
          </tr>
          <tr  >
            <td align="right"><strong>SKU</strong></td>
            <td><input name="sibn" type="text" id="sibn" value="<?=$myRows[sibn]?>" /></td>
          </tr>

          <tr  >
            <td align="right"><strong>MRP</strong><strong>Price</strong> </td>
            <td><input name="productprice" type="text" id="productprice"  value="<?=$myRows[products_price]?>"></td>
          </tr>
          <tr  >
            <td align="right"><strong>Brand Name</strong> </td>
            <td><select name="brand" size="1" class="textfield3" id="brand">
                    <!-- ************************ Start  Code for select category ***************-->
                    <option  value="">Select Brand</option>
 		   
                      <? $Sql= "select * from brand ";
 			$Result = mysql_query($Sql) or die(mysql_error());
		while($ArrayC = mysql_fetch_array($Result)){
	  ?>
                    <option value="<?=$ArrayC[cid]?>"  style="font-size:12px;" <? if($ArrayC[cid]==$myRows[brand]){ echo "selected"; }else{?> <? } ?>>
                    <?=$ArrayC[name]?>
                    </option>
                    <? }?>
                    
                     
                  </select></td>
          </tr>
          <tr  >
            <td align="right"><strong>Stock</strong></td>
            <td><input name="stock" type="radio" value="1" <? if ($myRows[stock]=="1") {?> checked="checked" <? } ?> />
              <strong>              In Stock</strong> 
              <input name="stock" type="radio" value="0" <? if ($myRows[stock]=="0") {?> checked="checked" <? } ?> />
              <strong>Out of Stock </strong></td>
          </tr>
          <tr  >
            <td align="right"><strong>Delivery Time </strong></td>
            <td><input name="dltime" type="text" id="dltime" value="<?=$myRows[dltime]?>" style="width:400px;" /></td>
          </tr>
   <tr align="center"  >
            <td colspan="2"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><strong>Prodyduct Short Detail </strong></td>
              </tr>
              <tr>
                <td colspan="2" align="center"><textarea id="shortdesc" name="shortdesc" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[shortdesc]?></textarea>&nbsp;</td>
              </tr>
			  	<script type="text/javascript">		
		var editor = CKEDITOR.replace( 'shortdesc',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
              <tr>
                <td colspan="2" align="center"><span class="style3"> </span> 
                   <span class="style3">* </span><strong> About Product : </strong> </td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
				<textarea id="productSummary" name="productSummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[Description]?></textarea>                 </td>
                </tr>
				<script type="text/javascript">		
		var editor = CKEDITOR.replace( 'productSummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
            </table></td>
          </tr>
		    <tr align="center"  >
            <td colspan="2"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><span class="style3">* </span><strong> Product feature  : </strong></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
				<textarea id="authorsummary" name="authorsummary" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[authorsummary]?></textarea>                 </td>
                </tr>
            </table></td>
          </tr>
      
           <script type="text/javascript">		
		var editor = CKEDITOR.replace( 'authorsummary',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script>
 <tr align="center"  >
            <td colspan="2"><table width="100%"  border="0" cellpadding="1" cellspacing="1" class="text">
              <tr>
                <td colspan="2" align="center"><span class="style3">* </span><strong> Product specification  : </strong></td>
                </tr>
              <tr>
                <td colspan="2" align="center"> 
				<textarea id="specification" name="specification" cols="47" rows="5" style="width:46%;px; height:180px; background-color:#FFFFFF" mce_editable="true"><?=$myRows[specification]?></textarea>                 </td>
                </tr>
            </table></td>
          </tr>
      
           <?php /*?><script type="text/javascript">		
		var editor = CKEDITOR.replace( 'specification',{ customConfig : '<?=$rootpath?>/ckeditor/configcms.js' } );
		CKFinder.SetupCKEditor( editor, '<?=$rootpath?>/ckfinder/' ) ;
		</script><?php */?>
          
           <tr  >
             <td align="right">Embed Code </td>
             <td><textarea name="emdvedio" id="emdvedio" style="height:200px; width:300px;"><?=$myRows[emdvedio]?></textarea></td>
           </tr>
           <tr  >
            <td align="right"><strong> View Product  : </strong></td>
            <td><input name="productStatus" type="checkbox" class="textbox" id="articleStatus" value="1" <? if($myRows[products_status]==1){?>checked <? }?>></td>
          </tr>
                     
          <tr align="center"> 
            <td colspan="2"><input name="btnBack2" type="button" id="btnBack3" value="   &lt;&lt; Back   "  class="button1" onClick="javascript:location.href='home.php?PageURL=ManageCategory&catid=<?=$_REQUEST[catid]?>&cname=<?=$_REQUEST[catid]?>'">              <input name="btnSubmit" type="submit" id="btnSubmit" value="Update Product Now" class="button1">
           <input name="ProductID" type="hidden" id="ProductID" value="<?=$_REQUEST[ProductID]?>">           </tr>
      </table></td>
    </form>
  </tr>
</table>
 
