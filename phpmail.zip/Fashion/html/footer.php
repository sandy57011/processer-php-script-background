
<div class="container">
<div class="footer3">
<div class="row">
<div class="col-sm-3">
Secure Payment:
</div>
<div class="col-sm-9">
  <img src="images/payment.png" alt="payment method" class="img-responsive" />
</div>
</div>
</div>
</div>

<div class="footer2">
<div class="container">


<div class="row">

<div class="col-sm-3">
<h3>Customer Service</h3><ul>      	
            <li><a href="termsconditions.php"><i class="fa fa-list" aria-hidden="true"></i> Term of Use</a></li>
            <li><a href="privacypolicy.php"><i class="fa fa-sticky-note" aria-hidden="true"></i> Privacy Policy</a></li>
            <li><a href="shipping_policy.php"><i class="fa fa-truck" aria-hidden="true"></i> Shipping Policy</a></li>
            <li><a href="faq.php"><i class="fa fa-question" aria-hidden="true"></i> FAQ's</a></li>
            <li><a href="contact-us.php"><i class="fa fa-envelope-o" aria-hidden="true"></i> Contact Us</a></li>
      </ul>
</div>


<div class="col-sm-3">
<h3>Fashion Fab</h3>
      <ul>
<? //$SQL = "select * from categories where pid = 0  order by cname  ";
	$RES = mysql_query("select * from categories where pid = 0  order by cname limit 0,4") or die(mysql_error());
	while($ARR = mysql_fetch_array($RES)){
	?>    
<li><a href="detail-catid-<? echo $ARR[cid]; ?>-cname-<?=$ARR[cname]?>.html"><i class="fa fa-hand-o-right" aria-hidden="true"></i> <? echo $ARR[cname]; ?></a>
  
</li>
  <? }?>
  <li><a href="categories.php"><i class="fa fa-hand-o-right" aria-hidden="true"></i> More</a>
  
</li>
</ul>
</div>



<div class="col-sm-3">
<h3>Connect with us</h3>
<ul>
<li><a href="contact-us.php"><i class="fa fa-phone" aria-hidden="true"></i> +91-98765 43210</a></li>
<li><a href="contact-us.php"><i class="fa fa-envelope" aria-hidden="true"></i> info@fashionfab.in</a></li>
</ul>



<div class="social">
<ul>
<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
</ul>
</div>


</div>

<div class="col-sm-3">
<h3>Subscribe Newsletter</h3>
<div class="nl">
<form>
<div class="nl-field">
<input name="" type="text" placeholder="Enter your email id" />
</div>
<div class="nl-btn">
<button type="button" class="btn1"><i class="fa fa-arrow-right" aria-hidden="true"></i></button>
</div>
</form>
<div class="clear"></div>
</div>
      
<img src="images/logo2.png" alt="Fashion Fab" class="img-responsive" />
</div>

</div>

</div>

</div>

<footer>
© BodyKart.in, All Rights Reserved | Powered By: <a href="http://www.gapinfotech.com/" target="_blank">GAP Infotech</a>
</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>