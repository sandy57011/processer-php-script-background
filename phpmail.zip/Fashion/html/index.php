<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("includeshoping/functions.php");
	if($_REQUEST['command']=='add' && $_REQUEST['productid']>0)
	{
		$pid=$_REQUEST['productid'];
		addtocart($pid,1);
		header("location:shoppingcart.php");
		exit();
	}	
?>
<? include("include/config.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >
<title>Fashion Fab : </title>
<script language="javascript">
	function addtocart(pid){
		document.form1.productid.value=pid;
		document.form1.command.value='add';
		document.form1.submit();
	}
</script>

<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="megamenu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="megamenu/css/webslidemenu.css" />
<script type="text/javascript" src="megamenu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="megamenu/font-awesome/css/font-awesome.min.css" />


<link type="text/css" href="plugins/slider/css/responsive-slider.css" rel="stylesheet" />




<script src="js/footer_ad.js" type="text/javascript"></script>
<script type="text/javascript">eval(mod_pagespeed_c9fyOvayxY);</script>
<!-- footer banner starts -->
<script>function hideFooter()
{if(isNS4())
{document.layerClos.visibility="hide";}
if(isNS6())
{document.getElementById("fixme-bottom").style.visibility="hidden";}
if(isIE())
{document.getElementById("fixme-bottom").style.visibility="hidden";}}</script>



<script language="javascript" type="text/javascript">
function validate()
    { 
		//alert();
        doc =document.reuq_form;
		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		var r_name = doc.r_name.value;
		var r_email = doc.r_email.value;
		var r_mob = doc.r_mob.value;
		var r_comment = doc.r_comment.value;
        if(r_name=="")
        {
        alert('Please Enter Name');
        doc.r_name.focus();
        return false;
        }
		if(r_email=="")
        {
        alert('Please Enter Email');
        doc.r_email.focus();
        return false;
        }
		if(reg.test(r_email) == false) { 
        alert('Invalid Email Address');
        doc.r_email.value ="";
        doc.r_email.focus();
        return false;
        }
		if(r_mob=="")
        {
        alert('Please Enter Mobile Number');
        doc.r_mob.focus();
        return false;
        }
		if(isNaN(r_mob))
        {
        alert("Enter the valid Mobile Number(Like : 9566137117)");
        doc.r_mob.focus();
        return false;
        } 
		if(r_comment=="")
        {
        alert('Please Enter Message');
        doc.r_comment.focus();
        return false;
        }  
    }
</script>





</head>
<? if($_REQUEST[hdnenq]==1)
{
 
 	 $serverpath = "http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
		 $serverpath1= dirname($serverpath);
		$email=$_REQUEST[r_email];
		$name=$_REQUEST[r_name];
		$contact_no=$_REQUEST[r_mob];
		$comments=$_REQUEST[r_comment];
	 	$curTime = date("Y-m-d H:i:s");
mysql_query("insert into tbl_homeenquiry set name = '".$name."', email = '".$email."', mobile = '".$contact_no."', message = '".$comments."', msg_time = '".$curTime."' ");
		
	  $body='<table width="600" style="border:1px solid #943600; background-color:#F5F5F5" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0" cellpadding="4" cellspacing="0">
       
      <tr>
        <td height="40" colspan="2" bgcolor="#808000" style="font-family:Trebuchet MS; font-size:14px; font-weight:bold; text-transform:uppercase; text-align:center;">Enquiry  Information From Home Page</td>
      </tr>
      <tr>
        <td colspan="2">&nbsp;</td>
        </tr>
      <tr>
        <td width="51%" align="left"><strong>Name</strong></td>
        <td width="49%" align="left"><span style="float:left; width:270px;">'.$name.'</span></td>
        </tr>
      
      <tr>
        <td align="left"><strong>Email:</strong></td>
        <td align="left"><span style="float:left; width:270px;">'.$email.'</span></td>
      </tr>
      <tr>
        <td align="left"><STRONG>Phone:</STRONG></td>
        <td align="left"><span style="float:left; width:270px;">'.$contact_no.'</span></td>
      </tr>
      <tr>
        <td align="left"><STRONG><span class="txt4">Query</span>:</STRONG></td>
        <td align="left"><span style="float:left; width:270px;">'.$comments.'</span></td>
      </tr>
    </table></td>
  </tr>
</table>';  
 $to = "info@fashionfab.in";
$body;
 //exit();
		$subject = "Contact Information";
 		$headers = "MIME-Version:1.0\r\n";
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$from = "info@fashionfab.in";
		@mail($to,$subject,$body,$headers);
          header("Location:thankyou.php?msg=Successfully Send");
 }
	//$serverpath = dirname(dirname($_SERVER['HTTP_REFERER']));
?>
<body>
<form name="form1">
	<input type="hidden" name="productid" />
    <input type="hidden" name="command" />
</form>

<? include"header.php"?>




<div class="responsive-slider" data-spy="responsive-slider" data-autoplay="true">
        <div class="slides" data-group="slides">
      		<ul>
  	    		<li>
              <div class="slide-body" data-group="slide">
                <img src="plugins/slider/img/slide-1.jpg" alt="Outbond Call Center" />
                <div class="caption header" data-animate="slideAppearRightToLeft" data-delay="500" data-length="300">
                  <h2>The <span>Best Collection</span> for 2016</h2>
                  <div class="caption sub res-hide" data-animate="slideAppearLeftToRight" data-delay="800" data-length="300">New Trending Save up to 40%</div>
                </div>
              </div>
  	    		</li>
                
  	    		<li>
              <div class="slide-body" data-group="slide">
                <img src="plugins/slider/img/slide-2.jpg" alt="Inbound Call Center" />
                <div class="caption header" data-animate="slideAppearRightToLeft" data-delay="500" data-length="300">
                  <h2>Buy to Get <span>25% Off</span></h2>
                  <div class="caption sub res-hide" data-animate="slideAppearLeftToRight" data-delay="800" data-length="300">Fantastic Designer Clothes for Men</div>
                </div>
                
                
              </div>
  	    		</li>
                
  	    		<li>
              <div class="slide-body" data-group="slide">
                <img src="plugins/slider/img/slide-3.jpg" alt="Web Enabled Services" />
                <div class="caption header" data-animate="slideAppearRightToLeft" data-delay="500" data-length="300">
                  <h2>Get Up to <span>18% off</span></h2>
                  <div class="caption sub res-hide" data-animate="slideAppearLeftToRight" data-delay="800" data-length="300">Fantastic Women Cloths.</div>
                </div>
                </div>
  	    		</li>
                
                
                <li>
              <div class="slide-body" data-group="slide">
                <img src="plugins/slider/img/slide-4.jpg" alt="BPO Services" />
                <div class="caption header" data-animate="slideAppearRightToLeft" data-delay="500" data-length="300">
                  <h2>The <span>Best Collection</span> for 2016</h2>
                  <div class="caption sub res-hide" data-animate="slideAppearLeftToRight" data-delay="800" data-length="300">New Trending Save up to 40%</div>
                </div>
               
              </div>
  	    		</li>
                
                
                <li>
              <div class="slide-body" data-group="slide">
                <img src="plugins/slider/img/slide-5.jpg" alt="Digital Marketing" />
                <div class="caption header" data-animate="slideAppearRightToLeft" data-delay="500" data-length="300">
                  <h2>Buy to Get <span>25% Off</span></h2>
                  <div class="caption sub res-hide" data-animate="slideAppearLeftToRight" data-delay="800" data-length="300">Fantastic Designer Clothes for Men</div>
                </div>
              </div>
  	    		</li>
                
                
                <li>
              <div class="slide-body" data-group="slide">
                <img src="plugins/slider/img/slide-6.jpg" alt="Web Designing" />
                <div class="caption header" data-animate="slideAppearRightToLeft" data-delay="500" data-length="300">
                  <h2>The <span>Best Collection</span> for 2016</h2>
                  <div class="caption sub res-hide" data-animate="slideAppearLeftToRight" data-delay="800" data-length="300">New Trending Save up to 40%</div>
                </div>
                
                
              </div>
  	    		</li>
  	    	</ul>
        </div>
        <div class="pages">
          <a class="page" href="#" data-jump-to="1">1</a>
          <a class="page" href="#" data-jump-to="2">2</a>
          <a class="page" href="#" data-jump-to="3">3</a>
          <a class="page" href="#" data-jump-to="4">4</a>
          <a class="page" href="#" data-jump-to="5">5</a>
          <a class="page" href="#" data-jump-to="6">6</a>
        </div>
    	</div>








<div class="container">
<div class="content">

<h1><span>Welcome to the world of Fashion Fab</span></h1>
<h6 class="text-center">Filtering the latest trends, prospects never seem to end when you are shopping with us.</h6>
<h2><span>Freedom Fashion Sale</span></h2>
<div class="banner-ad">
<div class="row">
<div class="col-md-6">
  <img src="glarge_media/ad1.jpg" alt="ad" class="img-responsive" />
</div>

<div class="col-md-6">
  <img src="glarge_media/ad2.jpg" alt="ad" class="img-responsive" />
</div>

<div class="col-md-12">&nbsp;</div>
<div class="col-md-12">
  <img src="glarge_media/ad3.jpg" alt="ad" class="img-responsive" />
</div>
</div>
</div>




<? include"brand.php"?>

<?php include "indexproduct.php"; ?>


<h2><span>Overview Fashion Fab</span></h1>
<?
$contan=mysql_fetch_array(mysql_query("select * from contents where id='18'"));
echo $contan[contents];
?>



</div>
</div>




  
<div class="main">

<div class="page_content">

<div align="justify">
     </div>
</div>

</div>

<? include"footer.php"?>
</body>
</html>


<script src="plugins/slider/js/jquery.js"></script>
<script src="plugins/slider/js/jquery.event.move.js"></script>
<script src="plugins/slider/js/responsive-slider.js"></script>