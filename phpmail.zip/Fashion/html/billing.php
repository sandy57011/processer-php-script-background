<?
include("include/connect.php");
include("includeshoping/functions.php");
	
	if($_REQUEST['btn']=='Place Order'){
	
if($_SESSION[MemId]=="") {
	mysql_query("insert into customers set ins = ''") or die(mysql_error());
	$sescustid = mysql_insert_id();
	$_SESSION[MemId] = $sescustid;
	
	mysql_query("insert into orders set memid = '".$_SESSION[MemId]."', orderid = '".$_SESSION["shoporderid"]."', se_brow_id = '".$br_s_id."', billing_cust_email = '".$_REQUEST['email']."', delivery_cust_name = '".$_REQUEST[Nname]."', delivery_cust_address = '".$_REQUEST['Naddress1']."', delivery_cust_city = '".$_REQUEST['Ncity']."', delivery_cust_state = '".$_REQUEST['NState']."', delivery_cust_zip = '".$_REQUEST['NZipcode']."', delivery_cust_country = '".$_REQUEST['NCountry']."', delivery_cust_tel = '".$_REQUEST['NPhone1']."', billing_cust_name = '".$_REQUEST[Bname]."', billing_cust_address = '".$_REQUEST[Baddress1]."', billing_cust_city = '".$_REQUEST[Bcity]."', billing_cust_state = '".$_REQUEST[BState]."', billing_zip = '".$_REQUEST[Bzipcode]."', billing_cust_country = '".$_REQUEST[Bcountry]."', billing_cust_tel = '".$_REQUEST[BPhone1]."'") or die(mysql_error());
}
else {
	mysql_query("update orders set se_brow_id = '".$br_s_id."', billing_cust_email = '".$_REQUEST['email']."', delivery_cust_name = '".$_REQUEST[Nname]."', delivery_cust_address = '".$_REQUEST['Naddress1']."', delivery_cust_city = '".$_REQUEST['Ncity']."', delivery_cust_state = '".$_REQUEST['NState']."', delivery_cust_zip = '".$_REQUEST['NZipcode']."', delivery_cust_country = '".$_REQUEST['NCountry']."', delivery_cust_tel = '".$_REQUEST['NPhone1']."', billing_cust_name = '".$_REQUEST[Bname]."', billing_cust_address = '".$_REQUEST[Baddress1]."', billing_cust_city = '".$_REQUEST[Bcity]."', billing_cust_state = '".$_REQUEST[BState]."', billing_zip = '".$_REQUEST[Bzipcode]."', billing_cust_country = '".$_REQUEST[Bcountry]."', billing_cust_tel = '".$_REQUEST[BPhone1]."' where memid = '".$_SESSION[MemId]."' and orderid = '".$_SESSION["shoporderid"]."'") or die(mysql_error());
}		
	//////////////////////////////////////////////////////
$Oquery = "select * from order_mem where orderid = '".$_SESSION["shoporderid"]."'";
$OResult = mysql_query($Oquery) or die(mysql_error());
$ONumber = mysql_num_rows($OResult);
 
if($ONumber==0){
$ttoal = get_order_total();
 $query="insert into order_mem (orderid, memid, date, itemprice,name,email,mobile,productinfo,lastname,address1,address2,city,state,country,zipcode,udf1,udf2,udf3,udf4,udf5,pg) values('".$_SESSION["shoporderid"]."', '".$_SESSION[MemId]."', '".time()."', '".$ttoal."','".$_REQUEST[Bname]."','".$_REQUEST[email]."','".$_REQUEST[BPhone1]."','".$_REQUEST[productinfo]."','".$_REQUEST[lastname]."','".$_REQUEST[Baddress1]."','".$_REQUEST[address2]."','".$_REQUEST[Bcity]."','".$_REQUEST[BState]."','".$_REQUEST[Bcountry]."','".$_REQUEST[Bzipcode]."','".$_REQUEST[udf1]."','".$_REQUEST[udf2]."','".$_REQUEST[udf3]."','".$_REQUEST[udf4]."','".$_REQUEST[udf5]."','".$_REQUEST[pg]."')";
 
//mysql_query("insert into orders set memid = '".$_SESSION[MemId]."', orderid = '".$_SESSION["shoporderid"]."', se_brow_id = '".$br_s_id."'") or die(mysql_error());
}else{
$tutotal = get_order_total();
$query="UPDATE order_mem set  date = '".time()."', memid = '".$_SESSION[MemId]."', itemprice = '".$tutotal."',name='".$_REQUEST[Bname]."',email='".$_REQUEST[email]."',mobile='".$_REQUEST[BPhone1]."',productinfo='".$_REQUEST[productinfo]."',lastname='".$_REQUEST[lastname]."',address1='".$_REQUEST[Baddress1]."',address2='".$_REQUEST[address2]."',city='".$_REQUEST[Bcity]."',state='".$_REQUEST[BState]."',country='".$_REQUEST[Bcountry]."',zipcode='".$_REQUEST[Bzipcode]."',udf1='".$_REQUEST[udf1]."',udf2='".$_REQUEST[udf2]."',udf3='".$_REQUEST[udf3]."',udf4='".$_REQUEST[udf4]."',udf5='".$_REQUEST[udf5]."',pg='".$_REQUEST[pg]."' where orderid = '".$_SESSION["shoporderid"]."'";
}
mysql_query($query) or die(mysql_error());
   header("location:PayUMoney_form.php");
}
?>



<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab : </title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />


<script type="text/javascript" src="megamenu/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="megamenu/css/webslidemenu.css" />
<script type="text/javascript" src="megamenu/js/webslidemenu.js"></script>
<link rel="stylesheet" type="text/css" href="megamenu/font-awesome/css/font-awesome.min.css" />



<script language="javascript">
	function validate(){
		var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		var f=document.form1;
		if(f.name.value==''){
			alert('Your name is required');
			f.name.focus();
			return false;
		}
		if(f.phone.value==''){
			alert('Mobile is required');
			f.phone.focus();
			return false;
		}
		if(isNaN(f.phone.value))
        {
        alert("Enter the valid Mobile Number(Like : 9566137117)");
        f.phone.focus();
        return false;
        } 
		if(f.email.value==''){
			alert('Email is required');
			f.email.focus();
			return false;
		}
		if(reg.test(f.email.value) == false) { 
        alert('Invalid Email Address');
        f.email.value ="";
        f.email.focus();
        return false;
        }
		if(f.address.value==''){
			alert('Address is required');
			f.address.focus();
			return false;
		}
		if(f.scity.value==''){
			alert('City is required');
			f.scity.focus();
			return false;
		}
		if(f.sstate.value==''){
			alert('State is required');
			f.sstate.focus();
			return false;
		}
		if(f.szipcode.value==''){
			alert('Zip Code is required');
			f.szipcode.focus();
			return false;
		}
		if(f.captcha.value==''){
			alert('Captcha Code required');
			f.captcha.focus();
			return false;
		}
		
		f.command.value='update';
		f.submit();
	}
</script>


</head>

<body>
<?
$Oquery = "select * from order_mem where orderid = '".$_SESSION["shoporderid"]."'";
$OResult = mysql_query($Oquery) or die(mysql_error());
$OArray = mysql_fetch_array($OResult);
?>

<? include"header.php"?>
<div class="inner-banner ib-s">
<div><a href="index.php">Home</a> &raquo; Billing</div>
</div>


<div class="container">
<div class="content">
<h1><span>Billing Info</span></h1>


<form action="" method="post" enctype="multipart/form-data" name="order_account" onSubmit="return Chck_Order()" style="margin:auto; height:auto"> 
<table width="100%" border="0" cellspacing="0" cellpadding="0">  
  <tr>
    
<!--<form name="form1" method="post" onsubmit="return validate()">--> 
   
    <td valign="top" class="content"> 
      
    <input type="hidden" name="command" />
	<div>
        
        
        <div class="txt8"><?php if($_REQUEST['er']==1) { echo "Not A Valid Code"; } ?></div>
        <div class="page_content">

<table width="100%" border="0" cellspacing="0" cellpadding="0">

  

  <tr>

    <td class="content" style="padding:0"> 
     <!--<form action="" method="post" enctype="multipart/form-data" name="order_account" onSubmit="return Chck_Order()" style="margin:auto; height:auto"> -->
       <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="34%" align="left" valign="top">	 
      <table width="100%" border="0" cellpadding="0"  cellspacing="10">
        <tr>
          <td><h3>Shipping Address</h3></td>
        </tr>
        <tr>
          
          <td align="left"><input name="email" type="text" class="txtfield-f" id="email" value="<?php echo (empty($OArray['email'])) ? '' : $OArray['email']; ?>" placeholder="Email ID" /></td>
          
        </tr>
        <tr>
          <td width="252" align="left"><input name="Nname" type="text" class="txtfield-f" id="Nname" value="<?php echo (empty($OArray['name'])) ? '' : $OArray['name']; ?>" placeholder="Full Name" />        </td>
        </tr>
        <tr>
          <td align="left"><textarea name="Naddress1" placeholder="Enter Your Address" cols="14" rows="2" class="txtarea_f"><?php echo (empty($OArray['address1'])) ? '' : $OArray['address1']; ?></textarea></td>
          
        </tr>
        <tr>
          <td align="left"><input name="Ncity" type="text" class="txtfield-f" id="Ncity" placeholder="City" value="<?php echo (empty($OArray['city'])) ? '' : $OArray['city']; ?>"/></td>
        </tr>
        <tr>
          <td align="left"><input name="NState" type="text" class="txtfield-f" id="NState" placeholder="State" value="<?php echo (empty($OArray['state'])) ? '' : $OArray['state']; ?>" /></td>
        </tr>
        <tr>
          <td align="left"><input name="NZipcode" type="text" class="txtfield-f" id="NZipcode" placeholder="Zipcode" value="<?php echo (empty($OArray['zipcode'])) ? '' : $OArray['zipcode']; ?>"/></td>
        </tr>
        <tr>
          <td align="left">
            <?php /*?><select name="NCountry" class="w194" id="NCountry">
 	  <?
 	  	$CountrySql = mysql_query("select * from countrylist where id=97") or die(mysql_error());
		while($CountryArr = mysql_fetch_array($CountrySql)){
	?>

        <option value="<?=$CountryArr[id]?>" <? if($countryid==$CountryArr[id]){ echo "selected"; }?>><?=$CountryArr[cname]?></option>

		<? }?>
         </select><?php */?>
            <select name="NCountry" id="NCountry">
              <option value="India">India</option>
              </select>
            </td>
        </tr>
        
        <tr>
          
          <td align="left">   <input name="NPhone1" type="text" class="txtfield-f" id="NPhone1" value="<?php echo (empty($OArray['mobile'])) ? '' : $OArray['mobile']; ?>" placeholder="Contact No." size="27"/></td>
        </tr>
        
        <tr>
          <td colspan="2"><textarea name="productinfo" placeholder="Enter Product Info" class="txtarea_f">
<?php
$max=count($_SESSION['cart']);
				for($i=0;$i<$max;$i++){
					$pid=$_SESSION['cart'][$i]['productid'];
					$pname .=",".get_product_name($pid);
					}
				$pname = substr($pname,1);
				echo $pname;	
?>                  
                  </textarea></td>
        </tr>
        </table></td>
    <td width="2%">&nbsp;</td>
    
    <td width="36%" valign="top" style="border-left:1px solid #CCCCCC; border-right:1px solid #CCCCCC; padding:0 15px;"><table width="100%" border="0" align="left" cellpadding="0" cellspacing="10">
      
      <tr>
        <td><h3>Billing Address</h3></td>
        </tr>
      <tr align="">
        <td align="right"><div>  
          
          
          <input type="button" class="btn3" onClick="Billaddress()" value="Same as shipping address" />
          
          </div></td>
      </tr>
      <tr align="">
        <td align="left"><input name="Bname" placeholder="Full Name" type="text" class="txtfield-f" id="Bname" value="<?php echo (empty($OArray['name'])) ? '' : $OArray['name']; ?>" /></td>
      </tr>
      <tr>
        <td align="left"><textarea name="Baddress1" placeholder="Address" cols="14" rows="2" class="txtarea_f"><?php echo (empty($OArray['address1'])) ? '' : $OArray['address1']; ?></textarea></td>
      </tr>
      <tr>
        <td align="left"><input name="Bcity" placeholder="City" type="text" class="txtfield-f" id="Bcity" value="<?php echo (empty($OArray['city'])) ? '' : $OArray['city']; ?>" /></td>
        
      </tr>
      <tr>
        <td align="left"><input name="BState" placeholder="State" type="text" class="txtfield-f" id="BState" value="<?php echo (empty($OArray['state'])) ? '' : $OArray['state']; ?>" /></td>
      </tr>
      <tr>
        
        <td align="left"><input name="Bzipcode" placeholder="ZIP/Postal Code*" type="text" class="txtfield-f" id="Bzipcode" value="<?php echo (empty($OArray['zipcode'])) ? '' : $OArray['zipcode']; ?>" /></td>
      </tr>
      
      <tr>
        <td align="left"> <select name="Bcountry" id="Bcountry">
          
          <?php /*?> <?
 	  	$CountrySql = mysql_query("select * from countrylist where id=97 ") or die(mysql_error());

		while($CountryArr = mysql_fetch_array($CountrySql)){
	?>
        <option value="<?=$CountryArr[id]?>" <? if($Bcountryid==$CountryArr[id]){ echo "selected"; }?>><?=$CountryArr[cname]?></option>
		<? }?>
         </select><?php */?>
          
          <option value="India">India</option>
          </select>
          
          </td>
      </tr>
      
      <tr>
        <td align="left"> <input name="BPhone1" placeholder="Contact No." type="text" class="txtfield-f" id="BPhone1" value="<?php echo (empty($OArray['mobile'])) ? '' : $OArray['mobile']; ?>" size="27" /></td>
      </tr>
      </table>
      
      </td>
    <td width="1%" valign="top">&nbsp;</td>
    
    <td width="27%" valign="top"><table width="100%" border="0" cellspacing="10" cellpadding="0">
     <tr>
        <td colspan="2" style="color:#000000;"><h3>Order Summary</h3></td>
        </tr>
      <?php 
	 $query="select * from orders where orderid='".$_SESSION["shoporderid"]."' and waitstatus !=1";
	 $result=mysql_query($query); 

		while($result_rec=mysql_fetch_array($result)){	
		$itemsid=$result_rec['itemsid'];
		$id=$result_rec['id'];							
		$quantity=$result_rec['quantity'];
 			$sqlitems ="select * from products  where products_id='".$itemsid."'";
			$itemsresult=mysql_query($sqlitems);
			$itemRows=mysql_fetch_array($itemsresult);
	  ?>
     
      <tr>
        <td style="color:#000000;"><?php echo $itemRows[product_title]; ?><br /><?php /*?><?php echo get_Sizename($result_rec[size]);?>,<?php echo get_Colorname($result_rec[color]);?><?php */?></td>
        <td align="right" style="color:#000000;"><?   echo number_format($itemRows[products_price], 0, '.', '');?></td>
        </tr>
      <? }?>
      <?php /*?> <tr  bgcolor="#CCCCCC" style="color:#000">

    <td>Discount </td>

    <td align="right"><? $orders="select * from cup_discount where se_brow_id='".$br_s_id."' and orderid='".$_SESSION["shoporderid"]."' ";

		$resorders=mysql_query($orders);

		$rsCount=mysql_fetch_array($resorders);

		  $rsCount[dis_cou];

		if($rsCount[dis_cou]!=0){ $cu_dis=$rsCount[dis_cou];} else { $cu_dis=0;} ?> <? $dicopan=totalshopping()*($cu_dis/100);
		if($dicopan!=0){ echo $cu_dis." % ";}else{ echo "-";}
		?></td>
  </tr><?php */?>
      <tr>
        <td class="txt2">&nbsp;</td>
        <td align="right">&nbsp;</td>
      </tr>
      <tr>
        
        <td class="txt2">Grand Total</td>
        <td align="right"><span class="txt8">
          <?php /*?><? 
	    $pr=number_format(totalshopping(), 0, '.', '');

		$sm=$pr+$gg2m+$tocpr-number_format($dicopan,0,'.','')-number_format($getrec[creduse],0,'.','')-$tindis;
		echo number_format($sm,0,'.',''); if($_SESSION[pp]=='doler'){ echo "&nbsp;$";}if($_SESSION[pp]=='rs')		
		?><?php */?>
          <label> Rs. 
            <?=get_order_total()?> /-
          </label>
        </span>
          <label><!--<input name="textfield" type="text" class="txtfield" id="textfield" value="" />-->
          </label>
          </td>
        </tr>
      
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;
          <!--    <input   type="submit"   value="Continue to Pay" style="width:170px; height:36px; color:#fff; font-family:'Futura Bk'; font-size:16px; margin-top:3px; margin-bottom:3px; background:#000; padding:1px 5px 5px 5px; letter-spacing:1px;" />-->
          </td>
        <td><input name="btn" type="submit" class="btn btn-success" id="btn" value="Place Order" />
          <input name="SendOrder" type="hidden" id="SendOrder" value="1"></td>
        </tr>
  </table>
      </td>
  </tr>
</table>
<!--	</form>-->
      </td>
  </tr>

</table>

</div>
	</div>
      </td>
  </tr>
</table>
</form>
</div>
</div>
<? include"footer.php"?>
</body>
</html>
 <script language="javascript">
function Billaddress()

 {
 document.order_account.Bname.value = document.order_account.Nname.value;
 document.order_account.Baddress1.value = document.order_account.Naddress1.value;
 document.order_account.Bcity.value = document.order_account.Ncity.value;
 document.order_account.BState.value = document.order_account.NState.value;
 document.order_account.Bzipcode.value = document.order_account.NZipcode.value;
  document.order_account.Bcountry.value = document.order_account.NCountry.value;
 document.order_account.BPhone1.value = document.order_account.NPhone1.value;

  }
  
  function Chck_Order()
  {
 	if(document.order_account.Nname.value=="")
	{
		alert('Please Enter name');
		document.order_account.Nname.focus();
		return false;
	}
	if(document.order_account.Naddress1.value=="")
	{
		alert('Please Enter Address');
		 document.order_account.Naddress1.focus();
		return false;
	}
	if(document.order_account.Ncity.value=="")
	{
		alert('Please Enter City');
		 document.order_account.Ncity.focus();
		return false;
	}
	if(document.order_account.NState.value=="")
	{
		alert('Please Enter State');
		 document.order_account.NState.focus();
		return false;
	}
	if(document.order_account.NZipcode.value=="")
	{
		alert('Please Enter Zipcode');
		 document.order_account.NZipcode.focus();
		return false;
	}
	if(document.order_account.NPhone1.value=="")
	{
		alert('Please Enter Phone Number');
		 document.order_account.NPhone1.focus();
		return false;
	}
 	 if(document.order_account.Bname.value=="")
	{
		alert('Please Enter name');
		document.order_account.Bname.focus();
		return false;
	}
	if(document.order_account.Baddress1.value=="")
	{
		alert('Please Enter Address');
		 document.order_account.Baddress1.focus();
		return false;
	}
	if(document.order_account.Bcity.value=="")
	{
		alert('Please Enter City');
		 document.order_account.Bcity.focus();
		return false;
	}
	if(document.order_account.BState.value=="")
	{
		alert('Please Enter State');
		 document.order_account.BState.focus();
		return false;
	}
	if(document.order_account.Bzipcode.value=="")
	{
		alert('Please Enter Zipcode');
		 document.order_account.Bzipcode.focus();
		return false;
	}

	if(document.order_account.BPhone1.value=="")
	{
		alert('Please Enter Phone Number');
		 document.order_account.BPhone1.focus();
		return false;
	}
   }

 </script>