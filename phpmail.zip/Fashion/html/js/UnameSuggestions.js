// JavaScript Document
var axmlHttp
function ChkAvailability(username){
	
	axmlHttp=aGetXmlHttpObject();
	if (axmlHttp==null)
	  {
	  alert ("Your browser does not support AJAX!");
	  return;
	  } 
	document.getElementById("Suggestions").style.visibility = 'visible';
	document.getElementById("Suggestions").style.display	= 'block';
  	document.getElementById('Suggestions').innerHTML = '<img src="images/loadingsug.jpg">';
	document.getElementById('Suggestions').innerHTML+= 'Please Wait..., We are Generating some id suggestions';
	var url="Suggestions.php";
	url=url+"?username="+username;
	url=url+"&sid="+Math.random();
	axmlHttp.onreadystatechange=stateChangeda;
	axmlHttp.open("GET",url,true);
	axmlHttp.send("UsernmaeSuggestions");
	
}

function stateChangeda() 
{ 
	 
	if (axmlHttp.readyState==4){ 
		//document.getElementById(tdid).innerHTML=xmlHttp.responseText;
		 
		if (axmlHttp.status == 200){
       		
			var response = axmlHttp.responseText;
			
			document.getElementById("Suggestions").innerHTML 		= response;

			}
		
		}

	}

 
function aGetXmlHttpObject()
{
var axmlHttp=null;
try
  {
  // Firefox, Opera 8.0+, Safari
  axmlHttp=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    axmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    axmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
return axmlHttp;
}
