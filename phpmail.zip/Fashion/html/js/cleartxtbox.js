// JavaScript Document

/* clear subscribe news letter */
function clearDefaultandCSS(el) {
if (el.defaultValue==el.value) el.value = ""
// If Dynamic Style is supported, clear the style
if (el.style) el.style.cssText = ""
}