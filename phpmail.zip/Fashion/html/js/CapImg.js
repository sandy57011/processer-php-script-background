// JavaScript Document
// JavaScript Document

var capXmlHttp;
//Function to call the url for adding a friend
function Reload(id,Req,op,tdid,mtype)
{ 

capXmlHttp=GetXmlHttpObjects();
if (capXmlHttp==null)
  {
  alert ("Your browser does not support AJAX!");
  return;
  } 

  	document.getElementById(1111).innerHTML = 'Loading Please Wait';
	var url="img.php";
	/*url=url+"?width=100";
	url=url+"&height=40";
	url=url+"&characters=5";*/
	url=url+"?sid="+Math.random();
	capXmlHttp.onreadystatechange=stateChanged;
	capXmlHttp.open("GET",url,true);
	capXmlHttp.send("sadfdsaf");
}

function stateChanged() 
{ 
	// alert(axmlHttp.readyState)
	if (capXmlHttp.readyState==4){ 
		//document.getElementById(tdid).innerHTML=axmlHttp.responseText;
		 
		if (capXmlHttp.status == 200){
       		
			var response = capXmlHttp.responseText;
			 
			document.getElementById(1111).innerHTML = response

			}
		
		}

	}

function changeText(rmsg) {
    // Detect Browser
	//alert(text);
    var IE  = (document.all) ? 1 : 0;
    var DOM = 0; 
	div2show= parseInt(1111);
	
    if (parseInt(navigator.appVersion) >=5) {DOM=1};
		
    // Grab the content from the requested "div" and show it in the "container"
    if (DOM) {
		
		var viewer = document.getElementById(div2show);
		alert(rmsg);
	 	viewer.innerHTML = rmsg;
 
	}else if(IE) {
		document.all[div2show].innerHTML = rmsg;
		 
    }
}

function GetXmlHttpObjects()
{
var xmlHttps=null;
try
  {
  // Firefox, Opera 8.0+, Safari
  xmlHttps=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    xmlHttps=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    xmlHttps=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
return xmlHttps;
}
