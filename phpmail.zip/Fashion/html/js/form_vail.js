function check_form() { 
  		if(document.create_account.firstname.value=="")
		{
			alert("Please Enter Your First Name");
			document.create_account.firstname.focus();
			return false;	
		}
		if(document.create_account.lname.value=="")
		{
			alert("Please Enter Your Last Name");
			document.create_account.lname.focus();
			return false;	
		}
		 if(document.create_account.userid.value=="")
		{
			alert("Please Enter Your Email ID");
			document.create_account.userid.focus();
			return false;	
		}
	var id=document.create_account.userid.value;
	if (id.indexOf("@")==-1 || id.indexOf(".")==-1)
	{
	alert("Please Enter Valid Email ID ");
	document.create_account.userid.focus();
	return false;
	}	

		 if(document.create_account.password.value=="")
		{
		
			alert("Please Enter Your password");
			document.create_account.password.focus();
			return false;	
		}
		if(document.create_account.password.length<6)
		{
 			alert("Please not");
			document.create_account.password.focus();
			return false;	
		}
 		 if(document.create_account.confirmation.value=="")
		{
			alert("Enter Confirmation Password.");
			document.create_account.confirmation.focus();
			return false;	
		}
		 if(document.create_account.confirmation.value!=document.create_account.password.value)
		{
			alert("The Password Confirmation must match your Password.");
			document.create_account.confirmation.value=="";
			return false;	
		}
		 if(document.create_account.hints.value=="")
		{
			alert("Enter Hits For Remember Your Password.");
			document.create_account.hints.focus();
			return false;	
		}
		 if(document.create_account.accept.checked==false)
		{
			alert("Please checked the checkbox for agree to the terms and condition of Souq El Arab.com .");
			document.create_account.hints.focus();
			return false;	
		}
   }
 
function Validate(){
 	if(document.contact_form.name.value=="")
	{
	alert('Enter Your name');
	document.contact_form.name.focus();
	return false;
	}
	
	if(document.contact_form.email.value=="")
	{
	alert('Enter email');
	document.contact_form.email.focus();
	return false;
	}
	
	if (document.contact_form.email.value.length >0) {
			i=document.contact_form.email.value.indexOf("@")
			j=document.contact_form.email.value.indexOf(".",i)
			k=document.contact_form.email.value.indexOf(",")
			kk=document.contact_form.email.value.indexOf(" ")
			jj=document.contact_form.email.value.lastIndexOf(".")+1
			len=document.contact_form.email.value.length
			if ((i>0) && (j>(1+1)) && (k==-1) && (kk==-1) && (len-jj >=2) && (len-jj<=4)) {
			}else {
			alert("Please enter valid Email address.\n" + document.contact_form.email.value + " is invalid.");
			document.contact_form.email.focus();
			return false;
			}
			}
			
 if(document.contact_form.phone.value=="")
	{
	alert('Enter Phone Number');
	document.contact_form.phone.focus();
	return false;
	}
	if (isNaN(document.contact_form.phone.value))
	{
	alert("Enter Numeric Value Only.");
	document.contact_form.phone.focus();
	return false;
	}

	}
// JavaScript Document
 
//**********************************************************************/

function reqq_Validate()
{ 
//**************************Postedby***********************/
if (document.reuq_form.r_name.value=='Enter Name')
	{
		alert("Enter Your Name");
		document.reuq_form.r_name.focus();
		return false;
	}
//**************************email***********************/
if (document.reuq_form.r_email.value=="")
	{
		alert("Enter Your Email");
		document.reuq_form.r_email.focus();
		return false;
	}	
 
 if (document.reuq_form.r_email.value.length >0) {
			i=document.reuq_form.r_email.value.indexOf("@")
			j=document.reuq_form.r_email.value.indexOf(".",i)
			k=document.reuq_form.r_email.value.indexOf(",")
			kk=document.reuq_form.r_email.value.indexOf(" ")
			jj=document.reuq_form.r_email.value.lastIndexOf(".")+1
			len=document.reuq_form.r_email.value.length
			if ((i>0) && (j>(1+1)) && (k==-1) && (kk==-1) && (len-jj >=2) && (len-jj<=4)) {
			}else {
			alert("Please enter valid Email address.\n" + document.reuq_form.r_email.value + " is invalid.");
			document.reuq_form.r_email.focus();
			return false;
			}
			}
/***************************/

if(document.reuq_form.r_mob.value=="")
	{
	alert('Enter Mobile Number');
	document.reuq_form.r_mob.focus();
	return false;
	}
if (isNaN(document.reuq_form.r_mob.value))
	{
	alert("Enter Numeric Value Only.");
	document.reuq_form.r_mob.focus();
	return false;
	}

}
/*******************order form********************/

function order_Validate()
{
/****************************************/
if (document.order_form.ord_name.value=="")
	{
		alert("Enter Your Name");
		document.order_form.ord_name.focus();
		return false;
	}
	
//**************************email***********************/
if (document.order_form.ord_email.value=="")
	{
		alert("Enter Your Email");
		document.order_form.ord_email.focus();
		return false;
	}	
 
 if (document.order_form.ord_email.value.length >0) {
			i=document.order_form.ord_email.value.indexOf("@")
			j=document.order_form.ord_email.value.indexOf(".",i)
			k=document.order_form.ord_email.value.indexOf(",")
			kk=document.order_form.ord_email.value.indexOf(" ")
			jj=document.order_form.ord_email.value.lastIndexOf(".")+1
			len=document.order_form.ord_email.value.length
			if ((i>0) && (j>(1+1)) && (k==-1) && (kk==-1) && (len-jj >=2) && (len-jj<=4)) {
			}else {
			alert("Please enter valid Email address.\n" + document.order_form.ord_email.value + " is invalid.");
			document.order_form.ord_email.focus();
			return false;
			}
			}
 if(document.order_form.ord_cont.value=="")
	{
	alert('Enter Phone Number');
	document.order_form.ord_cont.focus();
	return false;
	}
if (isNaN(document.order_form.ord_cont.value))
	{
	alert("Enter Numeric Value Only.");
	document.order_form.ord_cont.focus();
	return false;
	}
	if (document.order_form.ordert.value=="")
	{
	alert("Select Your Order");
	document.order_form.ordert.focus();
	return false;
	}
		
}
/***************************Carr***************************/
function carr_Validate()
{
/****************************************/
if (document.carr_form.carr_name.value=="")
	{
		alert("Enter Your Name");
		document.carr_form.carr_name.focus();
		return false;
	}
	/*************************/
if (document.carr_form.applied.value=="")
	{
		alert("Select applied for the post");
		document.carr_form.applied.focus();
		return false;
	}
//**************************email***********************/
if (document.carr_form.carr_email.value=="")
	{
		alert("Enter Your Email");
		document.carr_form.carr_email.focus();
		return false;
	}	
 
 if (document.carr_form.carr_email.value.length >0) {
			i=document.carr_form.carr_email.value.indexOf("@")
			j=document.carr_form.carr_email.value.indexOf(".",i)
			k=document.carr_form.carr_email.value.indexOf(",")
			kk=document.carr_form.carr_email.value.indexOf(" ")
			jj=document.carr_form.carr_email.value.lastIndexOf(".")+1
			len=document.carr_form.carr_email.value.length
			if ((i>0) && (j>(1+1)) && (k==-1) && (kk==-1) && (len-jj >=2) && (len-jj<=4)) {
			}else {
			alert("Please enter valid Email address.\n" + document.carr_form.carr_email.value + " is invalid.");
			document.carr_form.carr_email.focus();
			return false;
			}
			}

 if(document.carr_form.carr_cont.value=="")
	{
	alert('Enter Phone Number');
	document.carr_form.carr_cont.focus();
	return false;
	}
	if (isNaN(document.carr_form.carr_cont.value))
	{
	alert("Enter Numeric Value Only.");
	document.carr_form.carr_cont.focus();
	return false;
	}


var extensions = new Array("jpg","jpeg","gif","png","doc","pdf");

/*
// Alternative way to create the array

var extensions = new Array();

extensions[1] = "jpg";
extensions[0] = "jpeg";
extensions[2] = "gif";
extensions[3] = "png";
extensions[4] = "bmp";
*/

var image_file = document.carr_form.c_file.value;

var image_length = document.carr_form.c_file.value.length;

var pos = image_file.lastIndexOf('.') + 1;

var ext = image_file.substring(pos, image_length);

var final_ext = ext.toLowerCase();

for (i = 0; i < extensions.length; i++)
{
    if(extensions[i] == final_ext)
    {
    return true;
    }
}

alert("You must upload an image file with one of the following extensions: "+ extensions.join(', ') +".");
return false;
}
 
function checkfieldNewUser(validateForm)
	{
	 if (document.loginForm.txt_usernanme.value=="")
	{
	alert("Enter First Email ID");
	document.loginForm.txt_usernanme.focus();
	return false;
	}
var id=document.loginForm.txt_usernanme.value;
if (id.indexOf("@")==-1 || id.indexOf(".")==-1)
	{
	alert("Please Enter Valid Email ID ");
	document.loginForm.txt_usernanme.focus();
	return false;
	}	
	 if (document.loginForm.txt_password.value=="")
		{
			alert("Please enter password.");
			document.loginForm.txt_password.focus();
			return false;
		}						
}


 
 