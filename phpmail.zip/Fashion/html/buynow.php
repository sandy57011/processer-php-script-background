<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.png" >

<title>Fashion Fab::Shipping Policy</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />

<link href="slide/slide.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="slide/jquery-1.2.6.min.js"></script>
<script type="text/javascript">
function slideSwitch() {
    var $active = $('#slideshow IMG.active');

    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');

    // use this to pull the images in the order they appear in the markup
    var $next =  $active.next().length ? $active.next()
        : $('#slideshow IMG:first');
    $active.addClass('last-active');

    $next.css({opacity: 0.0})
        .addClass('active')
        .animate({opacity: 1.0}, 1000, function() {
            $active.removeClass('active last-active');
        });
}

$(function() {
    setInterval( "slideSwitch()", 4000 );
});
</script>
<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu.css" />
<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu-v.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="top-menu/ddsmoothmenu.js"></script>
<script type="text/javascript">
ddsmoothmenu.init({
	mainmenuid: "smoothmenu1", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
ddsmoothmenu.init({
	mainmenuid: "smoothmenu2", //Menu DIV id
	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
	//customtheme: ["#804000", "#482400"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>
<script type="text/javascript" src="js/form_vail.js"></script>
<script type="text/javascript" src="js/cleartxtbox.js"></script>
</head>
<body>
<center>
<? include"header.php"?>
<div class="main">
<div class="page_content">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td width="2%" valign="top" class="left"><? include"left.php"?></td>
  <td valign="top" class="content"> 
<h1>Buy Now </h1>

<?
$prod_id=$_REQUEST['prod_id'];
$prod_price=$_REQUEST['prod_price'];
?>
<table width="100%" border="0" cellpadding="0" cellspacing="10" class="prof-table">
    
		 
 	        <tr>
              <td align="right"><strong> Item Name</strong></td>
 	          <td class="txt8"><strong>:</strong></td>
 	          <td height="25"><? $pro=mysql_fetch_array(mysql_query("select * from products where products_id=$prod_id"));
	  echo $pro[product_title];?>              </td>
 	          </tr>
 	        <tr>
              <td align="right"><strong>Item Price</strong></td>
 	          <td class="txt8"><strong>:</strong></td>
 	          <td height="25"><?=$prod_price?>              </td>
 	          </tr>
 	        <tr>
	          <th width="18%" align="right" class="txt12"> Name<span class="alert">*</span></th>
              <td width="2%" class="txt8"><strong>:</strong></td>
              <td width="80%"><input name="name" type="text" class="txtfield" id="name"  /></td>
    </tr>
	 <tr>
	          <th width="18%" align="right" class="txt12"> E-mail Id<span class="alert">*</span></th>
              <td width="2%" class="txt8"><strong>:</strong></td>
              <td width="80%"><input name="name" type="text" class="txtfield" id="e-mail_id"  /></td>
    </tr>
	        <tr>
	          <th align="right" class="txt12">Address Line 1<span class="alert">*</span></th>
              <td class="txt8"><strong>:</strong></td>
              <td><input name="saddress1" type="text" class="txtfield" id="saddress1"  /></td>
    </tr>
	        <tr>
	          <th align="right" class="txt12">Address Line 2</th>
              <td class="txt8"><strong>:</strong></td>
              <td><input name="saddress2" type="text" class="txtfield" id="saddress2" value="" /></td>
    </tr>
	        <tr>
	          <th align="right" class="txt12">City<span class="alert">*</span></th>
              <td class="txt8"><strong>:</strong></td>
              <td>
	  <select name="scity" id="scity" class="txtfield" style="width:256px">
         <option value="" selected="selected">Select</option>
         <option value="Gurgaon">Gurgaon</option>
          <option value="Noida" > Noida</option>
         </select></td>
    </tr>
	      	        <tr>
	          <th align="right" class="txt12">ZIP/Postal Code<span class="alert">*</span></th>
              <td class="txt8"><strong>:</strong></td>
              <td><input name="szipcode" type="text" class="txtfield" id="szipcode"  ></td>
    </tr>
	        
	       
	        <tr>
	          <th align="right" class="txt12">Phone Number </th>
              <td class="txt8"><strong>:</strong></td>
              <td><input name="std2" type="text" class="txtfield" id="std2"  />                </td>
    </tr>
	 <tr>
	          <th align="right" class="txt12">Phone Number </th>
              <td class="txt8"><strong>:</strong></td>
              <td><input type="submit" class="btn3" value="Submit" accept="Submit" />                </td>
    </tr>
  </table></td>
  </tr>
</table>
</div>
</div>
<? include"footer.php"?>
</center>
</body>
</html>