<? include("include/connect.php");?>
<? include("include/function.php");?>
<? include("include/config.php");?>
<? if($_SESSION[MemId]==""){header("Location:index.php"); }?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Smartbuyz.co.in: Online Toys & Gift Store</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<LINK REV="made" href="mailto:info@smartbuyz.co.in">
<META NAME="description" CONTENT="Welcome to Smartbuyz.co.in ,Search. Author, Book, ISBN, Price.  "/>
<META NAME="keywords" CONTENT="Smartbuyz.co.in, earch. Author, Book, ISBN, Price./">
<META NAME="ROBOTS" CONTENT="ALL">
<link href="css/style.css" rel="stylesheet" type="text/css" />  

</head>

<body>
<center>
<? include("top.php") ?>
<div class="main">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top" class="left"><? include("left.php") ?></td>
      <td valign="top" class="content"> 
      <div class="nav2">
      <div>
      <h2>Logged off</h2>
      </div>
      </div>
               <div class="box2">
                      
You have been logged off your account. It is now safe to leave the computer.
 If you had items in your cart, they have been saved. The items inside it will be restored when you log back into your account.</div>
<?
	$_SESSION[MemId] = "";
	$_SESSION[name] = "";
	$_SESSION[lastname] = "";
	$_SESSION[email] = "";
	$_SESSION[shop] = "";
	$_SESSION[shipaddress] = "";
	$_SESSION[shoporderid] = "";
	$_SESSION[BillAddr] = "";
//unset($_SESSION[MemId]);
//unset($_SESSION[email]);
//session_destroy();
//header("Location:index.php");
 ?>
 <meta http-equiv=refresh content="2; URL=index.php">      </td>
      </tr>
  </table>
</div>


<? include("footer.php") ?>
</center>
</body>

</html>