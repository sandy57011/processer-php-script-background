<? include("include/connect.php");

include("include/function.php");

require('setvalue.php');

?>

<?php

// Merchant key here as provided by Payu

$MERCHANT_KEY = "P226s4";



// Merchant Salt as provided by Payu

$SALT = "xyO3tAF1";



// End point - change to https://secure.payu.in for LIVE mode //https://test.payu.in

$PAYU_BASE_URL = "https://secure.payu.in";



$action = '';



$posted = array();

if(!empty($_POST)) {

    //print_r($_POST);

  foreach($_POST as $key => $value) {    

    $posted[$key] = $value; 

	

  }

}



$formError = 0;



if(empty($posted['txnid'])) {

  // Generate random transaction id

  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);

} else {

  $txnid = $posted['txnid'];

}

$hash = '';

// Hash Sequence

$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";

if(empty($posted['hash'])> 0) {

  if(

          empty($posted['key'])

          || empty($posted['txnid'])

          || empty($posted['amount'])

          || empty($posted['firstname'])

          || empty($posted['email'])

          || empty($posted['phone'])

          || empty($posted['productinfo'])

          || empty($posted['surl'])

          || empty($posted['furl'])

		  || empty($posted['service_provider'])

  ) {

    $formError = 1;

  } else {

    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));

	$hashVarsSeq = explode('|', $hashSequence);

    $hash_string = '';	

	foreach($hashVarsSeq as $hash_var) {

      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';

      $hash_string .= '|';

    }



    $hash_string .= $SALT;





    $hash = strtolower(hash('sha512', $hash_string));

    $action = $PAYU_BASE_URL . '/_payment';

  }

} elseif(!empty($posted['hash'])) {

  $hash = $posted['hash'];

  $action = $PAYU_BASE_URL . '/_payment';

}

?>

 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />





<title>Fashion Fab : </title>

<link href="css/style.css" rel="stylesheet" type="text/css" />



<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu.css" />

<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu-v.css" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

<script type="text/javascript" src="top-menu/ddsmoothmenu.js"></script>

  <script>

    var hash = '<?php echo $hash ?>';

    function submitPayuForm() {

      if(hash == '') {

        return;

      }

      var payuForm = document.forms.payuForm;

      payuForm.submit();

    }

  </script>

<script type="text/javascript">



ddsmoothmenu.init({

	mainmenuid: "smoothmenu1", //menu DIV id

	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"

	classname: 'ddsmoothmenu', //class added to menu's outer DIV

	//customtheme: ["#1c5a80", "#18374a"],

	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]

})



ddsmoothmenu.init({

	mainmenuid: "smoothmenu2", //Menu DIV id

	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"

	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV

	//customtheme: ["#804000", "#482400"],

	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]

})



</script>

 



</head>



<body onLoad="submitPayuForm()">

<center>

<div class="main">

<? include"header.php"?>





<div class="page_content">



<table width="100%" border="0" cellspacing="0" cellpadding="0">



     <tr>



    <td width="65%" align="center" valign="top" style="padding-left:20px;">

<?

$Oquery = "select * from order_mem where orderid = '".$_SESSION["shoporderid"]."'";

$OResult = mysql_query($Oquery) or die(mysql_error());

$OArray = mysql_fetch_array($OResult);

?>   

<div align="left">
<?php /*?><a href="pa_ by_cash_on_deliver.php" style="text-decoration:none">
<input name="placeorder2" type="submit"    style="color:#fff;  font-size:16px; margin-top:3px; margin-bottom:3px; background:#000; letter-spacing:1px; font-family:'Futura Bk'; letter-spacing:1px; padding:8px;" id="placeorder" value="Pay by Cash On Delivery" /></a><?php */?><br /><br>


<form action="<?php echo $action; ?>" method="post" name="payuForm">

<input type="hidden" name="productinfo" value="BodyKart.in product" />

<input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />

<input type="hidden" name="hash" value="<?php echo $hash ?>"/>

<input type="hidden" name="txnid" value="<?php echo $txnid ?>" />

<input  type="hidden" name="amount" value="<?php echo $OArray['itemprice'];?>" />

<input  type="hidden" name="firstname" id="firstname" value="<?php echo $OArray['name'];?>" />

<input  type="hidden" name="email" id="email" value="<?php echo $OArray['email'];?>" />

<input  type="hidden" name="phone" value="<?php echo $OArray['phone'];?>" />

<input  type="hidden" name="surl" value="http://www.BodyKart.in/paysuccess.php"   /> 

<input  type="hidden" name="furl" value="http://www.BodyKart.in/fail.php"   />

<input   type="hidden" name="service_provider" value="payu_paisa"  />

<input type="hidden" name="curl" value="http://www.BodyKart.in/fail.php" />

<input type="hidden" name="address1" value="<?php echo $ShArr[address1]; ?>" />

<input type="hidden" name="address2" value="<?php echo $ShArr[address1]; ?>" />

<input name="city" type="hidden" value="<?php echo $ShArr[city]; ?>" />

<input name="state" type="hidden" value="<?php echo $ShArr[state]; ?>" />  

<input name="country" type="hidden" value="India" /> 

<input name="zipcode" type="hidden" value="<?php echo $ShArr[zipcode]; ?>" />

<?php if(!$hash) { ?>

  <input name="placeorder2" type="submit"    style="color:#fff;  font-size:16px; margin-top:3px; margin-bottom:3px; background:#000; letter-spacing:1px; font-family:'Futura Bk'; letter-spacing:1px; padding:8px;" id="placeorder" value="Pay by Debit Card / Credit Card /Net Banking" />

<?php }else{ echo "Page redirect Please Wait";} ?>

</form> </div>







<table width="100%"  border="0" cellspacing="0" cellpadding="0">



   



	  <?



	 $countproduct="SELECT COUNT( quantity ) as c FROM orders WHERE orderid = '".$_SESSION["shoporderid"]."' AND waitstatus !=1";



	 $result2=mysql_query($countproduct); 



	 



	 $result_rec2=mysql_fetch_array($result2);



	   



		  $query="select * from orders where orderid='".$_SESSION["shoporderid"]."' and waitstatus !=1";



		$result=mysql_query($query); 



		while($result_rec=mysql_fetch_array($result)){	



		$itemsid=$result_rec["itemsid"];



		$id=$result_rec["id"];							



		$quantity=$result_rec["quantity"];



 			$sqlitems ="select * from products  where products_id=".$itemsid."";



			$itemsresult=mysql_query($sqlitems);



			$itemRows=mysql_fetch_array($itemsresult);



	  ?>



     



      



	  <? }?>



    </table>



    </td>



    <td width="6%" style="border-left:1px solid #CCCCCC;">&nbsp;</td>



    <td width="29%" valign="top">



    <table width="100%" border="0" cellspacing="0" cellpadding="0">



  <tr>



    <td>



    <table width="290"  border="0" align="left" cellpadding="5" cellspacing="5" style="font-family:'Futura Bk'; color:#000000; font-style:normal; font-size:12px; margin-top:18px;"  >



       <tr bgcolor="#CCCCCC">



    <td align="center" colspan="2"  style="font-family:'Futura Bk'; color:#000000; font-style:normal; font-size:16px">Order Summary</td>



  </tr> <?



	 $countproduct="SELECT COUNT( quantity ) as c FROM orders WHERE orderid = '".$_SESSION["shoporderid"]."' AND waitstatus !=1";



	 $result2=mysql_query($countproduct); 



	 $result_rec2=mysql_fetch_array($result2);



	   



		  $query="select * from orders where orderid='".$_SESSION["shoporderid"]."' and waitstatus !=1";



		$result=mysql_query($query); 



		while($result_rec=mysql_fetch_array($result)){	



		$itemsid=$result_rec["itemsid"];



		$id=$result_rec["id"];							



		$quantity=$result_rec["quantity"];



 			$sqlitems ="select * from products  where products_id=".$itemsid."";



			$itemsresult=mysql_query($sqlitems);



			$itemRows=mysql_fetch_array($itemsresult);



	  ?>



      <tr>



    <td style="color:#000000"><?=$itemRows[product_title]?></td>



    <td style="color:#000;">  <?   echo number_format($itemRows[products_price], 0, '.', ''); ?></td>



  </tr>



   <? } $orders="select * from cup_discount where se_brow_id='".$br_s_id."'";







		$resorders=mysql_query($orders);







		$rsCount=mysql_fetch_array($resorders);







		  $rsCount[dis_cou];?>



  <tr  bgcolor="#CCCCCC">



    <td style="color:#000000;">Discount </td>



    <td style="color:#000;"><? 







		if($rsCount[dis_cou]!=0){ $cu_dis=$rsCount[dis_cou];} else { $cu_dis=0;} ?><? $dicopan=totalshopping()*($cu_dis/100);



		if($dicopan!=0){ echo $cu_dis." % ";}else{ echo "-";}



		?></td>



  </tr>



  <tr  bgcolor="#cccccc" style="font-size:14px; color:#000;">



    <td>Grand Total</td>



    <td><? 



		 



	    $pr=number_format(totalshopping(), 0, '.', '');



  	    



		$sm=$pr+$gg2m+$tocpr-number_format($dicopan,0,'.','')-number_format($getrec[creduse],0,'.','')-$tindis;



		echo number_format($sm,0,'.',''); if($_SESSION[pp]=='doler'){ echo "&nbsp;$";}if($_SESSION[pp]=='rs')		



		?></td>



  </tr>







  </table></td>



  </tr>



  <tr>



    <td ><table width="281" border="0" align="left" cellpadding="0" cellspacing="0" style="font-family:'Futura Bk'; color:#000000; font-style:normal; font-size:12px; margin-left:5px; " >



  <tr >



    <td width="141" colspan="2" align="center"  style="font-size:16px; color:#000; font-style:normal; padding:9px"  bgcolor="#CCCCCC">Shipping Details</td>



  </tr>



  <tr>



    <td colspan="2" align="left"> <?



		$query = "select * from shipping_tbl where se_brow_id='".$br_s_id."' and orderid='".$_SESSION["shoporderid"]."'";



		$res = mysql_query($query) or die(mysql_error());



		$Arr = mysql_fetch_array($res);



		?>



		 



<?=$Arr[name]?>



          </p>



          <p>



            <?=$Arr[address1]?> 



              </p>



          <p>



            <?=$Arr[city]?>  <?=$Arr[state]?>



            <br /> 



              <?=$Arr[zipcode]?>



            <br />



              <?=findcountry($Arr[country])?>



           <? if($Arr[phone1]!='') {?> 



            <br />



          



            <?=$Arr[std1]?>



            



            <?=$Arr[phone1]?> 



            <br />



             <? } if($Arr[phone2]!='') {?> 



            



            <?=$Arr[std2]?>



            



            <?=$Arr[phone2]?>



            <? }?> 		



          </p></td>



  </tr>



</table></td>



  </tr>



  



</table>



 </td>



  </tr>



</table>

</div>

</div>

<? include"footer.php"?>

</center>

</body>

</html>