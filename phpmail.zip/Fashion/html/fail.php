<? include("include/connect.php");?>

<? include("include/function.php");?>

<? include("include/config.php");?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />





<title>Payment not accepted</title>

<meta name="description" content="payment not accepted by the service" />

<meta name="keywords" content="online shopping, shop for suppliment, online mass gainer products" />

<link href="css/style.css" rel="stylesheet" type="text/css" />



<link href="slide/slide.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="slide/jquery-1.2.6.min.js"></script>

<script type="text/javascript">

function slideSwitch() {

    var $active = $('#slideshow IMG.active');



    if ( $active.length == 0 ) $active = $('#slideshow IMG:last');



    // use this to pull the images in the order they appear in the markup

    var $next =  $active.next().length ? $active.next()

        : $('#slideshow IMG:first');

    $active.addClass('last-active');



    $next.css({opacity: 0.0})

        .addClass('active')

        .animate({opacity: 1.0}, 1000, function() {

            $active.removeClass('active last-active');

        });

}



$(function() {

    setInterval( "slideSwitch()", 4000 );

});

</script>





<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu.css" />

<link rel="stylesheet" type="text/css" href="top-menu/ddsmoothmenu-v.css" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>

<script type="text/javascript" src="top-menu/ddsmoothmenu.js"></script>



<script type="text/javascript">



ddsmoothmenu.init({

	mainmenuid: "smoothmenu1", //menu DIV id

	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"

	classname: 'ddsmoothmenu', //class added to menu's outer DIV

	//customtheme: ["#1c5a80", "#18374a"],

	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]

})



ddsmoothmenu.init({

	mainmenuid: "smoothmenu2", //Menu DIV id

	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"

	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV

	//customtheme: ["#804000", "#482400"],

	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]

})



</script>



<script type="text/javascript" src="js/form_vail.js"></script>

<script type="text/javascript" src="js/cleartxtbox.js"></script>





</head>



<body>

<center>

<div class="main">

<? include"header.php"?>





<div class="page_content">

<table width="100%" border="0" cellspacing="0" cellpadding="0">

  

  <tr>

    <td class="content" style="padding:0"> 

    Payment Not Accepted...

      <p>&nbsp;</p></td>

  </tr>

  <tr>

    <td>&nbsp;</td>

  </tr>

</table>

</div>









</div>



<? include"footer.php"?>

</center>

</body>

</html>

