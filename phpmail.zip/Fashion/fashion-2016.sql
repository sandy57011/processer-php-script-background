-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 23, 2016 at 09:44 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fashion-2016`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_banner`
--

CREATE TABLE IF NOT EXISTS `ad_banner` (
  `adid` int(11) NOT NULL auto_increment,
  `adtype` varchar(50) NOT NULL default '',
  `adfilevalue` text NOT NULL,
  `adposition` varchar(15) NOT NULL default '',
  `adstartdate` int(11) NOT NULL default '0',
  `ad_no_of_days` int(11) NOT NULL default '0',
  `ad_end_date` int(11) NOT NULL default '0',
  `adstatus` binary(1) NOT NULL default '\0',
  `adpayconfirm` binary(1) NOT NULL default '\0',
  `bannerurl` text NOT NULL,
  `clicks` int(200) NOT NULL default '0',
  `impression` int(200) NOT NULL default '0',
  PRIMARY KEY  (`adid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ad_banner`
--


-- --------------------------------------------------------

--
-- Table structure for table `bestseller_payment`
--

CREATE TABLE IF NOT EXISTS `bestseller_payment` (
  `id` int(11) NOT NULL auto_increment,
  `itemid` int(11) NOT NULL default '0',
  `paymentid` int(100) NOT NULL default '0',
  `amount` float NOT NULL default '0',
  `todate` bigint(20) NOT NULL default '0',
  `enddate` bigint(20) NOT NULL default '0',
  `status` binary(1) NOT NULL default '\0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bestseller_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `billingaddress_tbl`
--

CREATE TABLE IF NOT EXISTS `billingaddress_tbl` (
  `id` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `address1` varchar(255) NOT NULL default '',
  `address2` varchar(255) NOT NULL default '',
  `city` varchar(255) NOT NULL default '',
  `state` varchar(255) NOT NULL default '',
  `zipcode` varchar(20) NOT NULL default '',
  `country` int(20) NOT NULL default '0',
  `std1` int(10) NOT NULL default '0',
  `phone1` int(20) NOT NULL default '0',
  `std2` int(10) NOT NULL default '0',
  `phone2` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `billingaddress_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `cid` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `b_image` varchar(255) NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`cid`, `name`, `b_image`) VALUES
(20, 'life style', '12755312701.jpg'),
(22, 'john Players', '5825946922.jpg'),
(30, 'Puma', '18563998833.jpg'),
(31, 'Wrangler', '17112628474.jpg'),
(54, 'Lee', '1484058905.jpg'),
(53, 'Roggers Young', '10473532626.jpg'),
(42, 'Pepe jeans', '19907107777.jpg'),
(43, 'Jack Jones', '21208999548.jpg'),
(44, 'Indigo nation', '17461836509.jpg'),
(45, 'Numero uno', '38515288510.jpg'),
(46, 'Indian Terrain', '103227055511.jpg'),
(47, 'Red Tape', '39819313312.jpg'),
(48, 'Excalibur', '178200411213.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `cid` int(11) NOT NULL auto_increment,
  `orderby` int(100) NOT NULL,
  `cname` varchar(255) NOT NULL default '',
  `pid` int(11) NOT NULL default '0',
  `Childs` text NOT NULL,
  `LevelFromRoot` int(11) NOT NULL default '0',
  `hidestatus` binary(1) NOT NULL default '0',
  `categories_image` varchar(255) NOT NULL default '',
  `date_added` bigint(20) NOT NULL default '0',
  `last_modify` bigint(20) NOT NULL default '0',
  `aveg_rating` int(11) NOT NULL default '0',
  `mcid` varchar(255) NOT NULL,
  `home_page` int(2) NOT NULL default '0',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=247 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `orderby`, `cname`, `pid`, `Childs`, `LevelFromRoot`, `hidestatus`, `categories_image`, `date_added`, `last_modify`, `aveg_rating`, `mcid`, `home_page`) VALUES
(246, 0, 'Top', 239, '', 1, '0', '', 0, 0, 0, '', 0),
(244, 0, 'Watches', 0, '', 0, '0', '', 0, 0, 0, '', 0),
(211, 0, 'Kids Wear', 0, '', 0, '0', '', 0, 0, 0, '', 0),
(210, 0, 'Mens Wear', 0, '245,', 0, '0', '', 0, 0, 0, '', 1),
(245, 0, 'T-shirt', 210, '', 1, '0', '', 0, 0, 0, '', 0),
(236, 0, 'Infant Wear', 0, '', 0, '0', '', 0, 0, 0, '', 0),
(243, 0, 'Sunglasses', 0, '', 0, '0', '', 0, 0, 0, '', 0),
(239, 0, 'Women Wear', 0, '246,', 0, '0', '', 0, 0, 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `catrating`
--

CREATE TABLE IF NOT EXISTS `catrating` (
  `id` int(11) NOT NULL auto_increment,
  `mid` int(11) NOT NULL default '0',
  `phid` int(11) NOT NULL default '0',
  `points` float NOT NULL default '0',
  `adddate` bigint(20) NOT NULL default '0',
  `ipaddress` varchar(255) NOT NULL default '',
  `itemtype` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `catrating`
--


-- --------------------------------------------------------

--
-- Table structure for table `comment_tbl`
--

CREATE TABLE IF NOT EXISTS `comment_tbl` (
  `id` int(11) NOT NULL auto_increment,
  `itid` int(11) NOT NULL default '0',
  `date_added` bigint(20) NOT NULL default '0',
  `postedby` int(11) NOT NULL default '0',
  `comment` text NOT NULL,
  `status` binary(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comment_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `contactusid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `phone` varchar(100) NOT NULL default '0',
  `fax` int(11) NOT NULL default '0',
  `email` varchar(255) NOT NULL default '',
  `msg` text NOT NULL,
  `status` char(1) character set latin1 collate latin1_bin NOT NULL default '0',
  `datetime` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`contactusid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `contact`
--


-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL auto_increment,
  `cont_title` varchar(255) NOT NULL default '',
  `contents` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `cont_title`, `contents`) VALUES
(1, 'aboutus', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>'),
(6, 'privacy', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>'),
(18, 'Home', '<p>\r\n	This is only for dummy original text comes here Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	This is only for dummy original text comes here Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n'),
(4, 'Terms to use', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>'),
(12, 'ShippingPolicy', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>'),
(2, 'FAQ', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>'),
(14, 'Contact us', '<h3>\r\n	Fashion FAB</h3>\r\n<p>\r\n	#</p>\r\n<h3>\r\n	Email:</h3>\r\n<p>\r\n	info@fashionfab.in</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	Call:</h3>\r\n<p>\r\n	+91-98765 43210</p>\r\n'),
(3, 'Reach us Footer', '<p>\r\n	<strong>Mobile:</strong> +91-98765 43210<br />\r\n	<strong>Email: </strong>info@fashionfab.in</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `contents2`
--

CREATE TABLE IF NOT EXISTS `contents2` (
  `id` int(11) NOT NULL auto_increment,
  `cont_title` varchar(255) NOT NULL default '',
  `contents` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contents2`
--

INSERT INTO `contents2` (`id`, `cont_title`, `contents`) VALUES
(1, 'Free Shipping', 'Free Shipping'),
(2, '5-6 working days ', '5-6 working days '),
(3, 'text3', 'text3'),
(4, 'text4', 'text4');

-- --------------------------------------------------------

--
-- Table structure for table `countrylist`
--

CREATE TABLE IF NOT EXISTS `countrylist` (
  `id` int(11) NOT NULL auto_increment,
  `cname` varchar(255) NOT NULL default '',
  `code` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=236 ;

--
-- Dumping data for table `countrylist`
--

INSERT INTO `countrylist` (`id`, `cname`, `code`) VALUES
(1, 'Afganistan', ''),
(2, 'Albania', ''),
(3, 'Algeria', ''),
(4, 'American Samoa', ''),
(5, 'Andorra', ''),
(6, 'Angola', ''),
(7, 'Anguila', ''),
(8, 'Antarctica', ''),
(9, 'Antigua and Barbuda', ''),
(10, 'Argentina', ''),
(11, 'Armenia', ''),
(12, 'Aruba', ''),
(13, 'Australia', ''),
(14, 'Austria', ''),
(15, 'Azerjaijan', ''),
(16, 'Bahamas', ''),
(17, 'Bahrain', ''),
(18, 'Bangladesh', ''),
(19, 'Barbados', ''),
(20, 'Belarus', ''),
(21, 'Belguim', ''),
(22, 'Belize', ''),
(23, 'Benin', ''),
(24, 'Bermuda', ''),
(25, 'Bhutan', ''),
(26, 'Bolivia', ''),
(27, 'Bosnia and Herzegovina', ''),
(28, 'Botswana', ''),
(29, 'Bouvet Island', ''),
(30, 'Brazil', ''),
(31, 'British Indian Ocean territory', ''),
(32, 'Brunei Darussalam', ''),
(33, 'Bulgaria', ''),
(34, 'Burkina Faso', ''),
(35, 'Burundi', ''),
(36, 'Cambodia', ''),
(37, 'Cameroon', ''),
(38, 'Canada', ''),
(39, 'Cape Verde', ''),
(40, 'Cayman Islands', ''),
(41, 'Central African Republic', ''),
(42, 'Chad', ''),
(43, 'Chile', ''),
(44, 'China', ''),
(45, 'Christmas Island', ''),
(46, 'Cocos (Keeling) Islands', ''),
(47, 'Colombia', ''),
(48, 'Comoros', ''),
(49, 'Congo', ''),
(50, 'Cook Islands', ''),
(51, 'Costa Rica', ''),
(52, 'Cote d''Ivoire (Ivory Coast)', ''),
(53, 'Croatia (Hrvatska)', ''),
(54, 'Cuba', ''),
(55, 'Cyprus', ''),
(56, 'Czech Republic', ''),
(57, 'Denmark', ''),
(58, 'Djibouti', ''),
(59, 'Dominica', ''),
(60, 'Dominican Republic', ''),
(61, 'East Timor', ''),
(62, 'Ecuador', ''),
(63, 'Egypt', ''),
(64, 'El Salvador', ''),
(65, 'Equatorial Guinea', ''),
(66, 'Eritrea', ''),
(67, 'Estonia', ''),
(68, 'Ethiopia', ''),
(69, 'Falkland Islands', ''),
(70, 'Faroe Islands', ''),
(71, 'Fiji', ''),
(72, 'Finland', ''),
(73, 'France', ''),
(74, 'French Guiana', ''),
(75, 'French Polynesia', ''),
(76, 'French Southern Territories', ''),
(77, 'Gabon', ''),
(78, 'Gambia', ''),
(79, 'Georgia', ''),
(80, 'Germany', ''),
(81, 'Ghana', ''),
(82, 'Greece', ''),
(83, 'Greenland', ''),
(84, 'Grenada', ''),
(85, 'Guadaloupe', ''),
(86, 'Guam', ''),
(87, 'Guatamala', ''),
(88, 'Guinea-Bissau', ''),
(89, 'Guinea', ''),
(90, 'Guyana', ''),
(91, 'Haiti', ''),
(92, 'Heard and McDonald Islands', ''),
(93, 'Honduras', ''),
(94, 'Hong Kong', ''),
(95, 'Hungary', ''),
(96, 'Iceland', ''),
(97, 'India', ''),
(98, 'Indonesia', ''),
(99, 'Iran', ''),
(100, 'Iraq', ''),
(101, 'Ireland', ''),
(102, 'Israel', ''),
(103, 'Italy', ''),
(104, 'Jamaica', ''),
(105, 'Japan', ''),
(106, 'Jordan', ''),
(107, 'Kazakhstan', ''),
(108, 'Kenya', ''),
(109, 'Kiribati', ''),
(110, 'Korea (north)', ''),
(111, 'Korea (south)', ''),
(112, 'Kuwait', ''),
(113, 'Kyrgyzstan', ''),
(114, 'Laos', ''),
(115, 'Latvia', ''),
(116, 'Lebanon', ''),
(117, 'Lesotho', ''),
(118, 'Liberia', ''),
(119, 'Liechtenstein', ''),
(120, 'Lithuania', ''),
(121, 'Luxembourg', ''),
(122, 'Macau', ''),
(123, 'Macedonia', ''),
(124, 'Madagascar', ''),
(125, 'Malasia', ''),
(126, 'Malawi', ''),
(127, 'Maldives', ''),
(128, 'Mali', ''),
(129, 'Malta', ''),
(130, 'Marshal Islands', ''),
(131, 'Martinique', ''),
(132, 'Mauritania', ''),
(133, 'Maurritius', ''),
(134, 'Mayotte', ''),
(135, 'Mexico', ''),
(136, 'Micronesia', ''),
(137, 'Moldova', ''),
(138, 'Monaco', ''),
(139, 'Mongolia', ''),
(140, 'Montserrat', ''),
(141, 'Morocco', ''),
(142, 'Mozambique', ''),
(143, 'Mynamar', ''),
(144, 'Namibia', ''),
(145, 'Nauru', ''),
(146, 'Nepal', ''),
(147, 'Netherland Antilles', ''),
(148, 'Netherlands', ''),
(149, 'New Caledonia', ''),
(150, 'New Zealand', ''),
(151, 'Nicaragua', ''),
(152, 'Niger', ''),
(153, 'Nigeria', ''),
(154, 'Niue', ''),
(155, 'Norfolk Island', ''),
(156, 'Northern Marianas Islands', ''),
(157, 'Norway', ''),
(158, 'Oman', ''),
(159, 'Pakistan', ''),
(160, 'Palau', ''),
(161, 'Panama', ''),
(162, 'Papua New Guinea', ''),
(163, 'Paraguay', ''),
(164, 'Peru', ''),
(165, 'Philippines', ''),
(166, 'Pitcairn', ''),
(167, 'Poland', ''),
(168, 'Portugal', ''),
(169, 'Puerto Rico', ''),
(170, 'Qatar', ''),
(171, 'Reunion', ''),
(172, 'Romania', ''),
(173, 'Russian Federation', ''),
(174, 'Rwanda', ''),
(175, 'Saint Helena', ''),
(176, 'Saint Kitts and Nevis', ''),
(177, 'Saint Lucia', ''),
(178, 'Saint Pierre and Miquelon', ''),
(179, 'Saint Vincent and the Grenadines', ''),
(180, 'Samoa', ''),
(181, 'San Marino', ''),
(182, 'Sao Tome and Principe', ''),
(183, 'Saudi Arabia', ''),
(184, 'Senegal', ''),
(185, 'Seychelles', ''),
(186, 'Sierra Leone', ''),
(187, 'Singapore', ''),
(188, 'Slovak Republic', ''),
(189, 'Slovenia', ''),
(190, 'Solomon Islands', ''),
(191, 'Somalia', ''),
(192, 'South Africa', ''),
(193, 'South Georgia', ''),
(194, 'Spain', ''),
(195, 'Sri Lanka', ''),
(196, 'Sudan', ''),
(197, 'Suriname', ''),
(198, 'Svalbard and Jan Mayen Islands', ''),
(199, 'Swaziland', ''),
(200, 'Sweden', ''),
(201, 'Switzerland', ''),
(202, 'Syria', ''),
(203, 'Taiwan', ''),
(204, 'Tajikistan', ''),
(205, 'Tanzania', ''),
(206, 'Thailand', ''),
(207, 'Togo', ''),
(208, 'Tokelau', ''),
(209, 'Tonga', ''),
(210, 'Trinidad and Tobego', ''),
(211, 'Tunisia', ''),
(212, 'Turkey', ''),
(213, 'Turkmenistan', ''),
(214, 'Turks and Caicos Islands', ''),
(215, 'Tuvalu', ''),
(216, 'Uganda', ''),
(217, 'Ukraine', ''),
(218, 'United Arab Emirates', ''),
(219, 'United Kingdom', ''),
(220, 'United States of America', ''),
(221, 'Uruguay', ''),
(222, 'Uzbekistan', ''),
(223, 'Vanuatu', ''),
(224, 'Vatican City', ''),
(225, 'Venezuela', ''),
(226, 'Vietnam', ''),
(227, 'Virgin Islands (British)', ''),
(228, 'Virgin Islands (US)', ''),
(229, 'Wallis and Futuna Islands', ''),
(230, 'Western Sahara', ''),
(231, 'Yemen', ''),
(232, 'Yugoslavia', ''),
(233, 'Zaire', ''),
(234, 'Zambia', ''),
(235, 'Zimbabwe', '');

-- --------------------------------------------------------

--
-- Table structure for table `currencey`
--

CREATE TABLE IF NOT EXISTS `currencey` (
  `id` int(11) NOT NULL,
  `curr_name` varchar(255) NOT NULL,
  `curr_price` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currencey`
--


-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customers_id` int(11) NOT NULL auto_increment,
  `customers_gender` char(1) NOT NULL default '',
  `customers_firstname` varchar(32) NOT NULL default '',
  `customers_lastname` varchar(32) NOT NULL default '',
  `customers_dob` varchar(255) NOT NULL default '0',
  `occupation` varchar(255) NOT NULL,
  `m_status` varchar(255) NOT NULL,
  `anniversary_date` varchar(255) NOT NULL,
  `customers_email_address` varchar(96) NOT NULL default '',
  `mobile` varchar(255) NOT NULL,
  `customers_Title` varchar(96) NOT NULL default '',
  `companyname` varchar(255) NOT NULL default '',
  `address2` varchar(255) NOT NULL default '',
  `phone2` varchar(255) NOT NULL default '',
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL default '',
  `state` varchar(255) NOT NULL default '',
  `pincode` varchar(20) NOT NULL default '',
  `country` int(11) NOT NULL default '0',
  `customers_telephone` varchar(32) NOT NULL default '',
  `customers_fax` varchar(32) default NULL,
  `username` varchar(255) NOT NULL default '',
  `customers_password` varchar(40) NOT NULL default '',
  `memimage` varchar(255) NOT NULL default '',
  `customers_newsletter` char(1) default NULL,
  `updateprofile` int(11) NOT NULL default '0',
  `customers_email_format` varchar(4) NOT NULL default 'TEXT',
  `customers_authorization` int(1) NOT NULL default '0',
  `customers_referral` varchar(32) NOT NULL default '',
  `customers_paypal_payerid` varchar(20) NOT NULL default '',
  `customers_paypal_ec` tinyint(1) unsigned NOT NULL default '0',
  `hintsans` text NOT NULL,
  `std1` varchar(10) NOT NULL default '',
  `std2` varchar(10) NOT NULL default '',
  `ins` varchar(50) NOT NULL,
  PRIMARY KEY  (`customers_id`),
  KEY `idx_email_address_zen` (`customers_email_address`),
  KEY `idx_referral_zen` (`customers_referral`(10)),
  KEY `idx_grp_pricing_zen` (`updateprofile`),
  KEY `idx_nick_zen` (`customers_Title`),
  KEY `idx_newsletter_zen` (`customers_newsletter`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=127 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customers_id`, `customers_gender`, `customers_firstname`, `customers_lastname`, `customers_dob`, `occupation`, `m_status`, `anniversary_date`, `customers_email_address`, `mobile`, `customers_Title`, `companyname`, `address2`, `phone2`, `address`, `city`, `state`, `pincode`, `country`, `customers_telephone`, `customers_fax`, `username`, `customers_password`, `memimage`, `customers_newsletter`, `updateprofile`, `customers_email_format`, `customers_authorization`, `customers_referral`, `customers_paypal_payerid`, `customers_paypal_ec`, `hintsans`, `std1`, `std2`, `ins`) VALUES
(1, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(2, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(3, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(4, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(5, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(6, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(7, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(8, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(9, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(10, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(11, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(12, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(13, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(14, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(15, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(16, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(17, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(18, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(19, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(20, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(21, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(22, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(23, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(24, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(25, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(26, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(27, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(28, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(29, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(30, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(31, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(32, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(33, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(34, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(35, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(36, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(37, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(38, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(39, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(40, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(41, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(42, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(43, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(44, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(45, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(46, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(47, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(48, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(49, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(50, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(51, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(52, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(53, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(54, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(55, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(56, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(57, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(58, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(59, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(60, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(61, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(62, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(63, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(64, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(65, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(66, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(67, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(68, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(69, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(70, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(71, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(72, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(73, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(74, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(75, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(76, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(77, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(78, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(79, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(80, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(81, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(82, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(83, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(84, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(85, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(86, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(87, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(88, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(89, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(90, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(91, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(92, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(93, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(94, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(95, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(96, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(97, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(98, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(99, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(100, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(101, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(102, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(103, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(104, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(105, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(106, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(107, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(108, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(109, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(110, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(111, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(112, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(113, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(114, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(115, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(116, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(117, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(118, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(119, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(120, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(121, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(122, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(123, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(124, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(125, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', ''),
(126, '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', NULL, '', '', '', NULL, 0, 'TEXT', 0, '', '', 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_tmp`
--

CREATE TABLE IF NOT EXISTS `customer_tmp` (
  `id` int(11) NOT NULL auto_increment,
  `firstname` varchar(255) NOT NULL default '',
  `occupation` varchar(255) NOT NULL,
  `m_status` varchar(255) NOT NULL,
  `anniversary_date` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL default '',
  `gender` varchar(10) NOT NULL default '',
  `dob` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `mobile` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `hints` varchar(255) NOT NULL default '',
  `accept` binary(1) NOT NULL default '\0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer_tmp`
--


-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `faq_id` int(50) NOT NULL auto_increment,
  `faq_question` varchar(255) NOT NULL default '',
  `faq_ans` varchar(255) NOT NULL default '',
  `faq_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`faq_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `faq`
--


-- --------------------------------------------------------

--
-- Table structure for table `featureditem_payment`
--

CREATE TABLE IF NOT EXISTS `featureditem_payment` (
  `id` int(11) NOT NULL auto_increment,
  `itemid` int(11) NOT NULL default '0',
  `paymentid` int(100) NOT NULL default '0',
  `amount` float NOT NULL default '0',
  `todate` bigint(20) NOT NULL default '0',
  `enddate` bigint(20) NOT NULL default '0',
  `status` binary(1) NOT NULL default '\0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `featureditem_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `flavour`
--

CREATE TABLE IF NOT EXISTS `flavour` (
  `cid` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `flavour`
--

INSERT INTO `flavour` (`cid`, `name`) VALUES
(18, 'Chocolate'),
(19, 'Vanilla'),
(21, 'Milk Chocolate'),
(22, 'Banana'),
(23, 'Strawberry'),
(24, 'Cookies & Cream'),
(25, 'Fruit Punch'),
(26, 'Orange'),
(27, 'Pineapple'),
(28, 'Watermelon'),
(29, 'Grape Blast'),
(30, 'Vanilla Ice Cream'),
(31, 'Coffee'),
(32, 'Chocolate Cream'),
(33, 'Green Apple'),
(34, 'Blue Respberry'),
(35, 'Unflavoured'),
(36, 'Sucker Punch'),
(37, 'Malicious Melon'),
(39, 'Chocolate Ice Cream'),
(40, 'Banana & Cream'),
(41, 'Chocolate Malt'),
(42, 'Chocolate Mint'),
(43, 'Chocolate Peanut Butter'),
(45, 'Coffee & Cream'),
(46, 'Double Rich Chocolate'),
(47, 'French Vanilla Cream'),
(48, 'Mocha Capuccino'),
(49, 'Mocha Capuccino Flavour'),
(50, 'Rocky Road'),
(51, 'Strawberry Banana'),
(52, 'Vanila Creme'),
(53, 'Vanila Creme'),
(54, 'Vanila Creme'),
(55, 'Natural'),
(56, 'Raspberry'),
(57, 'Rum Raisin'),
(58, 'Cinnamon Roll'),
(59, 'Delicious Vanilla'),
(60, 'Strawberry & Cream'),
(61, 'Banana Perfection'),
(62, 'Cafe Brazil'),
(63, 'Cafe Fudge'),
(65, 'Chocolate Fudge'),
(66, 'Dutch Chocolate'),
(67, 'Strawberry Ice Cream'),
(68, 'Apple Melon'),
(69, 'Mint Chocolate Chip'),
(70, 'Pineapple Orange Banana'),
(71, 'Mango Peach'),
(72, 'Double Rich Cookie & Cream'),
(73, 'Chocolate Coconut'),
(74, 'Italian Cappuccino'),
(75, 'Wild Strawberry'),
(76, 'Chocolate Milk Shake'),
(77, 'Coconut'),
(78, 'Coconut Peanut Butter'),
(79, 'Strawberry Milkshake'),
(80, 'Chocolate Cake Batter'),
(81, 'Chocolate Supreme'),
(82, 'Raspberry Smoothie'),
(83, 'Loaded Lemonde'),
(84, 'Red Raspberry'),
(85, 'Wild Cherry'),
(86, 'Pink Lemonade'),
(87, 'Lemon Lime'),
(88, 'Blueberry'),
(89, 'Blue Rasberry'),
(90, 'Grape'),
(91, 'Swiss Chocolate'),
(99, 'Orange Mango'),
(100, 'Gourmet Vanilla'),
(101, 'Rich Chocolate');

-- --------------------------------------------------------

--
-- Table structure for table `grievance_comp`
--

CREATE TABLE IF NOT EXISTS `grievance_comp` (
  `gr_id` int(11) NOT NULL auto_increment,
  `gr_name` varchar(255) NOT NULL,
  `gr_email` varchar(255) NOT NULL,
  `gr_subjest` varchar(255) NOT NULL,
  `gr_comment` varchar(255) NOT NULL,
  PRIMARY KEY  (`gr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `grievance_comp`
--


-- --------------------------------------------------------

--
-- Table structure for table `g_image`
--

CREATE TABLE IF NOT EXISTS `g_image` (
  `c_id` bigint(20) NOT NULL auto_increment,
  `year` varchar(30) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `ccity` varchar(255) NOT NULL,
  `work_shop_ex` varchar(255) NOT NULL,
  `school` varchar(255) NOT NULL,
  `cstatus` binary(1) NOT NULL,
  `cimage` varchar(255) NOT NULL,
  `status` binary(1) NOT NULL,
  PRIMARY KEY  (`c_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `g_image`
--


-- --------------------------------------------------------

--
-- Table structure for table `make`
--

CREATE TABLE IF NOT EXISTS `make` (
  `cid` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `make`
--

INSERT INTO `make` (`cid`, `name`) VALUES
(15, 'Maker Name 1'),
(16, 'Maker Name 2'),
(17, 'Maker Name 3');

-- --------------------------------------------------------

--
-- Table structure for table `marbanner`
--

CREATE TABLE IF NOT EXISTS `marbanner` (
  `cid` int(5) NOT NULL auto_increment,
  `cname` varchar(255) NOT NULL,
  `hyperlink` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `m_image` varchar(255) NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `marbanner`
--

INSERT INTO `marbanner` (`cid`, `cname`, `hyperlink`, `name`, `m_image`) VALUES
(1, 'Ad 1', 'http://bodykart.in/detail-itid-23-catid-198.html', 'Top', '1013714696index2.jpg'),
(2, 'Banner 2', 'http://bodykart.in/detail-itid-91-catid-198.html', 'Middle', '2052289478index3.jpg'),
(3, 'Banner 33', '#', 'Bottom', '1575254246index.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `members_join`
--

CREATE TABLE IF NOT EXISTS `members_join` (
  `id` int(11) NOT NULL auto_increment,
  `invitor_id` int(11) NOT NULL default '0',
  `joined_id` int(11) NOT NULL default '0',
  `status` char(1) character set latin1 collate latin1_bin NOT NULL default '',
  `jdate` bigint(20) NOT NULL default '0',
  `joinkey` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `members_join`
--


-- --------------------------------------------------------

--
-- Table structure for table `member_msg_tbl`
--

CREATE TABLE IF NOT EXISTS `member_msg_tbl` (
  `id` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `postedby` int(11) NOT NULL default '0',
  `date_added` bigint(20) NOT NULL default '0',
  `message` text NOT NULL,
  `status` binary(1) NOT NULL default '\0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `member_msg_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `member_vew`
--

CREATE TABLE IF NOT EXISTS `member_vew` (
  `mem_id` int(33) NOT NULL auto_increment,
  `mem_name` varchar(255) NOT NULL,
  `mem_view` varchar(255) NOT NULL,
  `member` varchar(255) NOT NULL,
  PRIMARY KEY  (`mem_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `member_vew`
--


-- --------------------------------------------------------

--
-- Table structure for table `memcomment_tbl`
--

CREATE TABLE IF NOT EXISTS `memcomment_tbl` (
  `id` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `date_added` bigint(20) NOT NULL default '0',
  `postedby` int(11) NOT NULL default '0',
  `comment` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `memcomment_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE IF NOT EXISTS `model` (
  `cid` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`cid`, `name`) VALUES
(51, 'Model  Name 1'),
(52, 'Model  Name 2'),
(53, 'Model  Name 3');

-- --------------------------------------------------------

--
-- Table structure for table `myfavrites`
--

CREATE TABLE IF NOT EXISTS `myfavrites` (
  `id` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `itemid` int(11) NOT NULL default '0',
  `itemtype` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `myfavrites`
--


-- --------------------------------------------------------

--
-- Table structure for table `mywishlist`
--

CREATE TABLE IF NOT EXISTS `mywishlist` (
  `id` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `itemid` int(11) NOT NULL default '0',
  `itemtype` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mywishlist`
--


-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL auto_increment,
  `memid` int(100) NOT NULL default '0',
  `se_brow_id` varchar(255) NOT NULL,
  `orderid` int(11) NOT NULL default '0',
  `itemsid` int(11) NOT NULL default '0',
  `shopid` int(11) NOT NULL default '0',
  `quantity` int(20) default NULL,
  `waitstatus` int(11) NOT NULL default '0',
  `shipped` char(1) character set latin1 collate latin1_bin NOT NULL default '',
  `orderdate` bigint(20) NOT NULL default '0',
  `size` varchar(20) NOT NULL default '',
  `shape` varchar(20) NOT NULL default '',
  `color` varchar(20) NOT NULL default '',
  `billing_cust_name` varchar(100) NOT NULL,
  `billing_cust_address` varchar(255) NOT NULL,
  `billing_cust_country` varchar(100) NOT NULL,
  `billing_cust_state` varchar(50) NOT NULL,
  `billing_cust_city` varchar(50) NOT NULL,
  `billing_zip` varchar(15) NOT NULL,
  `billing_cust_tel` varchar(15) NOT NULL,
  `billing_cust_email` varchar(255) NOT NULL,
  `delivery_cust_name` varchar(100) NOT NULL,
  `delivery_cust_address` varchar(255) NOT NULL,
  `delivery_cust_country` varchar(50) NOT NULL,
  `delivery_cust_state` varchar(50) NOT NULL,
  `delivery_cust_city` varchar(50) NOT NULL,
  `delivery_cust_zip` varchar(15) NOT NULL,
  `delivery_cust_tel` varchar(15) NOT NULL,
  `add_date` datetime NOT NULL,
  `subtotal` int(11) NOT NULL,
  `status` int(1) NOT NULL default '0',
  `intPaid` int(1) NOT NULL default '0',
  `shipby` varchar(255) NOT NULL,
  `awbno` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `othership` varchar(255) NOT NULL,
  `shipprice` float NOT NULL,
  `Packingprice` float NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=137 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `memid`, `se_brow_id`, `orderid`, `itemsid`, `shopid`, `quantity`, `waitstatus`, `shipped`, `orderdate`, `size`, `shape`, `color`, `billing_cust_name`, `billing_cust_address`, `billing_cust_country`, `billing_cust_state`, `billing_cust_city`, `billing_zip`, `billing_cust_tel`, `billing_cust_email`, `delivery_cust_name`, `delivery_cust_address`, `delivery_cust_country`, `delivery_cust_state`, `delivery_cust_city`, `delivery_cust_zip`, `delivery_cust_tel`, `add_date`, `subtotal`, `status`, `intPaid`, `shipby`, `awbno`, `comment`, `othership`, `shipprice`, `Packingprice`) VALUES
(3, 3, '', 1808048377, 0, 0, NULL, 0, '', 0, '', '', '', 'Ravi rathee', 'Sf 41 Svk', 'India', 'Hry', 'Ggn', '122001', '7042828711', 'ravi_rathee22@yahoo.com', 'Ravi rathee', 'Sf 41 Svk', 'India', 'Hry', 'Ggn', '122001', '7042828711', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(2, 2, '', 458767803, 0, 0, NULL, 0, '', 0, '', '', '', 'Manish Dua', 'SF-37, Second Floor, Sushant Vyapar Kendra,\r\nSushant Lok-1, Near Huda City Center Metro Station,', 'India', 'Haryana', 'Gurgaon', '122002', '07503024770', 'manish@gapinfotech.com', 'Manish Dua', 'SF-37, Second Floor, Sushant Vyapar Kendra,\r\nSushant Lok-1, Near Huda City Center Metro Station,', 'India', 'Haryana', 'Gurgaon', '122002', '07503024770', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(4, 4, '', 1996213687, 0, 0, NULL, 0, '', 0, '', '', '', 'Ravi Ranjna', 'H.no-57a,kotla Vihar Phase 2\r\nDelhi', 'India', 'Delhi', 'Delhi', '110041', '9555349579', 'ranjan.ravi.ravi2@gmail.com', 'Ravi Ranjna', 'H.no-57a,kotla Vihar Phase 2\r\nDelhi', 'India', 'Delhi', 'Delhi', '110041', '9555349579', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(5, 5, '', 1469198350, 0, 0, NULL, 0, '', 0, '', '', '', 'Ravi rather', 'Sf 41 Svk', 'India', 'Haryana', 'Gurgaon', '122001', '7042818711', 'ravi.rathee22@gmail.com', 'Ravi rathee', 'Sf 41 Svk', 'India', 'Haryana', 'Gurgaon', '122001', '7042828711', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(6, 6, '', 765074627, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(7, 7, '', 170182940, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(8, 8, '', 531660564, 0, 0, NULL, 0, '', 0, '', '', '', 'ravi rathee', 'sf 41 svk', 'India', 'haryana', 'gurgaon', '122001', '7042828711', 'ravi_rathee22@YAHOO.COM', 'ravi rathee', 'sf 41 svk', 'India', 'haryana', 'gurgaon', '122001', '7042828711', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(9, 9, '', 198422057, 0, 0, NULL, 0, '', 0, '', '', '', 'dip chatterjee', 'B004, SALT LAKE, CITY CENTRE, KOLKATA - 700064.', 'India', 'WEST BENGAL', 'KOLKATA', '700064', '9038214762', 'dip5300@gmail.com', 'dip chatterjee', 'B004, SALT LAKE, CITY CENTRE, KOLKATA - 700064.', 'India', 'WEST BENGAL', 'KOLKATA', '700064', '9038214762', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(10, 10, '', 1549934533, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(11, 11, '', 682356705, 0, 0, NULL, 0, '', 0, '', '', '', 'Alpha1, Beta0, Delhi', 'Alpha1, Beta0, Delhi', 'India', 'Delhi', 'Delhi', '110001', '09876543210', 'ashuin27@yahoo.com', 'Alpha1, Beta0, Delhi', 'Alpha1, Beta0, Delhi', 'India', 'Delhi', 'Delhi', '110001', '09876543210', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(12, 12, '', 1051002270, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(13, 13, '', 962108637, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(14, 14, '', 1455205022, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(15, 15, '', 768741879, 0, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(16, 16, '', 229924833, 0, 0, NULL, 0, '', 0, '', '', '', 'Shrikant', 'Kannamwar nagar 1 , Bldg no. 175 , Room no. 5987 , Vikhroli East', 'India', 'Maharashtra', 'Mumbai', '400083', '8454872121', 'shrikantdalvi046@yahoo.in', 'Shrikant', 'Kannamwar nagar 1 , Bldg no. 175 , Room no. 5987 , Vikhroli East', 'India', 'Maharashtra', 'Mumbai', '400083', '8454872121', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(18, 18, '', 826584593, 53, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(19, 18, '', 826584593, 103, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(20, 19, '', 183744004, 26, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(21, 20, '', 748689732, 122, 0, NULL, 0, '', 0, '', '', '', 'ankush yadav', '\r\nc/o Ramesh more near gosavi Conley ganesh Nagar Amravati', 'India', 'Maharashtra', 'amravati', '444607', '7350076993', 'ankushyadav4149@gmail.com', 'ankush yadav', '\r\nc/o Ramesh more near gosavi Conley ganesh Nagar Amravati\r\n\r\n ', 'India', 'Maharashtra', 'amravati', '444607', '7350076993', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(22, 21, '', 246978256, 82, 0, NULL, 0, '', 0, '', '', '', 'Rajiv B Tayade ', '44, Bhumiputra colony, Near congress nagar, old bye pass road, Amravati - Maharashtra ', 'India', 'Maharashtra ', 'Amravati ', '444606', '9923133441 ', 'rajiv.tayade@gmail.com ', 'Rajiv B Tayade ', '44, Bhumiputra colony, Near congress nagar, old bye pass road, Amravati - Maharashtra ', 'India', 'Maharashtra ', 'Amravati ', '444606', '9923133441 ', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(24, 23, '', 783474763, 130, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(25, 24, '', 1316964844, 127, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(26, 25, '', 1739792698, 146, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(27, 26, '', 96134998, 147, 0, NULL, 0, '', 0, '', '', '', 'Ayoob Hameed', 'Chaliparambu house', 'India', 'Kerala', 'Ernakulam', '682021', '8606507035', 'ayoobhameed12345@gmail.com', 'Ayoob Hameed', 'Chaliparambu house', 'India', 'Kerala', 'Ernakulam', '682021', '8606507035', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(28, 27, '', 1626765217, 146, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(29, 28, '', 1372354254, 32, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(30, 29, '', 1426874082, 122, 0, NULL, 0, '', 0, '', '', '', 'Livinson', 'RM_7, Bharthi CHAWL(1),\r\nBehind vallabh bldg,\r\nOpp police station.\r\nDharavi.', 'India', 'Maharashtra', 'Mumbai', '400017', '7208661245', 'Livins.n005@gmail.com', 'livinson', 'RM_7,Bharathi chawl (1),\r\nBehind vallabh bldg,\r\nOpp police station,\r\nDharavi.', 'India', 'maharashtra', 'mumbai', '400017', '7208661245', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(31, 30, '', 1460618702, 31, 0, NULL, 0, '', 0, '', '', '', 'yuvraj pillay', 'Sr no 21/b1 ganesh nagar road no 4 bhopkhel pune 31', 'India', 'maharastra', 'pune', '411031', '7385973727', 'yuvraj.m6857@gmail.com', 'yuvraj pillay', 'Sr no 21/b1 ganesh nagar road no 4 bhopkhel pune 31', 'India', 'maharastra', 'pune', '411031', '7385973727', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(32, 31, '', 1693458693, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(33, 32, '', 1138095264, 146, 0, NULL, 0, '', 0, '', '', '', 'vishal', 'c/0 ss mushannavar house no.15, near kattimanglamma temple, lingraj nagar, vidyanagar,hubli 580031', 'India', 'karnataka', 'hubli', '580031', '9886588749', 'vishalchauhancr7@gmail.com', 'vishal', 'c/0 ss mushannavar house no.15, near kattimanglamma temple, lingraj nagar, vidyanagar,hubli 580031', 'India', 'karnataka', 'hubli', '580031', '9886588749', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(34, 33, '', 595899227, 168, 0, NULL, 0, '', 0, '', '', '', 'Anoop Yadav', 'Maruti suzuki  gate no. 4  sec.8  IMT Manesar', 'India', 'Haryana', 'Gurgaon', '123503', '9953728812', 'anoopyadav7477@yahoo.com', 'Anoop Yadav', 'Maruti suzuki  gate no. 4  sec.8  IMT Manesar', 'India', 'Haryana', 'Gurgaon', '123503', '9953728812', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(35, 34, '', 2070994464, 153, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(36, 35, '', 330947353, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(37, 36, '', 1514480802, 209, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(38, 37, '', 124938256, 184, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(39, 38, '', 1056465202, 142, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(40, 39, '', 1738173740, 142, 0, NULL, 0, '', 0, '', '', '', 'Jaymal Modhwadiya', 'D-5\r\nAditinagar\r\nOpp- Mastaram Chambers\r\nMaduram', 'India', 'Gujarat', 'Junagadh', '362001', '9824079593', 'Jaltheillusionist@gmail.com', 'Jaymal Modhwadiya', 'D-5\r\nAditinagar\r\nOpp- Mastaram Chambers\r\nMaduram', 'India', 'Gujarat', 'Junagadh', '362001', '9824079593', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(41, 40, '', 1409071340, 140, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(42, 41, '', 1592258528, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(43, 42, '', 212780425, 145, 0, NULL, 0, '', 0, '', '', '', 'haider ali', 'Nanak nagar thakurganj near arma nursing home', 'India', 'up', 'lucknow', '226003', '7860877776', 'haider.alixr007@gmail.com ', 'haider ali', 'Nanak nagar thakurganj near arma nursing home', 'India', 'up', 'lucknow', '226003', '7860877776', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(44, 43, '', 1445331494, 124, 0, NULL, 0, '', 0, '', '', '', 'samir', 'House no.953,street no.30,jaffrabad,near kashmiri building ,new seelampur ,Delhi-110053', 'India', 'delhi', 'delhi', '110053', '9136830501', 'samirkhan07861@yahoo.com', 'samir', 'House no.953,street no.30,jaffrabad,near kashmiri building ,new seelampur ,Delhi-110053', 'India', 'delhi', 'delhi', '110053', '9136830501', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(45, 44, '', 1763343541, 39, 0, NULL, 0, '', 0, '', '', '', 'rs s', 'dd\r\n3', 'India', 'Delhi', 'delhi', '110052', '08860087782', 'shyantyrahul@gmail.com', 'rs s', 'dd\r\n3', 'India', 'Delhi', 'delhi', '110052', '08860087782', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(46, 45, '', 2068911939, 144, 0, NULL, 0, '', 0, '', '', '', 'abhhishek mitra', 'lords and melbourne hostel near sanjeevani school sector 19 kharghar', 'India', 'Mumbai', 'NAVI MUMBAI', '410210', '9833949432', 'anilko1986@gmail.com', 'abhhishek mitra', 'lords and melbourne hostel near sanjeevani school sector 19 kharghar', 'India', 'Mumbai', 'NAVI MUMBAI', '410210', '9833949432', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(47, 46, '', 1007847909, 137, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(48, 47, '', 1638083937, 141, 0, NULL, 0, '', 0, '', '', '', 'Rajesh gopalakrishnan', 'E-903 \r\nTrillium\r\nMagarpatta\r\nPune-411013', 'India', 'Maharashtra', 'Magarpatta', '411013', '9689845858', 'renjini_nairn@yahoo.co.in', 'Rajesh gopalakrishnan', 'E-903 \r\nTrillium\r\nMagarpatta\r\nPune-411013', 'India', 'Maharashtra', 'Magarpatta', '411013', '8888806336', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(49, 48, '', 1948326755, 138, 0, NULL, 0, '', 0, '', '', '', 'Vanshaj Vk', 'room no. 317 le corbusier hostel - D\r\nNH95 Chandigarh University Gharuan ', 'India', 'Punjab', 'Gharuan', '140413', '9988667284', 'vkvanshaj@gmail.com', 'Vanshaj Vk', 'room no. 317 le corbusier hostel - D\r\nNH95 Chandigarh University Gharuan ', 'India', 'Punjab', 'Gharuan', '140413', '9988667284', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(50, 49, '', 915042568, 135, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(51, 50, '', 1632701680, 140, 0, NULL, 0, '', 0, '', '', '', 'ponkil hazarika', 'A type 718 oil colony near old post office ', 'India', 'assam', 'duliajan', '786602', '8402803991', 'ponkilhazarika38@gmail.com', 'ponkil hazarika', 'A type 718 oil colony near old post office ', 'India', 'assam', 'duliajan', '786602', '8402803991', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(52, 51, '', 1260362481, 142, 0, NULL, 0, '', 0, '', '', '', 'ponkil hazarika', 'A type 718 oil colony near old post office', 'India', 'assam', 'duliajan', '786602', '8402803991', 'ronirajkonwar@gmail.com', 'ponkil hazarika', 'A type 718 oil colony near old post office', 'India', 'assam', 'duliajan', '786602', '8402803991', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(53, 52, '', 1441926790, 142, 0, NULL, 0, '', 0, '', '', '', 'Ponkil Hazarika', 'A type 718 oil colony near old post office ', 'India', 'Assam', 'Duliajan', '786602', '8402803991', 'ponkilhazarika38@gmail.com', 'Ponkil Hazarika', 'A type 718 oil colony near old post office ', 'India', 'Assam', 'Duliajan', '786602', '8402803991', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(54, 53, '', 111072435, 141, 0, NULL, 0, '', 0, '', '', '', 'ponkil hazarika', 'A type 718 oil colony near old post office', 'India', 'Assam', 'Duliajan', '786602', '8402803991 ', 'ronirajkonwar@Gmail.com', 'ponkil hazarika', 'A type 718 oil colony near old post office', 'India', 'Assam', 'Duliajan', '786602', '8402803991 ', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(55, 54, '', 143311859, 144, 0, NULL, 0, '', 0, '', '', '', 'Rohan Mittal', 'A-28, FOPE Hostel, RIL Saraswati Township, Near Welspun Company, Village:Vadadala, Taluka:Vagra, Dahej \r\nBharuch, Gujarat - 392130', 'India', 'Gujarat', 'Bharuch', '392130', '7383335061', 'rohanmittal21@gmail.com', 'Rohan Mittal', 'A-28, FOPE Hostel, RIL Saraswati Township, Near Welspun Company, Village:Vadadala, Taluka:Vagra, Dahej \r\nBharuch, Gujarat - 392130', 'India', 'Gujarat', 'Bharuch', '392130', '7383335061', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(56, 55, '', 153493709, 123, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(57, 56, '', 980742722, 141, 0, NULL, 0, '', 0, '', '', '', 'Karthik U L', 'S/0 LAVAKUMAR U B ,#123 BAIRAVESHWARA NILAYA\r\n2ND LBS NAGAR SOWLANGA ROAD SHIMOGA', 'India', 'karnataka', 'Shimoga', '577204', '9739905134', 'karthikul505@gmail.com', 'Karthik U L', 'S/0 LAVAKUMAR U B ,#123 BAIRAVESHWARA NILAYA\r\n2ND LBS NAGAR SOWLANGA ROAD SHIMOGA', 'India', 'karnataka', 'Shimoga', '577204', '9739905134', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(59, 57, '', 375871737, 139, 0, NULL, 0, '', 0, '', '', '', 'Denny George', 'Symbiosis Vishwabhavan Boys Hostel SB Road hanuman Nagar , Pune, 411016', 'India', 'Maharashtra', 'Pune', '411016', '8879890856', 'loldennygeorge@gmail.com', 'Denny George', 'Symbiosis Vishwabhavan Boys Hostel SB Road hanuman Nagar , Pune, 411016', 'India', 'Maharashtra', 'Pune', '411016', '8879890856', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(60, 57, '', 375871737, 145, 0, NULL, 0, '', 0, '', '', '', 'Denny George', 'Symbiosis Vishwabhavan Boys Hostel SB Road hanuman Nagar , Pune, 411016', 'India', 'Maharashtra', 'Pune', '411016', '8879890856', 'loldennygeorge@gmail.com', 'Denny George', 'Symbiosis Vishwabhavan Boys Hostel SB Road hanuman Nagar , Pune, 411016', 'India', 'Maharashtra', 'Pune', '411016', '8879890856', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(61, 58, '', 1258331378, 170, 0, NULL, 0, '', 0, '', '', '', 'Ashish', 'H-1590, gali no- 44,B-block, hanumaan kunj , banagali colony, sant nagar burari', 'India', 'new delhi', 'delhi', '110084', '7503912754', 'ak39576@gmail.com', 'Ashish', 'H-1590, gali no- 44,B-block, hanumaan kunj , banagali colony, sant nagar burari', 'India', 'new delhi', 'delhi', '110084', '7503912754', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(62, 59, '', 900869039, 34, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(63, 60, '', 115334267, 170, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(64, 61, '', 2002728150, 144, 0, NULL, 0, '', 0, '', '', '', 'Kaushik Baria', 'C/18, Neelkantheswar soc. ', 'India', 'Gujarat', 'Vadodara', '390024', '9722240633', 'kaushikbaria@gmail.com', 'Kaushik Baria', 'C/18, Neelkantheswar soc. ', 'India', 'Gujarat', 'Vadodara', '390024', '9722240633', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(65, 62, '', 667893518, 34, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(66, 63, '', 119954574, 195, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(67, 64, '', 1148654942, 148, 0, NULL, 0, '', 0, '', '', '', 'Prasad Mundhe', '77/2, C, Karan Bharati Apt., Flat no -22, Behind Bharati Vidyapeeth, Near Ichhapurti Mandir, Katraj,', 'India', 'Maharashtra', 'Pune', '411046', '9850785587', 'prasad.mundhe@ymail.com', 'Prasad Mundhe', '77/2, C, Karan Bharati Apt., Flat no -22, Behind Bharati Vidyapeeth, Near Ichhapurti Mandir, Katraj,', 'India', 'Maharashtra', 'Pune', '411046', '9850785587', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(68, 65, '', 743325656, 200, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(75, 70, '', 1657837665, 138, 0, NULL, 0, '', 0, '', '', '', 'sandip sharma', 'M/s Mewar Marbles.Beside faridpur police station..faridpur..durgapur ', 'India', 'West bengal', 'durgapur', '713213', '7602585334', '1941988@gmail.com', 'sandip sharma', 'M/s Mewar Marbles.Beside faridpur police station..faridpur..durgapur ', 'India', 'West bengal', 'durgapur', '713213', '7602585334', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(72, 67, '', 435671020, 64, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(73, 68, '', 1440320934, 196, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(74, 69, '', 1275343956, 141, 0, NULL, 0, '', 0, '', '', '', 'divyasagar', '10-3-208c kota kommala street', 'India', 'Andhra Pradesh', 'tirupathi', '517501', '919703084000', 'jalakamdivyasagar@gmail.com', 'divyasagar', '10-3-208c kota kommala street', 'India', 'Andhra Pradesh', 'tirupathi', '517501', '919703084000', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(76, 71, '', 1438827514, 202, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(77, 72, '', 58622440, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(78, 73, '', 846498237, 49, 0, NULL, 0, '', 0, '', '', '', 'Dr.kamal Dholakia', '7,orient colony\r\n\r\nOpp. V.D. highschool', 'India', 'Gujarat', 'Bhuj', '370001', '9824800235', 'drkddholakia@yahoo.com', 'Dr.kamal Dholakia', '7,orient colony\r\n\r\nOpp. V.D. highschool', 'India', 'Gujarat', 'Bhuj', '370001', '9824800235', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(79, 74, '', 1704868065, 144, 0, NULL, 0, '', 0, '', '', '', 'sachin khillare', 'Tanaji nagar ward no 20,\r\nJaiswal ley out,\r\nNear buddha vihar', 'India', 'Maharashtra', 'buldhana', '443001', '8983340392', 'neo5792@gmail.com', 'sachin khillare', 'Tanaji nagar ward no 20,\r\nJaiswal ley out,\r\nNear buddha vihar', 'India', 'Maharashtra', 'buldhana', '443001', '8983340392', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(80, 75, '', 1553463408, 155, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(81, 76, '', 7584427, 146, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(82, 77, '', 461788549, 119, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(83, 78, '', 1149302186, 48, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(85, 79, '', 665707648, 194, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(86, 80, '', 188575129, 141, 0, NULL, 0, '', 0, '', '', '', 'Karthik R Kamath', '#86, 4th cross ganapathi nagar laggere peenya, Near BGS school Bangalore 58', 'India', 'Karnataka', 'Bangalore', '560058', '7259747491', 'karthikkamath1992@gmail.com', 'Karthik R Kamath', '#86, 4th cross ganapathi nagar laggere peenya, Near BGS school Bangalore 58', 'India', 'Karnataka', 'Bangalore', '560058', '7259747491', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(87, 81, '', 865221982, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(88, 82, '', 312916844, 141, 0, NULL, 0, '', 0, '', '', '', 'Karthik Kamath', '86,4th Cross Ganapathi Nagar Near BGS school Laggere Peenya Bangalore 58', 'India', 'Karnataka', 'Bangalore', '560058', '7259747491', 'karthikkamath1992@gmail.com', 'Karthik Kamath', '86,4th Cross Ganapathi Nagar Near BGS school Laggere Peenya Bangalore 58', 'India', 'Karnataka', 'Bangalore', '560058', '7259747491', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(89, 83, '', 310581829, 144, 0, NULL, 0, '', 0, '', '', '', 'Mayur S Mankar', 'A-5, Kritika apartment, lane number 9, dahanukar colony', 'India', 'Maharashtra', 'Pune', '411029', '8983253949', 'mankarmayur0@gmail.com', 'Mayur S Mankar', 'A-5, Kritika apartment, lane number 9, dahanukar colony', 'India', 'Maharashtra', 'Pune', '411029', '8983253949', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(90, 84, '', 2067008401, 145, 0, NULL, 0, '', 0, '', '', '', 'sachin khillare', 'Tanaji nagar, ward no 20\r\nJaiswal ley out, near buddha vihar,\r\nBuldhana', 'India', 'Maharashtra', 'buldhana', '443001', '8983340392', 'neo5792@gmail.com', 'sachin khillare', 'Tanaji nagar, ward no 20\r\nJaiswal ley out, near buddha vihar,\r\nBuldhana', 'India', 'Maharashtra', 'buldhana', '443001', '8983340392', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(91, 85, '', 2103373466, 140, 0, NULL, 0, '', 0, '', '', '', 'sumit khairnar', '47,balirampeth near durga devi temple khairnar tailors', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', 'sumitkhairnar2811@gmail.com', 'sumit khairnar', '47,balirampeth near durga devi temple khairnar tailors', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(92, 86, '', 1457143716, 140, 0, NULL, 0, '', 0, '', '', '', 'sumit', '47, baliram peth near durga devi temple, khairnar tailours', 'India', 'MAHARASHTRA', 'jalgaon', '425001', '9422217090', 'sumitkhairnar2811@gmail.com', 'sumit', '47, baliram peth near durga devi temple, khairnar tailours', 'India', 'MAHARASHTRA', 'jalgaon', '425001', '9422217090', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(93, 87, '', 911359566, 201, 0, NULL, 0, '', 0, '', '', '', 'tghuik', 'gthyh hhhhn', 'India', 'Haryana', 'Gurgaon', '122003', '7894561230', 'aswert@gthyh.in', 'tghuik', 'gthyh hhhhn', 'India', 'Haryana', 'Gurgaon', '122003', '7894561230', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(94, 88, '', 1742699859, 140, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(95, 89, '', 410953988, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(96, 90, '', 1092620855, 124, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(97, 91, '', 1919283614, 142, 0, NULL, 0, '', 0, '', '', '', 'sidhant kapoor', 'flat no. 8 nizamuddin east market, first floor. near nirankari bhavan ', 'India', 'Delhi', 'New Delhi', '110013', '9999479940', 'sidhant.kpr@gmail.com', 'sidhant kapoor', 'flat no. 8 nizamuddin east market, first floor. near nirankari bhavan ', 'India', 'Delhi', 'New Delhi', '110013', '9999479940', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(98, 92, '', 1572182872, 161, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(99, 93, '', 735473469, 140, 0, NULL, 0, '', 0, '', '', '', 'sumit khairnar', '47, baliram peth near durga devi temple khairnar tailors ', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', 'sumitkhairnar2811@gmail.com', 'sumit khairnar', '47, baliram peth near durga devi temple khairnar tailors ', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(100, 94, '', 1254876946, 171, 0, NULL, 0, '', 0, '', '', '', 'Swapnil mishra', 'New area,jailhata', 'India', 'Jharkhand', 'Daltonganj', '822101', '8409501893', 'Praveenmishrapm19@gmail.com', 'Swapnil mishra', 'New area,jailhata', 'India', 'Jharkhand', 'Daltonganj', '822101', '8409501893', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(101, 95, '', 1995817276, 140, 0, NULL, 0, '', 0, '', '', '', 'sumit khairnar', '47,baliran peth near durga devi temple khairnar tailors', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', 'sumitkhairnar28112013@gmail.com', 'sumit khairnar', '47,baliran peth near durga devi temple khairnar tailors', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(102, 96, '', 1493855136, 140, 0, NULL, 0, '', 0, '', '', '', 'sumit khairnar', '47, baliram peth near durga devi temple khairnar tailours', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', 'sumitkhairnar28112013@gmail.com', 'sumit khairnar', '47, baliram peth near durga devi temple khairnar tailours', 'India', 'maharastra', 'jalgaon', '425001', '9422217090', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(103, 97, '', 484242819, 142, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(104, 98, '', 1330958190, 150, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(105, 99, '', 982789275, 31, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(106, 100, '', 396082724, 107, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(108, 101, '', 611670113, 145, 0, NULL, 0, '', 0, '', '', '', 'rupesh bachhav', 'Sinhastha nagar cidco nashik', 'India', 'maharashtra', 'nashik', '422009', '9890481567', 'rupeshbachhav1993@gmail.com', 'rupesh bachhav', 'Sinhastha nagar cidco nashik', 'India', 'maharashtra', 'nashik', '422009', '9890481567', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(109, 102, '', 1127208656, 137, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(110, 103, '', 1391609470, 170, 0, NULL, 0, '', 0, '', '', '', 'vipul ukey', 'Pratap nagar road,gopal nagar,opp. Purrushottam kirna store,nagpur-440022', 'India', 'Maharashtra', 'Nagpur', '440022', '7875803963', 'vipul545@hotmail.com', 'vipul ukey', 'Pratap nagar road,gopal nagar,opp. Purrushottam kirna store,nagpur-440022', 'India', 'Maharashtra', 'Nagpur', '440022', '7875803963', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(111, 104, '', 894617199, 137, 0, NULL, 0, '', 0, '', '', '', 'Arnab MISHRA ', '8/2/20 Flat 4/C\r\nEast Kamlapur Aurbindo Sarani', 'India', 'WB', 'Kolkata', '700028', '9804444160', 'Arnab5944.mishra@gmail.com', 'Arnab MISHRA ', '8/2/20 Flat 4/C\r\nEast Kamlapur Aurbindo Sarani', 'India', 'WB', 'Kolkata', '700028', '9804444160', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(112, 105, '', 1175891689, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(113, 106, '', 17212839, 169, 0, NULL, 0, '', 0, '', '', '', 'xavier', 'C-6/119 yamuna vihar', 'India', 'delhi', 'delhi', '110053', '8802717115', 'xxgomes@gmail.com', 'xavier', 'C-6/119 yamuna vihar', 'India', 'delhi', 'delhi', '110053', '8802717115', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(114, 107, '', 1931595566, 142, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(115, 108, '', 185980790, 200, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(116, 109, '', 1985434096, 122, 0, NULL, 0, '', 0, '', '', '', 'Vikas singh', 'site #22,23 Tower- c ground floor DLF IT PARK Kishangarh Chandigarh', 'India', 'punjab', 'Chandigarh', '160101', '9878245290', 'vs851815@gmail.com', 'Vikas singh', 'site #22,23 Tower- c ground floor DLF IT PARK Kishangarh Chandigarh', 'India', 'punjab', 'Chandigarh', '160101', '9878245290', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(117, 110, '', 1352843409, 141, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(118, 111, '', 1792011474, 122, 0, NULL, 0, '', 0, '', '', '', '9878245290', 'site #22,23 Tower-c first floor DLF IT PARK Kishangarh Chandigarh', 'India', '160101', 'CHANDIGARH', '160101', '9878245290', 'Vikas Singh', '9878245290', 'site #22,23 Tower-c first floor DLF IT PARK Kishangarh Chandigarh', 'India', '160101', 'CHANDIGARH', '160101', '9878245290', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(119, 112, '', 241583251, 141, 0, NULL, 0, '', 0, '', '', '', 'Danish Kalra', 'Income Tax Officers Quarters, Building No. 24, Flat No. 302, Near Mega Mall, Oshiwara, Andheri West', 'India', 'Maharashtra', 'Mumbai', '400053', '09167253516', 'hi2dan@gmail.com', 'Danish Kalra', 'Income Tax Officers Quarters, Building No. 24, Flat No. 302, Near Mega Mall, Oshiwara, Andheri West', 'India', 'Maharashtra', 'Mumbai', '400053', '09167253516', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(120, 113, '', 1684057155, 123, 0, NULL, 0, '', 0, '', '', '', '9878245290', 'DLF IT PARK CHANDIGARH', 'India', 'Chandigarh', '160101', '9878245290', 'chandigarh', 'Vikas singh', '9878245290', 'DLF IT PARK CHANDIGARH', 'India', 'Chandigarh', '160101', '9878245290', 'chandigarh', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(121, 114, '', 1478900274, 170, 0, NULL, 0, '', 0, '', '', '', 'Sahil ahuja', '99-E pocket-K sheikh sarai-2 new delhi-110017', 'India', 'Delhi', 'New delhi', '110017', '9873564162', 'sahilahuja1997@gmail.com', 'Sahil ahuja', '99-E pocket-K sheikh sarai-2 new delhi-110017', 'India', 'Delhi', 'New delhi', '110017', '9873564162', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(122, 115, '', 1355606460, 189, 0, NULL, 0, '', 0, '', '', '', 'Chetan Dalal', '208, sector 15', 'India', 'haryana', 'faridabad', '121007', '8585975789', 'chetan.dalal@hotmail.com', 'Chetan Dalal', '208, sector 15', 'India', 'haryana', 'faridabad', '121007', '8585975789', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(123, 116, '', 256079103, 170, 0, NULL, 0, '', 0, '', '', '', 'Sahil ahuja', 'Jjajakkah982hhsE', 'India', 'Delhi', 'New delhi', '110017', '9873564162', 'sahilahuja1997@gmail.com', 'Sahil ahuja', 'Jjajakkah982hhsE', 'India', 'Delhi', 'New delhi', '110017', '9873564162', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(124, 117, '', 2007791087, 170, 0, NULL, 0, '', 0, '', '', '', 'sahil ahuja', '99-E,Pocket-K, Sheikh Sarai -2, new delhi-110017', 'India', 'delhi', 'new delhi', '110017', '9873564162', 'sahilahuja1997@gmail.com', 'sahil ahuja', '99-E,Pocket-K, Sheikh Sarai -2, new delhi-110017', 'India', 'delhi', 'new delhi', '110017', '9873564162', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(125, 118, '', 1923828072, 200, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(126, 119, '', 1015290866, 137, 0, NULL, 0, '', 0, '', '', '', 'arnab mishra', '8/2/20,flat 4/c,arbindo sarani east kamalapur dum dum near airport 1no gate', 'India', 'west bengal', 'kolkata', '700028', '9804444160', 'arnab5944.mishra@gmail.com', 'arnab mishra', '8/2/20,flat 4/c,arbindo sarani east kamalapur dum dum near airport 1no gate', 'India', 'west bengal', 'kolkata', '700028', '9804444160', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(128, 121, '', 1134774914, 152, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(129, 122, '', 1220337375, 215, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(131, 123, '', 363692822, 212, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(132, 123, '', 363692822, 217, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(133, 15, '', 1227934289, 32, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(134, 124, '', 1842861506, 217, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(135, 125, '', 1757880341, 225, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0),
(136, 126, '', 2020260975, 225, 0, NULL, 0, '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE IF NOT EXISTS `order_detail` (
  `id` int(11) NOT NULL auto_increment,
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float NOT NULL,
  `memid` int(11) NOT NULL,
  `coupon_code` varchar(50) collate latin1_general_ci NOT NULL,
  `discount` int(2) NOT NULL,
  `product_price` float NOT NULL,
  `sub_price` float NOT NULL,
  `ordid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=137 ;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `orderid`, `productid`, `quantity`, `price`, `memid`, `coupon_code`, `discount`, `product_price`, `sub_price`, `ordid`) VALUES
(1, 2116425965, 171, 1, 1149, 1, '', 0, 1149, 0, 0),
(2, 458767803, 202, 1, 4349, 2, '', 0, 4349, 0, 0),
(3, 1808048377, 202, 1, 4349, 3, '', 0, 4349, 0, 0),
(4, 1996213687, 200, 1, 3350, 4, '', 0, 3350, 0, 0),
(5, 1469198350, 200, 1, 3350, 5, '', 0, 3350, 0, 0),
(6, 765074627, 200, 1, 3350, 6, '', 0, 3350, 0, 0),
(7, 170182940, 150, 1, 2788, 7, '', 0, 2788, 0, 0),
(8, 531660564, 83, 1, 1499, 8, '', 0, 1499, 0, 0),
(9, 198422057, 143, 2, 1110, 9, '', 0, 1110, 0, 0),
(10, 1549934533, 120, 1, 3550, 10, '', 0, 3550, 0, 0),
(11, 682356705, 54, 1, 4488, 11, '', 0, 4488, 0, 0),
(12, 1051002270, 135, 1, 2450, 12, '', 0, 2450, 0, 0),
(13, 962108637, 170, 1, 1169, 13, '', 0, 1169, 0, 0),
(14, 1455205022, 195, 1, 3199, 14, '', 0, 3199, 0, 0),
(15, 768741879, 153, 1, 2750, 15, '', 0, 2750, 0, 0),
(16, 229924833, 135, 1, 2450, 16, '', 0, 2450, 0, 0),
(18, 826584593, 53, 1, 4375, 18, '', 0, 4375, 0, 0),
(19, 826584593, 103, 1, 5049, 18, '', 0, 5049, 0, 0),
(20, 183744004, 26, 1, 4638, 19, '', 0, 4638, 0, 0),
(21, 748689732, 122, 1, 4530, 20, '', 0, 4530, 0, 0),
(22, 246978256, 82, 1, 2944, 21, '', 0, 2944, 0, 0),
(24, 783474763, 130, 1, 4099, 23, '', 0, 4099, 0, 0),
(25, 1316964844, 127, 1, 6250, 24, '', 0, 6250, 0, 0),
(26, 1739792698, 146, 1, 2180, 25, '', 0, 2180, 0, 0),
(27, 96134998, 147, 1, 2180, 26, '', 0, 2180, 0, 0),
(28, 1626765217, 146, 1, 2180, 27, '', 0, 2180, 0, 0),
(29, 1372354254, 32, 1, 5154, 28, '', 0, 5154, 0, 0),
(30, 1426874082, 122, 1, 4530, 29, '', 0, 4530, 0, 0),
(31, 1460618702, 31, 1, 5154, 30, '', 0, 5154, 0, 0),
(32, 1693458693, 141, 1, 4150, 31, '', 0, 4150, 0, 0),
(33, 1138095264, 146, 1, 2180, 32, '', 0, 2180, 0, 0),
(34, 595899227, 168, 1, 2381, 33, '', 0, 2381, 0, 0),
(35, 2070994464, 153, 1, 2750, 34, '', 0, 2750, 0, 0),
(36, 330947353, 141, 1, 4150, 35, '', 0, 4150, 0, 0),
(37, 1514480802, 209, 1, 1900, 36, '', 0, 1900, 0, 0),
(38, 124938256, 184, 1, 799, 37, '', 0, 799, 0, 0),
(39, 1056465202, 142, 1, 4150, 38, '', 0, 4150, 0, 0),
(40, 1738173740, 142, 1, 4150, 39, '', 0, 4150, 0, 0),
(41, 1409071340, 140, 1, 4150, 40, '', 0, 4150, 0, 0),
(42, 1592258528, 141, 1, 4150, 41, '', 0, 4150, 0, 0),
(43, 212780425, 145, 1, 1110, 42, '', 0, 1110, 0, 0),
(44, 1445331494, 124, 1, 4530, 43, '', 0, 4530, 0, 0),
(45, 1763343541, 39, 1, 9999, 44, '', 0, 9999, 0, 0),
(46, 2068911939, 144, 1, 1110, 45, '', 0, 1110, 0, 0),
(47, 1007847909, 137, 1, 5150, 46, '', 0, 5150, 0, 0),
(48, 1638083937, 141, 1, 4150, 47, '', 0, 4150, 0, 0),
(49, 1948326755, 138, 1, 5150, 48, '', 0, 5150, 0, 0),
(50, 915042568, 135, 1, 2450, 49, '', 0, 2450, 0, 0),
(51, 1632701680, 140, 1, 4150, 50, '', 0, 4150, 0, 0),
(52, 1260362481, 142, 1, 4150, 51, '', 0, 4150, 0, 0),
(53, 1441926790, 142, 1, 4150, 52, '', 0, 4150, 0, 0),
(54, 111072435, 141, 1, 4150, 53, '', 0, 4150, 0, 0),
(55, 143311859, 144, 1, 1110, 54, '', 0, 1110, 0, 0),
(56, 153493709, 123, 1, 4530, 55, '', 0, 4530, 0, 0),
(57, 980742722, 141, 1, 4150, 56, '', 0, 4150, 0, 0),
(59, 375871737, 139, 1, 2450, 57, '', 0, 2450, 0, 0),
(60, 375871737, 145, 1, 1110, 57, '', 0, 1110, 0, 0),
(61, 1258331378, 170, 1, 1169, 58, '', 0, 1169, 0, 0),
(62, 900869039, 34, 1, 5154, 59, '', 0, 5154, 0, 0),
(63, 115334267, 170, 1, 1169, 60, '', 0, 1169, 0, 0),
(64, 2002728150, 144, 1, 1110, 61, '', 0, 1110, 0, 0),
(65, 667893518, 34, 1, 5154, 62, '', 0, 5154, 0, 0),
(66, 119954574, 195, 1, 3199, 63, '', 0, 3199, 0, 0),
(67, 1148654942, 148, 1, 2180, 64, '', 0, 2180, 0, 0),
(68, 743325656, 200, 1, 3350, 65, '', 0, 3350, 0, 0),
(73, 1440320934, 196, 2, 3749, 68, '', 0, 3749, 0, 0),
(72, 435671020, 64, 1, 6344, 67, '', 0, 6344, 0, 0),
(74, 1275343956, 141, 1, 4150, 69, '', 0, 4150, 0, 0),
(75, 1657837665, 138, 1, 5150, 70, '', 0, 5150, 0, 0),
(76, 1438827514, 202, 1, 4349, 71, '', 0, 4349, 0, 0),
(77, 58622440, 141, 1, 4150, 72, '', 0, 4150, 0, 0),
(78, 846498237, 49, 1, 2434, 73, '', 0, 2434, 0, 0),
(79, 1704868065, 144, 1, 1110, 74, '', 0, 1110, 0, 0),
(80, 1553463408, 155, 1, 5260, 75, '', 0, 5260, 0, 0),
(81, 7584427, 146, 1, 2180, 76, '', 0, 2180, 0, 0),
(82, 461788549, 119, 1, 2999, 77, '', 0, 2999, 0, 0),
(83, 1149302186, 48, 1, 2604, 78, '', 0, 2604, 0, 0),
(85, 665707648, 194, 5, 3450, 79, '', 0, 3450, 0, 0),
(86, 188575129, 141, 1, 4150, 80, '', 0, 4150, 0, 0),
(87, 865221982, 141, 1, 4150, 81, '', 0, 4150, 0, 0),
(88, 312916844, 141, 1, 4150, 82, '', 0, 4150, 0, 0),
(89, 310581829, 144, 1, 1110, 83, '', 0, 1110, 0, 0),
(90, 2067008401, 145, 1, 1110, 84, '', 0, 1110, 0, 0),
(91, 2103373466, 140, 1, 4150, 85, '', 0, 4150, 0, 0),
(92, 1457143716, 140, 1, 4150, 86, '', 0, 4150, 0, 0),
(93, 911359566, 201, 1, 5600, 87, '', 0, 5600, 0, 0),
(94, 1742699859, 140, 1, 4150, 88, '', 0, 4150, 0, 0),
(95, 410953988, 141, 1, 4150, 89, '', 0, 4150, 0, 0),
(96, 1092620855, 124, 1, 4530, 90, '', 0, 4530, 0, 0),
(97, 1919283614, 142, 1, 4150, 91, '', 0, 4150, 0, 0),
(98, 1572182872, 161, 1, 2313, 92, '', 0, 2313, 0, 0),
(99, 735473469, 140, 1, 4150, 93, '', 0, 4150, 0, 0),
(100, 1254876946, 171, 1, 1149, 94, '', 0, 1149, 0, 0),
(101, 1995817276, 140, 1, 4150, 95, '', 0, 4150, 0, 0),
(102, 1493855136, 140, 1, 4150, 96, '', 0, 4150, 0, 0),
(103, 484242819, 142, 1, 4150, 97, '', 0, 4150, 0, 0),
(104, 1330958190, 150, 1, 2788, 98, '', 0, 2788, 0, 0),
(105, 982789275, 31, 1, 5154, 99, '', 0, 5154, 0, 0),
(106, 396082724, 107, 1, 2429, 100, '', 0, 2429, 0, 0),
(108, 611670113, 145, 1, 1110, 101, '', 0, 1110, 0, 0),
(109, 1127208656, 137, 1, 5150, 102, '', 0, 5150, 0, 0),
(110, 1391609470, 170, 1, 1169, 103, '', 0, 1169, 0, 0),
(111, 894617199, 137, 1, 5150, 104, '', 0, 5150, 0, 0),
(112, 1175891689, 141, 1, 4150, 105, '', 0, 4150, 0, 0),
(113, 17212839, 169, 1, 1169, 106, '', 0, 1169, 0, 0),
(114, 1931595566, 142, 1, 4150, 107, '', 0, 4150, 0, 0),
(115, 185980790, 200, 1, 3350, 108, '', 0, 3350, 0, 0),
(116, 1985434096, 122, 1, 4530, 109, '', 0, 4530, 0, 0),
(117, 1352843409, 141, 1, 4150, 110, '', 0, 4150, 0, 0),
(118, 1792011474, 122, 1, 4530, 111, '', 0, 4530, 0, 0),
(119, 241583251, 141, 1, 4150, 112, '', 0, 4150, 0, 0),
(120, 1684057155, 123, 1, 4530, 113, '', 0, 4530, 0, 0),
(121, 1478900274, 170, 1, 1169, 114, '', 0, 1169, 0, 0),
(122, 1355606460, 189, 1, 3499, 115, '', 0, 3499, 0, 0),
(123, 256079103, 170, 1, 1169, 116, '', 0, 1169, 0, 0),
(124, 2007791087, 170, 1, 1169, 117, '', 0, 1169, 0, 0),
(125, 1923828072, 200, 1, 3350, 118, '', 0, 3350, 0, 0),
(126, 1015290866, 137, 1, 5150, 119, '', 0, 5150, 0, 0),
(128, 1134774914, 152, 1, 2514, 121, '', 0, 2514, 0, 0),
(129, 1220337375, 215, 1, 350, 122, '', 0, 350, 0, 0),
(131, 363692822, 212, 1, 350, 123, '', 0, 350, 0, 0),
(132, 363692822, 217, 1, 350, 123, '', 0, 350, 0, 0),
(133, 1227934289, 32, 3, 0, 15, '', 0, 0, 0, 0),
(134, 1842861506, 217, 1, 350, 124, '', 0, 350, 0, 0),
(135, 1757880341, 225, 1, 350, 125, '', 0, 350, 0, 0),
(136, 2020260975, 225, 1, 350, 126, '', 0, 350, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_mem`
--

CREATE TABLE IF NOT EXISTS `order_mem` (
  `id` int(11) NOT NULL auto_increment,
  `DateCreated` varchar(255) NOT NULL,
  `PaymentID` varchar(255) NOT NULL,
  `orderid` varchar(255) NOT NULL default '0',
  `memid` int(11) NOT NULL default '0',
  `ShippingOption` int(10) NOT NULL default '0',
  `date` varchar(255) NOT NULL default '',
  `shipped` char(1) character set latin1 collate latin1_bin NOT NULL default '',
  `status` int(1) NOT NULL default '0',
  `intPaid` int(1) NOT NULL default '0',
  `itemprice` float NOT NULL default '0',
  `shipprice` float NOT NULL default '0',
  `Packingprice` float NOT NULL default '0',
  `comment` text NOT NULL,
  `paymenttype` varchar(255) NOT NULL,
  `paystatus` varchar(255) NOT NULL,
  `txid` varchar(255) NOT NULL,
  `payer_eid` varchar(255) NOT NULL,
  `payer_st` varchar(255) NOT NULL,
  `paydate` datetime NOT NULL,
  `cookieId` varchar(255) NOT NULL,
  `cvccharge` varchar(255) NOT NULL,
  `coupons_id` varchar(255) NOT NULL,
  `pdscount` varchar(255) NOT NULL,
  `discountrs` int(22) NOT NULL,
  `se_brow_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `shipby` varchar(255) NOT NULL,
  `awbno` varchar(255) NOT NULL,
  `delname` varchar(255) NOT NULL,
  `deldate` varchar(255) NOT NULL,
  `othership` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `productinfo` varchar(255) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(70) NOT NULL,
  `country` varchar(70) NOT NULL,
  `zipcode` varchar(15) NOT NULL,
  `udf1` varchar(100) NOT NULL,
  `udf2` varchar(100) NOT NULL,
  `udf3` varchar(100) NOT NULL,
  `udf4` varchar(100) NOT NULL,
  `udf5` varchar(100) NOT NULL,
  `pg` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `order_mem`
--

INSERT INTO `order_mem` (`id`, `DateCreated`, `PaymentID`, `orderid`, `memid`, `ShippingOption`, `date`, `shipped`, `status`, `intPaid`, `itemprice`, `shipprice`, `Packingprice`, `comment`, `paymenttype`, `paystatus`, `txid`, `payer_eid`, `payer_st`, `paydate`, `cookieId`, `cvccharge`, `coupons_id`, `pdscount`, `discountrs`, `se_brow_id`, `name`, `email`, `phone`, `shipby`, `awbno`, `delname`, `deldate`, `othership`, `mobile`, `productinfo`, `lastname`, `address1`, `address2`, `city`, `state`, `country`, `zipcode`, `udf1`, `udf2`, `udf3`, `udf4`, `udf5`, `pg`) VALUES
(3, '', '', '1808048377', 3, 0, '1417106360', '', 0, 0, 4349, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Ravi rathee', 'ravi_rathee22@yahoo.com', '', '', '', '', '', '', '7042828711', 'MuscleTech Push 10, Fruit Punch 1.1 lb                  \r\n                  ', '', 'Sf 41 Svk', '', 'Ggn', 'Hry', 'India', '122001', '', '', '', '', '', ''),
(2, '', '', '458767803', 2, 0, '1417098366', '1', 1, 1, 4349, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Manish Dua', 'manish@gapinfotech.com', '', '', '', '', '', '', '07503024770', 'MuscleTech Push 10, Fruit Punch 1.1 lb                  \r\n                  ', '', 'SF-37, Second Floor, Sushant Vyapar Kendra,\r\nSushant Lok-1, Near Huda City Center Metro Station,', '', 'Gurgaon', 'Haryana', 'India', '122002', '', '', '', '', '', ''),
(4, '', '', '1996213687', 4, 0, '1417155312', '', 0, 0, 3350, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Ravi Ranjna', 'ranjan.ravi.ravi2@gmail.com', '', '', '', '', '', '', '9555349579', 'Bpi 1.M.R Vortex                  \r\n                  ', '', 'H.no-57a,kotla Vihar Phase 2\r\nDelhi', '', 'Delhi', 'Delhi', 'India', '110041', '', '', '', '', '', ''),
(5, '', '', '1469198350', 5, 0, '1417198191', '', 0, 0, 3350, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Ravi rather', 'ravi.rathee22@gmail.com', '', '', '', '', '', '', '7042818711', 'Bpi 1.M.R Vortex                  \r\n                  ', '', 'Sf 41 Svk', '', 'Gurgaon', 'Haryana', 'India', '122001', '', '', '', '', '', ''),
(6, '', '', '531660564', 8, 0, '1417506626', '', 0, 0, 1499, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'ravi rathee', 'ravi_rathee22@YAHOO.COM', '', '', '', '', '', '', '7042828711', 'ON (Optimum Nutrition) Gold Standard 100% Whey Protein, Double Rich Chocolate 5 lb                  \r\n                  ', '', 'sf 41 svk', '', 'gurgaon', 'haryana', 'India', '122001', '', '', '', '', '', ''),
(7, '', '', '198422057', 9, 0, '1418219006', '', 0, 0, 2220, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'dip chatterjee', 'dip5300@gmail.com', '', '', '', '', '', '', '9038214762', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'B004, SALT LAKE, CITY CENTRE, KOLKATA - 700064.', '', 'KOLKATA', 'WEST BENGAL', 'India', '700064', '', '', '', '', '', ''),
(8, '', '', '682356705', 11, 0, '1418391659', '', 0, 0, 4488, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Alpha1, Beta0, Delhi', 'ashuin27@yahoo.com', '', '', '', '', '', '', '09876543210', 'MuscleTech Phase 8, Strawberry                   \r\n                  ', '', 'Alpha1, Beta0, Delhi', '', 'Delhi', 'Delhi', 'India', '110001', '', '', '', '', '', ''),
(9, '', '', '229924833', 16, 0, '1419396067', '', 0, 0, 2450, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Shrikant', 'shrikantdalvi046@yahoo.in', '', '', '', '', '', '', '8454872121', 'Ultimate Nutrition Muscle Juice Revolution 2600,                   \r\n                  ', '', 'Kannamwar nagar 1 , Bldg no. 175 , Room no. 5987 , Vikhroli East', '', 'Mumbai', 'Maharashtra', 'India', '400083', '', '', '', '', '', ''),
(10, '', '', '748689732', 20, 0, '1420177100', '', 0, 0, 4530, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'ankush yadav', 'ankushyadav4149@gmail.com', '', '', '', '', '', '', '7350076993', 'MuscleTech 100 % Premium Mass Gainer,                   \r\n                  ', '', '\r\nc/o Ramesh more near gosavi Conley ganesh Nagar Amravati', '', 'amravati', 'Maharashtra', 'India', '444607', '', '', '', '', '', ''),
(11, '', '', '246978256', 21, 0, '1420378847', '', 0, 0, 2944, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Rajiv B Tayade ', 'rajiv.tayade@gmail.com ', '', '', '', '', '', '', '9923133441 ', 'ON (Optimum Nutrition) Gold Standard 100% Whey Protein, Double Rich Chocolate 5 lb                  \r\n                  ', '', '44, Bhumiputra colony, Near congress nagar, old bye pass road, Amravati - Maharashtra ', '', 'Amravati ', 'Maharashtra ', 'India', '444606', '', '', '', '', '', ''),
(12, '', '', '96134998', 26, 0, '1422195808', '', 0, 0, 2180, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Ayoob Hameed', 'ayoobhameed12345@gmail.com', '', '', '', '', '', '', '8606507035', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Chaliparambu house', '', 'Ernakulam', 'Kerala', 'India', '682021', '', '', '', '', '', ''),
(13, '', '', '1426874082', 29, 0, '1422593450', '', 0, 0, 4530, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Livinson', 'Livins.n005@gmail.com', '', '', '', '', '', '', '7208661245', 'MuscleTech 100 % Premium Mass Gainer,                   \r\n                  ', '', 'RM_7, Bharthi CHAWL(1),\r\nBehind vallabh bldg,\r\nOpp police station.\r\nDharavi.', '', 'Mumbai', 'Maharashtra', 'India', '400017', '', '', '', '', '', ''),
(14, '', '', '1460618702', 30, 0, '1422726155', '', 0, 0, 5154, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'yuvraj pillay', 'yuvraj.m6857@gmail.com', '', '', '', '', '', '', '7385973727', 'Ultimate Nutrition Prostar 100% Whey Protein                  \r\n                  ', '', 'Sr no 21/b1 ganesh nagar road no 4 bhopkhel pune 31', '', 'pune', 'maharastra', 'India', '411031', '', '', '', '', '', ''),
(15, '', '', '1138095264', 32, 0, '1422979956', '', 0, 0, 2180, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'vishal', 'vishalchauhancr7@gmail.com', '', '', '', '', '', '', '9886588749', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'c/0 ss mushannavar house no.15, near kattimanglamma temple, lingraj nagar, vidyanagar,hubli 580031', '', 'hubli', 'karnataka', 'India', '580031', '', '', '', '', '', ''),
(16, '', '', '595899227', 33, 0, '1423030777', '', 0, 0, 2381, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Anoop Yadav', 'anoopyadav7477@yahoo.com', '', '', '', '', '', '', '9953728812', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', 'Maruti suzuki  gate no. 4  sec.8  IMT Manesar', '', 'Gurgaon', 'Haryana', 'India', '123503', '', '', '', '', '', ''),
(17, '', '', '1738173740', 39, 0, '1425381599', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Jaymal Modhwadiya', 'Jaltheillusionist@gmail.com', '', '', '', '', '', '', '9824079593', 'SSN Anabolic Muscle Builder XXXL,  (Strawberry- 11lb)                 \r\n                  ', '', 'D-5\r\nAditinagar\r\nOpp- Mastaram Chambers\r\nMaduram', '', 'Junagadh', 'Gujarat', 'India', '362001', '', '', '', '', '', ''),
(18, '', '', '212780425', 42, 0, '1425920213', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'haider ali', 'haider.alixr007@gmail.com ', '', '', '', '', '', '', '7860877776', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Nanak nagar thakurganj near arma nursing home', '', 'lucknow', 'up', 'India', '226003', '', '', '', '', '', ''),
(19, '', '', '1445331494', 43, 0, '1425983043', '', 0, 0, 4530, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'samir', 'samirkhan07861@yahoo.com', '', '', '', '', '', '', '9136830501', 'MuscleTech 100 % Premium Mass Gainer,                   \r\n                  ', '', 'House no.953,street no.30,jaffrabad,near kashmiri building ,new seelampur ,Delhi-110053', '', 'delhi', 'delhi', 'India', '110053', '', '', '', '', '', ''),
(20, '', '', '1763343541', 44, 0, '1426500329', '', 0, 0, 9999, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'rs s', 'shyantyrahul@gmail.com', '', '', '', '', '', '', '08860087782', 'Ultimate Nutrition Prostar 100% Whey Protein                  \r\n                  ', '', 'dd\r\n3', '', 'delhi', 'Delhi', 'India', '110052', '', '', '', '', '', ''),
(21, '', '', '2068911939', 45, 0, '1427129234', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'abhhishek mitra', 'anilko1986@gmail.com', '', '', '', '', '', '', '9833949432', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'lords and melbourne hostel near sanjeevani school sector 19 kharghar', '', 'NAVI MUMBAI', 'Mumbai', 'India', '410210', '', '', '', '', '', ''),
(22, '', '', '1638083937', 47, 0, '1427256884', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Rajesh gopalakrishnan', 'renjini_nairn@yahoo.co.in', '', '', '', '', '', '', '9689845858', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'E-903 \r\nTrillium\r\nMagarpatta\r\nPune-411013', '', 'Magarpatta', 'Maharashtra', 'India', '411013', '', '', '', '', '', ''),
(23, '', '', '1948326755', 48, 0, '1427643398', '', 0, 0, 5150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Vanshaj Vk', 'vkvanshaj@gmail.com', '', '', '', '', '', '', '9988667284', 'Ultimate Nutrition Muscle Juice Revolution 2600,                   \r\n                  ', '', 'room no. 317 le corbusier hostel - D\r\nNH95 Chandigarh University Gharuan ', '', 'Gharuan', 'Punjab', 'India', '140413', '', '', '', '', '', ''),
(24, '', '', '1632701680', 50, 0, '1427743993', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'ponkil hazarika', 'ponkilhazarika38@gmail.com', '', '', '', '', '', '', '8402803991', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'A type 718 oil colony near old post office ', '', 'duliajan', 'assam', 'India', '786602', '', '', '', '', '', ''),
(25, '', '', '1260362481', 51, 0, '1427796260', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'ponkil hazarika', 'ronirajkonwar@gmail.com', '', '', '', '', '', '', '8402803991', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'A type 718 oil colony near old post office', '', 'duliajan', 'assam', 'India', '786602', '', '', '', '', '', ''),
(26, '', '', '1441926790', 52, 0, '1427795821', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Ponkil Hazarika', 'ponkilhazarika38@gmail.com', '', '', '', '', '', '', '8402803991', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'A type 718 oil colony near old post office ', '', 'Duliajan', 'Assam', 'India', '786602', '', '', '', '', '', ''),
(27, '', '', '111072435', 53, 0, '1427797849', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'ponkil hazarika', 'ronirajkonwar@Gmail.com', '', '', '', '', '', '', '8402803991 ', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'A type 718 oil colony near old post office', '', 'Duliajan', 'Assam', 'India', '786602', '', '', '', '', '', ''),
(28, '', '', '143311859', 54, 0, '1427954945', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Rohan Mittal', 'rohanmittal21@gmail.com', '', '', '', '', '', '', '7383335061', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'A-28, FOPE Hostel, RIL Saraswati Township, Near Welspun Company, Village:Vadadala, Taluka:Vagra, Dahej \r\nBharuch, Gujarat - 392130', '', 'Bharuch', 'Gujarat', 'India', '392130', '', '', '', '', '', ''),
(29, '', '', '980742722', 56, 0, '1428342584', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Karthik U L', 'karthikul505@gmail.com', '', '', '', '', '', '', '9739905134', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'S/0 LAVAKUMAR U B ,#123 BAIRAVESHWARA NILAYA\r\n2ND LBS NAGAR SOWLANGA ROAD SHIMOGA', '', 'Shimoga', 'karnataka', 'India', '577204', '', '', '', '', '', ''),
(30, '', '', '375871737', 57, 0, '1428351731', '', 0, 0, 3560, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Denny George', 'loldennygeorge@gmail.com', '', '', '', '', '', '', '8879890856', 'Ultimate Nutrition Muscle Juice Revolution 2600, ,SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Symbiosis Vishwabhavan Boys Hostel SB Road hanuman Nagar , Pune, 411016', '', 'Pune', 'Maharashtra', 'India', '411016', '', '', '', '', '', ''),
(31, '', '', '1258331378', 58, 0, '1428357748', '', 0, 0, 1169, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Ashish', 'ak39576@gmail.com', '', '', '', '', '', '', '7503912754', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', 'H-1590, gali no- 44,B-block, hanumaan kunj , banagali colony, sant nagar burari', '', 'delhi', 'new delhi', 'India', '110084', '', '', '', '', '', ''),
(32, '', '', '2002728150', 61, 0, '1429098207', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Kaushik Baria', 'kaushikbaria@gmail.com', '', '', '', '', '', '', '9722240633', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'C/18, Neelkantheswar soc. ', '', 'Vadodara', 'Gujarat', 'India', '390024', '', '', '', '', '', ''),
(33, '', '', '1148654942', 64, 0, '1429501338', '', 0, 0, 2180, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Prasad Mundhe', 'prasad.mundhe@ymail.com', '', '', '', '', '', '', '9850785587', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '77/2, C, Karan Bharati Apt., Flat no -22, Behind Bharati Vidyapeeth, Near Ichhapurti Mandir, Katraj,', '', 'Pune', 'Maharashtra', 'India', '411046', '', '', '', '', '', ''),
(34, '', '', '169470972', 66, 0, '1429689157', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Dilip Kumar', 'dots.dilip@gmail.com', '', '', '', '', '', '', '9835094339', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Sec 3A, Qtr No 600', '', 'Bokaro Steel City', 'Jharkhand', 'India', '827003', '', '', '', '', '', ''),
(35, '', '', '1275343956', 69, 0, '1429890570', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'divyasagar', 'jalakamdivyasagar@gmail.com', '', '', '', '', '', '', '919703084000', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '10-3-208c kota kommala street', '', 'tirupathi', 'Andhra Pradesh', 'India', '517501', '', '', '', '', '', ''),
(36, '', '', '1657837665', 70, 0, '1430293742', '', 0, 0, 5150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sandip sharma', '1941988@gmail.com', '', '', '', '', '', '', '7602585334', 'Ultimate Nutrition Muscle Juice Revolution 2600,                   \r\n                  ', '', 'M/s Mewar Marbles.Beside faridpur police station..faridpur..durgapur ', '', 'durgapur', 'West bengal', 'India', '713213', '', '', '', '', '', ''),
(37, '', '', '846498237', 73, 0, '1430822665', '', 0, 0, 2434, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Dr.kamal Dholakia', 'drkddholakia@yahoo.com', '', '', '', '', '', '', '9824800235', 'Ultimate Nutrition Prostar 100% Whey Protein                  \r\n                  ', '', '7,orient colony\r\n\r\nOpp. V.D. highschool', '', 'Bhuj', 'Gujarat', 'India', '370001', '', '', '', '', '', ''),
(38, '', '', '1704868065', 74, 0, '1430878183', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sachin khillare', 'neo5792@gmail.com', '', '', '', '', '', '', '8983340392', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Tanaji nagar ward no 20,\r\nJaiswal ley out,\r\nNear buddha vihar', '', 'buldhana', 'Maharashtra', 'India', '443001', '', '', '', '', '', ''),
(39, '', '', '188575129', 80, 0, '1431135401', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Karthik R Kamath', 'karthikkamath1992@gmail.com', '', '', '', '', '', '', '7259747491', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '#86, 4th cross ganapathi nagar laggere peenya, Near BGS school Bangalore 58', '', 'Bangalore', 'Karnataka', 'India', '560058', '', '', '', '', '', ''),
(40, '', '', '312916844', 82, 0, '1431157896', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Karthik Kamath', 'karthikkamath1992@gmail.com', '', '', '', '', '', '', '7259747491', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '86,4th Cross Ganapathi Nagar Near BGS school Laggere Peenya Bangalore 58', '', 'Bangalore', 'Karnataka', 'India', '560058', '', '', '', '', '', ''),
(41, '', '', '310581829', 83, 0, '1431279578', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Mayur S Mankar', 'mankarmayur0@gmail.com', '', '', '', '', '', '', '8983253949', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'A-5, Kritika apartment, lane number 9, dahanukar colony', '', 'Pune', 'Maharashtra', 'India', '411029', '', '', '', '', '', ''),
(42, '', '', '2067008401', 84, 0, '1431340986', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sachin khillare', 'neo5792@gmail.com', '', '', '', '', '', '', '8983340392', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Tanaji nagar, ward no 20\r\nJaiswal ley out, near buddha vihar,\r\nBuldhana', '', 'buldhana', 'Maharashtra', 'India', '443001', '', '', '', '', '', ''),
(43, '', '', '2103373466', 85, 0, '1431412697', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sumit khairnar', 'sumitkhairnar2811@gmail.com', '', '', '', '', '', '', '9422217090', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '47,balirampeth near durga devi temple khairnar tailors', '', 'jalgaon', 'maharastra', 'India', '425001', '', '', '', '', '', ''),
(44, '', '', '1457143716', 86, 0, '1431413623', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sumit', 'sumitkhairnar2811@gmail.com', '', '', '', '', '', '', '9422217090', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '47, baliram peth near durga devi temple, khairnar tailours', '', 'jalgaon', 'MAHARASHTRA', 'India', '425001', '', '', '', '', '', ''),
(45, '', '', '911359566', 87, 0, '1431450045', '', 0, 0, 5600, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'tghuik', 'aswert@gthyh.in', '', '', '', '', '', '', '7894561230', 'BPI Sports Whey-HD (5.37lbs)                  \r\n                  ', '', 'gthyh hhhhn', '', 'Gurgaon', 'Haryana', 'India', '122003', '', '', '', '', '', ''),
(46, '', '', '1919283614', 91, 0, '1431714128', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sidhant kapoor', 'sidhant.kpr@gmail.com', '', '', '', '', '', '', '9999479940', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'flat no. 8 nizamuddin east market, first floor. near nirankari bhavan ', '', 'New Delhi', 'Delhi', 'India', '110013', '', '', '', '', '', ''),
(47, '', '', '735473469', 93, 0, '1432360706', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sumit khairnar', 'sumitkhairnar2811@gmail.com', '', '', '', '', '', '', '9422217090', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '47, baliram peth near durga devi temple khairnar tailors ', '', 'jalgaon', 'maharastra', 'India', '425001', '', '', '', '', '', ''),
(48, '', '', '1254876946', 94, 0, '1432366987', '', 0, 0, 1149, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Swapnil mishra', 'Praveenmishrapm19@gmail.com', '', '', '', '', '', '', '8409501893', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', 'New area,jailhata', '', 'Daltonganj', 'Jharkhand', 'India', '822101', '', '', '', '', '', ''),
(49, '', '', '1995817276', 95, 0, '1432374650', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sumit khairnar', 'sumitkhairnar28112013@gmail.com', '', '', '', '', '', '', '9422217090', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '47,baliran peth near durga devi temple khairnar tailors', '', 'jalgaon', 'maharastra', 'India', '425001', '', '', '', '', '', ''),
(50, '', '', '1493855136', 96, 0, '1432479623', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sumit khairnar', 'sumitkhairnar28112013@gmail.com', '', '', '', '', '', '', '9422217090', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', '47, baliram peth near durga devi temple khairnar tailours', '', 'jalgaon', 'maharastra', 'India', '425001', '', '', '', '', '', ''),
(51, '', '', '611670113', 101, 0, '1433725622', '', 0, 0, 1110, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'rupesh bachhav', 'rupeshbachhav1993@gmail.com', '', '', '', '', '', '', '9890481567', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Sinhastha nagar cidco nashik', '', 'nashik', 'maharashtra', 'India', '422009', '', '', '', '', '', ''),
(52, '', '', '1391609470', 103, 0, '1434023056', '', 0, 0, 1169, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'vipul ukey', 'vipul545@hotmail.com', '', '', '', '', '', '', '7875803963', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', 'Pratap nagar road,gopal nagar,opp. Purrushottam kirna store,nagpur-440022', '', 'Nagpur', 'Maharashtra', 'India', '440022', '', '', '', '', '', ''),
(53, '', '', '894617199', 104, 0, '1434479197', '', 0, 0, 5150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Arnab MISHRA ', 'Arnab5944.mishra@gmail.com', '', '', '', '', '', '', '9804444160', 'Ultimate Nutrition Muscle Juice Revolution 2600,                   \r\n                  ', '', '8/2/20 Flat 4/C\r\nEast Kamlapur Aurbindo Sarani', '', 'Kolkata', 'WB', 'India', '700028', '', '', '', '', '', ''),
(54, '', '', '17212839', 106, 0, '1434713471', '', 0, 0, 1169, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'xavier', 'xxgomes@gmail.com', '', '', '', '', '', '', '8802717115', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', 'C-6/119 yamuna vihar', '', 'delhi', 'delhi', 'India', '110053', '', '', '', '', '', ''),
(55, '', '', '1985434096', 109, 0, '1435688810', '', 0, 0, 4530, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Vikas singh', 'vs851815@gmail.com', '', '', '', '', '', '', '9878245290', 'MuscleTech 100 % Premium Mass Gainer,                   \r\n                  ', '', 'site #22,23 Tower- c ground floor DLF IT PARK Kishangarh Chandigarh', '', 'Chandigarh', 'punjab', 'India', '160101', '', '', '', '', '', ''),
(56, '', '', '1792011474', 111, 0, '1435721561', '', 0, 0, 4530, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', '9878245290', 'Vikas Singh', '', '', '', '', '', '', '9878245290', 'MuscleTech 100 % Premium Mass Gainer,                   \r\n                  ', '', 'site #22,23 Tower-c first floor DLF IT PARK Kishangarh Chandigarh', '', 'CHANDIGARH', '160101', 'India', '160101', '', '', '', '', '', ''),
(57, '', '', '241583251', 112, 0, '1435760040', '', 0, 0, 4150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Danish Kalra', 'hi2dan@gmail.com', '', '', '', '', '', '', '09167253516', 'SSN Anabolic Muscle Builder XXXL,                   \r\n                  ', '', 'Income Tax Officers Quarters, Building No. 24, Flat No. 302, Near Mega Mall, Oshiwara, Andheri West', '', 'Mumbai', 'Maharashtra', 'India', '400053', '', '', '', '', '', ''),
(58, '', '', '1684057155', 113, 0, '1435734165', '', 0, 0, 4530, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', '9878245290', 'Vikas singh', '', '', '', '', '', '', 'chandigarh', 'MuscleTech 100 % Premium Mass Gainer,                   \r\n                  ', '', 'DLF IT PARK CHANDIGARH', '', '160101', 'Chandigarh', 'India', '9878245290', '', '', '', '', '', ''),
(59, '', '', '1478900274', 114, 0, '1435739056', '', 0, 0, 1169, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Sahil ahuja', 'sahilahuja1997@gmail.com', '', '', '', '', '', '', '9873564162', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', '99-E pocket-K sheikh sarai-2 new delhi-110017', '', 'New delhi', 'Delhi', 'India', '110017', '', '', '', '', '', ''),
(60, '', '', '1355606460', 115, 0, '1435740250', '', 0, 0, 3499, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Chetan Dalal', 'chetan.dalal@hotmail.com', '', '', '', '', '', '', '8585975789', 'Bpi A-Hd 112 G Or 28 Cap                  \r\n                  ', '', '208, sector 15', '', 'faridabad', 'haryana', 'India', '121007', '', '', '', '', '', ''),
(61, '', '', '256079103', 116, 0, '1435769320', '', 0, 0, 1169, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'Sahil ahuja', 'sahilahuja1997@gmail.com', '', '', '', '', '', '', '9873564162', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', 'Jjajakkah982hhsE', '', 'New delhi', 'Delhi', 'India', '110017', '', '', '', '', '', ''),
(62, '', '', '2007791087', 117, 0, '1435769924', '', 0, 0, 1169, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'sahil ahuja', 'sahilahuja1997@gmail.com', '', '', '', '', '', '', '9873564162', 'Universal Nutrition Gain Fast 3100,                  \r\n                  ', '', '99-E,Pocket-K, Sheikh Sarai -2, new delhi-110017', '', 'new delhi', 'delhi', 'India', '110017', '', '', '', '', '', ''),
(63, '', '', '1015290866', 119, 0, '1435775228', '', 0, 0, 5150, 0, 0, '', '', '', '', '', '', '0000-00-00 00:00:00', '', '', '', '', 0, '', 'arnab mishra', 'arnab5944.mishra@gmail.com', '', '', '', '', '', '', '9804444160', 'Ultimate Nutrition Muscle Juice Revolution 2600,                   \r\n                  ', '', '8/2/20,flat 4/c,arbindo sarani east kamalapur dum dum near airport 1no gate', '', 'kolkata', 'west bengal', 'India', '700028', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `otherfieldsproducts_tbl`
--

CREATE TABLE IF NOT EXISTS `otherfieldsproducts_tbl` (
  `id` int(100) NOT NULL auto_increment,
  `AuthorName` varchar(255) NOT NULL default '',
  `ISBN` varchar(255) NOT NULL default '',
  `Language` varchar(100) NOT NULL default '',
  `Publisher` varchar(255) NOT NULL default '',
  `Edition` varchar(100) NOT NULL default '',
  `Actor` varchar(255) NOT NULL default '',
  `Director` varchar(255) NOT NULL default '',
  `Singername` varchar(255) NOT NULL default '',
  `Ingredients` text NOT NULL,
  `Directions` text NOT NULL,
  `Lencetype` varchar(255) NOT NULL default '',
  `BatteryLife` varchar(255) NOT NULL default '',
  `BrandName` varchar(255) NOT NULL default '',
  `Electricityconsumption` varchar(100) NOT NULL default '',
  `warrenty` varchar(100) NOT NULL default '',
  `itemid` int(100) NOT NULL default '0',
  `catid` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `otherfieldsproducts_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `paymentrec_tbl`
--

CREATE TABLE IF NOT EXISTS `paymentrec_tbl` (
  `cid` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `cardtype` varchar(255) NOT NULL default '',
  `ccnumber` varbinary(255) NOT NULL default '',
  `expmonth` int(11) NOT NULL default '0',
  `expyear` int(11) NOT NULL default '0',
  `ownername` varchar(255) NOT NULL default '',
  `cvv_numver` varchar(20) NOT NULL default '',
  `verifieded` int(5) NOT NULL default '0',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paymentrec_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `photo_gallary`
--

CREATE TABLE IF NOT EXISTS `photo_gallary` (
  `p_id` bigint(20) NOT NULL auto_increment,
  `p_memid` varchar(255) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `p_img1` varchar(255) NOT NULL,
  `p_status` binary(1) NOT NULL,
  PRIMARY KEY  (`p_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `photo_gallary`
--


-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `mrpprice` varchar(255) NOT NULL,
  `products_id` int(11) NOT NULL auto_increment,
  `products_image2` varchar(255) NOT NULL,
  `products_image3` varchar(255) NOT NULL,
  `products_image4` varchar(255) NOT NULL,
  `products_image5` varchar(255) NOT NULL,
  `input_url` varchar(255) NOT NULL,
  `Seo_Project_Title` varchar(255) NOT NULL,
  `Seo_Project_Description` varchar(255) NOT NULL,
  `Seo_Project_Keyword` varchar(255) NOT NULL,
  `product_title` varchar(255) NOT NULL default '',
  `product_title1` varchar(255) NOT NULL,
  `product_make` varchar(255) NOT NULL default '',
  `products_model` varchar(255) default NULL,
  `products_image` varchar(64) default NULL,
  `products_price` varchar(255) NOT NULL,
  `products_oldprice` varchar(255) NOT NULL,
  `discountpercentage` int(11) NOT NULL default '0',
  `customerdiscount` int(100) NOT NULL default '0',
  `Description` text NOT NULL,
  `products_date_added` bigint(20) NOT NULL default '1',
  `products_last_modified` datetime default NULL,
  `products_date_available` datetime default NULL,
  `products_weight` float NOT NULL default '0',
  `products_status` tinyint(1) NOT NULL default '0',
  `products_offer` tinyint(1) NOT NULL default '0',
  `products_tax_class_id` int(11) NOT NULL default '0',
  `manufacturers_id` int(11) default NULL,
  `totalstock` int(11) NOT NULL default '0',
  `products_quantity_order_min` float NOT NULL default '1',
  `products_quantity_order_units` float NOT NULL default '1',
  `products_isFeatured` tinyint(1) NOT NULL default '0',
  `master_categories_id` int(11) NOT NULL default '0',
  `BestSeller` int(11) NOT NULL default '0',
  `Producttag` varchar(255) NOT NULL default '',
  `aveg_rating` int(11) NOT NULL default '0',
  `num_favorite` int(11) NOT NULL default '0',
  `viewtime` bigint(20) NOT NULL default '0',
  `shippingprice` int(11) NOT NULL default '0',
  `ShopCatid` int(100) NOT NULL default '0',
  `fes_discountpercentage` int(11) NOT NULL,
  `authorsummary` longtext NOT NULL,
  `author` varchar(255) NOT NULL,
  `sibn` varchar(255) NOT NULL,
  `npage` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `rarebooks` int(2) NOT NULL,
  `toysforage` varchar(255) NOT NULL,
  `stock` binary(1) NOT NULL,
  `dltime` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `materparrentid` varchar(255) NOT NULL,
  `shortdesc` longtext NOT NULL,
  `specification` longtext NOT NULL,
  `arg_ord` varchar(255) NOT NULL,
  `icon1` varchar(255) NOT NULL,
  `icon2` varchar(255) NOT NULL,
  `icon3` varchar(255) NOT NULL,
  `icon4` varchar(255) NOT NULL,
  `icon5` varchar(255) NOT NULL,
  `emdvedio` longtext NOT NULL,
  `specification2` longtext NOT NULL,
  `weight_qty` varchar(10) NOT NULL,
  `weight_unit` varchar(15) NOT NULL,
  `p_id` int(11) NOT NULL,
  `product_option_ids` varchar(255) NOT NULL,
  `product_option_field_array` varchar(255) NOT NULL,
  `gallery_image1` varchar(255) NOT NULL,
  `gallery_image2` varchar(255) NOT NULL,
  `gallery_image3` varchar(255) NOT NULL,
  `gallery_image4` varchar(255) NOT NULL,
  `multioption` int(1) NOT NULL default '0',
  `freeproduct` varchar(255) NOT NULL,
  PRIMARY KEY  (`products_id`),
  KEY `idx_products_date_added_zen` (`products_date_added`),
  KEY `idx_products_status_zen` (`products_status`),
  KEY `idx_products_date_available_zen` (`products_date_available`),
  KEY `idx_products_ordered_zen` (`totalstock`),
  KEY `idx_products_model_zen` (`products_model`),
  KEY `idx_master_categories_id_zen` (`master_categories_id`),
  KEY `idx_manufacturers_id_zen` (`manufacturers_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=231 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`mrpprice`, `products_id`, `products_image2`, `products_image3`, `products_image4`, `products_image5`, `input_url`, `Seo_Project_Title`, `Seo_Project_Description`, `Seo_Project_Keyword`, `product_title`, `product_title1`, `product_make`, `products_model`, `products_image`, `products_price`, `products_oldprice`, `discountpercentage`, `customerdiscount`, `Description`, `products_date_added`, `products_last_modified`, `products_date_available`, `products_weight`, `products_status`, `products_offer`, `products_tax_class_id`, `manufacturers_id`, `totalstock`, `products_quantity_order_min`, `products_quantity_order_units`, `products_isFeatured`, `master_categories_id`, `BestSeller`, `Producttag`, `aveg_rating`, `num_favorite`, `viewtime`, `shippingprice`, `ShopCatid`, `fes_discountpercentage`, `authorsummary`, `author`, `sibn`, `npage`, `cover`, `rarebooks`, `toysforage`, `stock`, `dltime`, `brand`, `materparrentid`, `shortdesc`, `specification`, `arg_ord`, `icon1`, `icon2`, `icon3`, `icon4`, `icon5`, `emdvedio`, `specification2`, `weight_qty`, `weight_unit`, `p_id`, `product_option_ids`, `product_option_field_array`, `gallery_image1`, `gallery_image2`, `gallery_image3`, `gallery_image4`, `multioption`, `freeproduct`) VALUES
('', 211, 'product_file/127521147602.jpg', 'product_file/127521147603.jpg', 'product_file/127521147604.jpg', 'product_file/127521147605.jpg', '', 'Fashion Fab Tee 1', '', '', 'Fashion Fab Tee 1', 'Fashion Fab Tee 1', '', '', 'product_file/127521147601.jpg', '350', '470', 0, 0, '', 1471669851, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 245, 0, '', 0, 0, 1482468606, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '62', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 211, '1', '89', '', '', '', '', 0, ''),
('', 212, '', '', '', '', '', 'Fashion Fab Tee 2', '', '', 'Fashion Fab Tee 2', 'Fashion Fab Tee 2', '', '', 'product_file/1026796860t2.jpg', '350', '470', 0, 0, '', 1470658911, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 245, 0, '', 0, 0, 1473167899, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '54', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 212, '1', '90', '', '', '', '', 0, ''),
('', 213, '', '', '', '', '', 'Fashion Fab Tee 3', '', '', 'Fashion Fab Tee 3', 'Fashion Fab Tee 3', '', '', 'product_file/673186804t3.jpg', '350', '470', 0, 0, '', 1470659320, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 245, 0, '', 0, 0, 1473157052, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '30', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 213, '1', '87', '', '', '', '', 0, ''),
('', 214, '', '', '', '', '', 'Fashion Fab Tee 4', '', '', 'Fashion Fab Tee 4', 'Fashion Fab Tee 4', '', '', 'product_file/415876565t5.jpg', '350', '470', 0, 0, '', 1470659343, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 245, 0, '', 0, 0, 1482468612, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '42', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 214, '1', '86', '', '', '', '', 0, ''),
('', 215, 'product_file/35478002702.jpg', 'product_file/35478002704.jpg', '', '', '', 'Women Top 1', '', '', 'Women Top 1', 'Women Top 1', '', '', 'product_file/35478002701.jpg', '350', '470', 0, 0, '', 1473162274, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473222697, 0, 0, 0, '<p>\r\n	Product Short Feature or description</p>\r\n', '', '', '', '', 0, '', '1', '', '48', '', '<p>\r\n	About Product</p>\r\n', '<p>\r\n	Product Specification</p>\r\n', '', '', '', '', '', '', '', '', '', '', 215, '1,2,5', '5,90,142', '', '', '', '', 0, ''),
('', 216, '', '', '', '', '', 'Fashion Fab Tee 5', '', '', 'Fashion Fab Tee 5', 'Fashion Fab Tee 5', '', '', 'product_file/453531046t4.jpg', '350', '470', 0, 0, '', 1470659964, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 245, 0, '', 0, 0, 1473160841, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '54', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 216, '1', '86', '', '', '', '', 0, ''),
('', 217, '', '', '', '', '', 'Women Top 2', '', '', 'Women Top 2', 'Women Top 2', '', '', 'product_file/451495701top2.jpg', '350', '470', 0, 0, '', 1470660051, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473161242, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '54', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 217, '1', '89', '', '', '', '', 0, ''),
('', 218, '', '', '', '', '', 'Women Top 3', '', '', 'Women Top 3', 'Women Top 3', '', '', 'product_file/790647326top3.jpg', '350', '470', 0, 0, '', 1470660089, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473161154, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '20', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 218, '1', '89', '', '', '', '', 0, ''),
('', 219, '', '', '', '', '', 'Women Top 4', '', '', 'Women Top 4', 'Women Top 4', '', '', 'product_file/194599250top4.jpg', '350', '470', 0, 0, '', 1470660115, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473074641, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '53', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 219, '1', '87', '', '', '', '', 0, ''),
('', 220, '', '', '', '', '', 'Women Top 5', '', '', 'Women Top 5', 'Women Top 5', '', '', 'product_file/244643387top5.jpg', '350', '470', 0, 0, '', 1470660170, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473161245, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '45', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 220, '1', '88', '', '', '', '', 0, ''),
('', 228, 'product_file/35478002702.jpg', 'product_file/35478002704.jpg', '', '', '', 'Women Top 1', '', '', 'Women Top 1', 'Women Top 1', '', '', 'product_file/35478002701.jpg', '350', '470', 0, 0, '', 1473162306, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473163681, 0, 0, 0, '<p>\r\n	Product Short Feature or description</p>\r\n', '', '', '', '', 0, '', '1', '', '48', '', '<p>\r\n	About Product</p>\r\n', '<p>\r\n	Product Specification</p>\r\n', '', '', '', '', '', '', '', '', '', '', 215, '1,2,5', '6,90,142', '', '', '', '', 0, ''),
('', 227, 'product_file/35478002702.jpg', 'product_file/35478002704.jpg', '', '', '', 'Women Top 1', '', '', 'Women Top 1', 'Women Top 1', '', '', 'product_file/35478002701.jpg', '350', '470', 0, 0, '', 1473162101, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473396163, 0, 0, 0, '<p>\r\n	Product Short Feature or description</p>\r\n', '', '', '', '', 0, '', '1', '', '48', '', '<p>\r\n	About Product</p>\r\n', '<p>\r\n	Product Specification</p>\r\n', '', '', '', '', '', '', '', '', '', '', 215, '1,2,5', '5,89,142', '', '', '', '', 0, ''),
('', 226, 'product_file/35478002702.jpg', 'product_file/35478002704.jpg', '', '', '', 'Women Top 1', '', '', 'Women Top 1', 'Women Top 1', '', '', 'product_file/35478002701.jpg', '350', '470', 0, 0, '', 1473162331, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473163686, 0, 0, 0, '<p>\r\n	Product Short Feature or description</p>\r\n', '', '', '', '', 0, '', '1', '', '48', '', '<p>\r\n	About Product</p>\r\n', '<p>\r\n	Product Specification</p>\r\n', '', '', '', '', '', '', '', '', '', '', 215, '1,2,5', '6,89,142', '', '', '', '', 0, ''),
('', 225, 'product_file/127521147602.jpg', 'product_file/127521147604.jpg', '', 'product_file/127521147605.jpg', '', 'Fashion Fab Tee 1', '', '', 'Fashion Fab Tee 1', 'Fashion Fab Tee 1', '', '', 'product_file/127521147601.jpg', '350', '470', 0, 0, '', 1471688930, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 245, 0, '', 0, 0, 1482468515, 0, 0, 0, '<br />\r\n', '', '', '', '', 0, '', '1', '', '62', '', '<br />\r\n', '<br />\r\n', '', '', '', '', '', '', '', '', '', '', 211, '', '', '', '', '', '', 0, ''),
('', 229, 'product_file/35478002702.jpg', 'product_file/35478002704.jpg', '', '', '', 'Women Top 1', '', '', 'Women Top 1', 'Women Top 1', '', '', 'product_file/35478002701.jpg', '350', '470', 0, 0, '', 1473162167, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473168031, 0, 0, 0, '<p>\r\n	Product Short Feature or description</p>\r\n', '', '', '', '', 0, '', '1', '', '48', '', '<p>\r\n	About Product</p>\r\n', '<p>\r\n	Product Specification</p>\r\n', '', '', '', '', '', '', '', '', '', '', 215, '1,2,5', '5,88,142', '', '', '', '', 0, ''),
('', 230, 'product_file/35478002702.jpg', 'product_file/35478002704.jpg', '', '', '', 'Women Top 1', '', '', 'Women Top 1', 'Women Top 1', '', '', 'product_file/35478002701.jpg', '350', '470', 0, 0, '', 1473162185, NULL, NULL, 0, 1, 1, 0, NULL, 0, 0, 1, 0, 246, 0, '', 0, 0, 1473224760, 0, 0, 0, '<p>\r\n	Product Short Feature or description</p>\r\n', '', '', '', '', 0, '', '1', '', '48', '', '<p>\r\n	About Product</p>\r\n', '<p>\r\n	Product Specification</p>\r\n', '', '', '', '', '', '', '', '', '', '', 215, '1,2,5', '6,88,142', '', '', '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `product_option`
--

CREATE TABLE IF NOT EXISTS `product_option` (
  `op_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`op_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `product_option`
--

INSERT INTO `product_option` (`op_id`, `name`) VALUES
(1, 'size'),
(2, 'color'),
(5, 'Fabric');

-- --------------------------------------------------------

--
-- Table structure for table `product_option_array`
--

CREATE TABLE IF NOT EXISTS `product_option_array` (
  `p_op_arr_id` int(11) NOT NULL auto_increment,
  `cat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_op_id` int(11) NOT NULL,
  `option_array` varchar(255) NOT NULL,
  PRIMARY KEY  (`p_op_arr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `product_option_array`
--


-- --------------------------------------------------------

--
-- Table structure for table `product_option_array_field`
--

CREATE TABLE IF NOT EXISTS `product_option_array_field` (
  `id` bigint(20) NOT NULL auto_increment,
  `p_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `subcat_id` int(11) NOT NULL,
  `p_op_id` int(11) NOT NULL,
  `product_option_ids` varchar(255) NOT NULL,
  `product_option_field_array` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `gallery_image1` varchar(255) NOT NULL,
  `gallery_image2` varchar(255) NOT NULL,
  `gallery_image3` varchar(255) NOT NULL,
  `gallery_image4` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `products_status` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `product_option_array_field`
--

INSERT INTO `product_option_array_field` (`id`, `p_id`, `cat_id`, `subcat_id`, `p_op_id`, `product_option_ids`, `product_option_field_array`, `price`, `gallery_image1`, `gallery_image2`, `gallery_image3`, `gallery_image4`, `product_image`, `products_status`) VALUES
(12, 1, 0, 0, 0, '1,2,3', '1,5,11', 1500, '', '', '', '', '', 1),
(10, 1, 0, 0, 0, '1,2,3', '1,6,11', 1800, '', '', '', '', '', 1),
(9, 1, 0, 0, 0, '1,2,3', '1,6,12', 1700, '', '', '', '', '', 1),
(8, 1, 0, 0, 0, '1,2,3', '2,5,12', 1550, '', '', '', '', '', 1),
(7, 1, 0, 0, 0, '1,3', '2,12', 1920, '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_option_field`
--

CREATE TABLE IF NOT EXISTS `product_option_field` (
  `id` int(11) NOT NULL auto_increment,
  `product_option_id` int(11) NOT NULL,
  `product_option_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=145 ;

--
-- Dumping data for table `product_option_field`
--

INSERT INTO `product_option_field` (`id`, `product_option_id`, `product_option_name`) VALUES
(90, 1, 'S'),
(89, 1, 'M'),
(5, 2, 'Red'),
(6, 2, 'Green'),
(88, 1, 'L'),
(87, 1, 'XL'),
(30, 3, 'Strawberry'),
(29, 3, 'Chocolate'),
(13, 3, 'Banana & Cream'),
(14, 3, 'Coffee'),
(15, 3, 'vanilla'),
(86, 1, 'XXL'),
(85, 1, 'XXXL'),
(31, 3, 'Banana'),
(32, 3, 'Cookie'),
(33, 3, 'Rocky Road'),
(34, 3, 'Vanilla Ice Cream'),
(35, 3, 'Cookiees & Cream'),
(36, 3, 'Double Rich Chocolate'),
(37, 3, 'French Vanilla Cream'),
(38, 3, 'Strawberry Banana'),
(39, 3, 'Mocha Capuccino'),
(40, 3, 'Coffee Mint'),
(41, 3, 'chocolate Mint'),
(42, 3, 'Chocolate Malt'),
(43, 3, 'Chocolate Penut Butter'),
(44, 3, 'Chocolate Cream'),
(45, 3, 'Lemon'),
(46, 3, 'Nutural'),
(47, 3, 'Cocoa Mocha'),
(48, 3, 'Ruspberry'),
(49, 3, 'Rum Raisin'),
(50, 3, 'Vanilla Cream'),
(51, 3, 'Cafe Mocha'),
(52, 3, 'Chocolate Fudge'),
(53, 3, 'Vanilla Bean'),
(54, 3, 'Unflavoured'),
(55, 3, 'Milk Chocolate'),
(56, 3, 'Delicious Vanilla'),
(57, 3, 'Cinnamon roll'),
(58, 3, 'Rich Chololate'),
(59, 3, 'Gourmet Vanilla'),
(60, 3, 'Chocolate Rocky roll'),
(61, 3, 'Vanilla Very Bery'),
(62, 3, 'Chocolate Hazelunt'),
(63, 3, 'Chocolate Cookies & Cream'),
(64, 3, 'Chocolate Ice Cream'),
(65, 3, 'Strawberry Ice Cream'),
(66, 3, 'Banana Ice Cream'),
(67, 3, 'Mocha Ccino'),
(68, 3, 'Choc Cake butter'),
(69, 3, 'Chocolate Charge'),
(70, 3, 'Killa Vanilla'),
(71, 3, 'Strawberry Siege'),
(72, 3, 'Coockies Khaos'),
(73, 3, 'Chocolate Monster'),
(74, 3, 'Vanilla Vafor Crisp'),
(75, 3, 'Chocolate Milk Shake'),
(76, 3, 'Strawberry Milk shake'),
(77, 3, 'Banana Milk Shake'),
(102, 3, 'Cafe Brazil'),
(109, 3, 'Water Melon Rage'),
(110, 3, 'Fruit Punch'),
(111, 3, 'Sucker Punch'),
(112, 3, 'Malicious Melon'),
(113, 3, 'Lunatic Lemonade'),
(114, 3, 'Bruisin Berry'),
(118, 3, 'Orange'),
(119, 3, 'Grape'),
(144, 5, 'Nylon'),
(143, 5, 'Silk'),
(142, 5, 'Cotton');

-- --------------------------------------------------------

--
-- Table structure for table `ratetbl`
--

CREATE TABLE IF NOT EXISTS `ratetbl` (
  `rateid` int(11) NOT NULL auto_increment,
  `total_votes` int(11) NOT NULL default '0',
  `total_value` int(11) NOT NULL default '0',
  `used_ips` varchar(255) NOT NULL default '',
  `id` varchar(11) NOT NULL default '0',
  `memid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`rateid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ratetbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(11) NOT NULL auto_increment,
  `mid` int(11) NOT NULL default '0',
  `phid` int(11) NOT NULL default '0',
  `points` float NOT NULL default '0',
  `adddate` bigint(20) NOT NULL default '0',
  `ipaddress` varchar(255) NOT NULL default '',
  `itemtype` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rating`
--


-- --------------------------------------------------------

--
-- Table structure for table `recentlyviewed`
--

CREATE TABLE IF NOT EXISTS `recentlyviewed` (
  `id` int(5) NOT NULL auto_increment,
  `ip` varchar(255) NOT NULL,
  `pid` varchar(255) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `nview` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `recentlyviewed`
--


-- --------------------------------------------------------

--
-- Table structure for table `sconfig`
--

CREATE TABLE IF NOT EXISTS `sconfig` (
  `id` int(11) NOT NULL auto_increment,
  `tag` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sconfig`
--

INSERT INTO `sconfig` (`id`, `tag`, `value`) VALUES
(1, 'BestSeller', '5'),
(2, 'FeaturedProduct', '1');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_tbl`
--

CREATE TABLE IF NOT EXISTS `shipping_tbl` (
  `sid` int(11) NOT NULL auto_increment,
  `memid` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `address1` varchar(255) NOT NULL default '',
  `address2` varchar(255) NOT NULL default '',
  `city` varchar(255) NOT NULL default '',
  `state` varchar(255) NOT NULL default '',
  `zipcode` varchar(20) NOT NULL default '',
  `country` varchar(255) NOT NULL default '',
  `phone1` varchar(255) NOT NULL default '',
  `phone2` varchar(255) NOT NULL default '',
  `std1` varchar(10) NOT NULL default '',
  `std2` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shipping_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `shoppercategory`
--

CREATE TABLE IF NOT EXISTS `shoppercategory` (
  `scid` int(11) NOT NULL auto_increment,
  `Spid` int(11) NOT NULL default '0',
  `shopid` int(11) NOT NULL default '0',
  `Scname` longtext NOT NULL,
  `status` int(4) NOT NULL default '0',
  `SCatImg` longtext NOT NULL,
  `SCatDesc` longtext NOT NULL,
  `adddate` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`scid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shoppercategory`
--


-- --------------------------------------------------------

--
-- Table structure for table `shopper_tbl`
--

CREATE TABLE IF NOT EXISTS `shopper_tbl` (
  `shopid` int(11) NOT NULL auto_increment,
  `shopusername` varchar(255) NOT NULL default '',
  `shoppass` varchar(255) NOT NULL default '',
  `shopname` varchar(255) NOT NULL default '',
  `shoptype` varchar(255) NOT NULL default '',
  `shopowner` varchar(255) NOT NULL default '',
  `shoplogo` varchar(255) NOT NULL default '',
  `shopphone` varchar(255) NOT NULL default '',
  `shopfax` varchar(255) NOT NULL default '',
  `shopemail` varchar(255) NOT NULL default '',
  `shopaddress` text NOT NULL,
  `shopcity` varchar(255) NOT NULL default '',
  `shopstate` varchar(255) NOT NULL default '',
  `shopcountry` int(11) NOT NULL default '0',
  `shopstatus` int(11) NOT NULL default '0',
  `shopfeatured` int(11) NOT NULL default '0',
  `adddate` bigint(20) NOT NULL default '0',
  `compdetail` text NOT NULL,
  `IsLebanon` int(4) NOT NULL default '0',
  `headercolor` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`shopid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shopper_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `sh_price`
--

CREATE TABLE IF NOT EXISTS `sh_price` (
  `id` int(4) NOT NULL auto_increment,
  `l_5` varchar(255) NOT NULL,
  `l_1000` varchar(255) NOT NULL,
  `l_1500` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sh_price`
--


-- --------------------------------------------------------

--
-- Table structure for table `subscribe_tbl`
--

CREATE TABLE IF NOT EXISTS `subscribe_tbl` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL default '',
  `status` binary(1) NOT NULL default '\0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `subscribe_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_homeenquiry`
--

CREATE TABLE IF NOT EXISTS `tbl_homeenquiry` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `message` varchar(255) NOT NULL,
  `msg_time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_homeenquiry`
--

INSERT INTO `tbl_homeenquiry` (`id`, `name`, `email`, `mobile`, `message`, `msg_time`) VALUES
(4, 'Jason Johnson', 'jjwebdesignstudio@gmail.com', '', '', '2015-02-04 22:05:29'),
(5, 'Jason Johnson', 'jjwebdesignstudio@gmail.com', '', '', '2015-02-21 13:00:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(50) NOT NULL default '',
  `user_fullname` varchar(50) NOT NULL default '',
  `user_email` varchar(100) NOT NULL default '',
  `user_password` varchar(50) NOT NULL default '',
  `user_isactive` tinyint(4) NOT NULL default '0',
  `user_isadmin` tinyint(4) NOT NULL default '0',
  `paypalid` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `user_name`, `user_fullname`, `user_email`, `user_password`, `user_isactive`, `user_isadmin`, `paypalid`) VALUES
(1, 'admin', 'admin', 'info@domainname.com', 'admin', 1, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `test_products`
--

CREATE TABLE IF NOT EXISTS `test_products` (
  `products_id` int(11) NOT NULL auto_increment,
  `product_title` varchar(255) NOT NULL default '',
  `product_make` varchar(255) NOT NULL default '',
  `products_model` varchar(32) default NULL,
  `products_image` varchar(64) default NULL,
  `products_price` decimal(15,4) NOT NULL default '0.0000',
  `discountpercentage` int(11) NOT NULL default '0',
  `Description` text NOT NULL,
  `products_weight` float NOT NULL default '0',
  `products_quantity_order_min` float NOT NULL default '1',
  `Producttag` varchar(255) NOT NULL default '',
  `shippingprice` float NOT NULL default '0',
  `totalstock` int(20) NOT NULL default '0',
  `catid` int(11) NOT NULL default '0',
  `shopid` int(11) NOT NULL default '0',
  `AuthorName` varchar(255) NOT NULL default '',
  `ISBN` varchar(100) NOT NULL default '',
  `Language` varchar(100) NOT NULL default '',
  `Publisher` varchar(255) NOT NULL default '',
  `Edition` varchar(100) NOT NULL default '',
  `Actor` varchar(255) NOT NULL default '',
  `Director` varchar(255) NOT NULL default '',
  `Singername` varchar(255) NOT NULL default '',
  `Ingredients` text NOT NULL,
  `Directions` text NOT NULL,
  `Lencetype` varchar(255) NOT NULL default '',
  `BatteryLife` varchar(255) NOT NULL default '',
  `BrandName` varchar(255) NOT NULL default '',
  `Electricityconsumption` varchar(255) NOT NULL default '',
  `warrenty` varchar(255) NOT NULL default '',
  `ShopCatid` int(100) NOT NULL default '0',
  PRIMARY KEY  (`products_id`),
  KEY `idx_products_model_zen` (`products_model`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `test_products`
--


-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE IF NOT EXISTS `ticket` (
  `tid` int(11) NOT NULL auto_increment,
  `TicketNumber` int(100) NOT NULL default '0',
  `Tmessage` longtext NOT NULL,
  `memid` int(11) NOT NULL default '0',
  `tdate` varchar(255) NOT NULL default '',
  `Tstatus` int(4) NOT NULL default '0',
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ticket`
--


-- --------------------------------------------------------

--
-- Table structure for table `title_gallary`
--

CREATE TABLE IF NOT EXISTS `title_gallary` (
  `t_id` bigint(20) NOT NULL auto_increment,
  `tname` varchar(255) NOT NULL,
  `t_img1` varchar(255) NOT NULL,
  `t_status` binary(1) NOT NULL,
  PRIMARY KEY  (`t_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `title_gallary`
--

INSERT INTO `title_gallary` (`t_id`, `tname`, `t_img1`, `t_status`) VALUES
(1, 'aaa', '', '\0');

-- --------------------------------------------------------

--
-- Table structure for table `tmessage`
--

CREATE TABLE IF NOT EXISTS `tmessage` (
  `mid` int(11) NOT NULL auto_increment,
  `mbody` longtext NOT NULL,
  `mpostby` int(11) NOT NULL default '0',
  `mtopicid` int(11) NOT NULL default '0',
  `mdate` varchar(255) NOT NULL default '',
  `TMstatus` int(4) NOT NULL default '0',
  PRIMARY KEY  (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tmessage`
--


-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE IF NOT EXISTS `upload` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `filename` varchar(225) NOT NULL default '',
  `shopid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `upload`
--

